#!/bin/sh
set -eu

export PYTHONDONTWRITEBYTECODE=1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CASE_ID=${1:-}

usage()
{
    cat <<'EOF'
Usage: ./verify_case.sh CASE_ID

CASE_ID is one of:
  r09_k2_a0   (R,k,a)=(9,2,0)
  r11_k3_a0   (R,k,a)=(11,3,0)
  r12_k3_a0   (R,k,a)=(12,3,0)
  r12_k3_a1   (R,k,a)=(12,3,1)
  all         verify the complete recorded certificate package
EOF
}

if [ -z "$CASE_ID" ]; then
    usage >&2
    exit 2
fi

if [ "$CASE_ID" = "all" ]; then
    exec "$ROOT/verify_all.sh"
fi

command -v python3 >/dev/null
command -v cc >/dev/null
python3 "$ROOT/verify_repository_manifest.py"

VERIFY_TMP=$(mktemp -d "${TMPDIR:-/tmp}/d8-case-verify.XXXXXX")
cleanup()
{
    rm -rf -- "$VERIFY_TMP"
}
trap cleanup EXIT HUP INT TERM

verify_cert19()
{
    cc -O3 -std=c99 -Wall -Wextra -Werror \
      -o "$VERIFY_TMP/verify19" \
      "$ROOT/cert19/verify_19_skeletons.c"
    "$VERIFY_TMP/verify19" "$ROOT/cert19/tri19_4567.plc"
}

verify_cert23()
{
    (cd "$ROOT/cert23" && \
      python3 verify_23_quartic.py quartic23_F3x8_F4x17.plc)
}

verify_quartic25()
{
    (cd "$ROOT/cert25B" && python3 verify_typeB25.py octa25c2.plc)
}

verify_core25()
{
    cc -O3 -std=c99 -Wall -Wextra -Werror -DCORE_ACCEPT_SUPERSET \
      -o "$VERIFY_TMP/verify_core_superset" \
      "$ROOT/cert25_core/verify_core_duals.c"
    (cd "$ROOT/cert25_core" && \
      python3 verify_run_parts.py && \
      D8_CORE_SUPERSET_VERIFIER="$VERIFY_TMP/verify_core_superset" \
        python3 verify_superset_manifest.py)
}

verify_parallel25()
{
    (cd "$ROOT/cert25_parallel" && python3 verify_manifest.py)
}

case "$CASE_ID" in
    r09_k2_a0)
        verify_cert19
        ;;
    r11_k3_a0)
        verify_cert23
        ;;
    r12_k3_a0)
        verify_quartic25
        verify_core25
        ;;
    r12_k3_a1)
        verify_quartic25
        verify_core25
        verify_parallel25
        ;;
    *)
        usage >&2
        exit 2
        ;;
esac

printf '%s\n' "PASS case $CASE_ID: no residual counterexample"
