#!/usr/bin/env python3
"""Verify the repository-wide SHA-256 manifest and its coverage."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path

from refresh_manifest import iter_manifest_files


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST.sha256"


def fail(message: str) -> None:
    raise SystemExit(f"FAIL repository manifest: {message}")


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    try:
        lines = MANIFEST.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        fail(f"cannot read {MANIFEST}: {exc}")

    listed: set[str] = set()
    for number, line in enumerate(lines, 1):
        if not line:
            continue
        expected, separator, relative = line.partition("  ")
        if not separator or len(expected) != 64:
            fail(f"{MANIFEST.name}:{number}: malformed entry")
        try:
            int(expected, 16)
        except ValueError:
            fail(f"{MANIFEST.name}:{number}: non-hexadecimal digest")

        relative_path = Path(relative)
        if relative_path.is_absolute() or ".." in relative_path.parts:
            fail(f"{MANIFEST.name}:{number}: unsafe path: {relative}")
        if relative in listed:
            fail(f"{MANIFEST.name}:{number}: duplicate entry: {relative}")
        listed.add(relative)

        path = ROOT / relative_path
        if not path.is_file():
            fail(f"missing file: {relative}")
        actual = digest(path)
        if actual != expected:
            fail(
                f"SHA-256 mismatch for {relative}\n"
                f"expected {expected}\nactual   {actual}"
            )

    actual_files = {
        path.relative_to(ROOT).as_posix() for path in iter_manifest_files(ROOT)
    }
    if listed != actual_files:
        missing = sorted(actual_files - listed)
        extra = sorted(listed - actual_files)
        details = []
        if missing:
            details.append("unlisted files:\n  " + "\n  ".join(missing))
        if extra:
            details.append("unexpected entries:\n  " + "\n  ".join(extra))
        fail("manifest coverage mismatch\n" + "\n".join(details))

    print(f"PASS root MANIFEST.sha256 files={len(listed)}")


if __name__ == "__main__":
    main()
