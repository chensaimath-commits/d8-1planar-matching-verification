#!/usr/bin/env python3
"""Locked manifest and fresh rerun for the optional 16-shard superset audit."""

from __future__ import annotations

from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess


HERE = Path(__file__).resolve().parent
RUN = HERE / "run_parts"

SOURCE_HASHES = {
    HERE / "enumerate_core_duals.c":
        "3c5718b60bbc2649ecf638e0184a3dc659e9800344b972e5116b73942c6cf567",
    HERE / "enumerate_core_superset":
        "982dc60d1e0f3a4c5b2dcb852084c0d03dc4178ca64dc6556df4557b5634f727",
    HERE / "verify_core_duals.c":
        "f7bbc7ba9035bc08490fe4d492eabb74081a5f27e2cbc74b7f2d66b62a9fbb49",
    HERE / "verify_core_superset":
        "bc62f12a7f7377444afb01005c13550c2af92c2aff7a7bea7ab0f8dd374de8ad",
}

SUPERSET_HASHES = (
    "38a62f1afd532eb06367bbfa270ed8ae597c6862783e80ede50a29a9a7521261",
    "6098e7dde1b8470f0a6be997619363c023dceaa5f3d46494a5c3acfe072254fa",
    "559fef63111fc65c80e7e37433d028e9459f91dfbfb18698f42d5255777845c8",
    "874801e0e88c4021e10635cc710f68b4ac41ec218fabbb0fdb061f7e1995b957",
    "8a369e7e6f8ceffa471b4767167cba6b7e9d494e114df672755d2d9726627009",
    "8d4f61ac2b6e1df974c5c9258c020a7e7279f7d58a05a389b8a9dca201dcbcfe",
    "21a8c499e3f918694a4f1e0d2cb238babf5497f24c06e0a7700c3c027e8ef5d0",
    "7c5133956c20a82f6aa15b6e6da145c584653ea00c8738de7c06c3dc9da2697a",
    "db38c72db18cf70b764aad2c70519bb57a5dbcd43bf3cc01d05cebf64ac81571",
    "7ba66851818251a9f6178d7c0242ea24fd23dc71bc5e422572fd4baa6c11a4c5",
    "891a3f7505e9ea0113a92176b4def8d0440911a07397284b40d3e65f2089b143",
    "be981ee868c54870fd2b939cf92e8eef75f98164ff093329b9c2e38eaebc623f",
    "4be66aae08b995d94a46365500376279854be8a222d9adec5600c7a73239170e",
    "338e43f6af0ce75c86a23815bc77a8c4b0028b19ea51b563cb8c6c3e0859c1ee",
    "76216a8dbaae4883ede86d62d14f100d5be814030e22339711a6ed5239a83a98",
    "a9736dd4107d37f567924b720ed59b921b7101f401f1a0be016de71956ad81e2",
)

EXPECTED_EMITTED = (
    3020, 4488, 4645, 1623, 2492, 4997, 1970, 2116,
    5674, 2511, 1749, 4960, 4883, 3557, 1584, 1900,
)

GENERATOR_KEYS = (
    "input", "matchings", "dominance", "assignments",
    "subdivision_solutions", "bad_contraction", "simple_D",
    "capacity_possible", "exact_patch_phases", "D_with_exact_patch",
    "emitted",
)

VERIFY_KEYS = (
    "maps", "valid_D", "phases", "simple_R", "exact_R", "profile_R",
    "typeX_choices", "typeX_simple", "typeX_degree", "typeX_fc",
    "a1_choices", "a1_simple", "a1_degree", "a1_fc",
)

EXPECTED_VERIFY_TOTALS = (
    52169, 52169, 30049344, 3847248, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
)


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def digest(path: Path) -> str:
    try:
        return sha256(path.read_bytes()).hexdigest()
    except OSError as exc:
        fail(f"cannot read {path}: {exc}")


def numeric_row(text: str, keys: tuple[str, ...], label: str) -> tuple[int, ...]:
    observed = dict((key, int(value)) for key, value in
                    re.findall(r"([A-Za-z0-9_]+)=([0-9]+)", text))
    if set(observed) != set(keys):
        fail(f"{label}: counter keys {sorted(observed)}, expected {sorted(keys)}")
    return tuple(observed[key] for key in keys)


def read_one_line(path: Path) -> str:
    try:
        lines = path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        fail(f"cannot read {path}: {exc}")
    if len(lines) != 1 or not lines[0]:
        fail(f"{path}: expected exactly one nonempty line")
    return lines[0]


def main() -> None:
    for path, expected in SOURCE_HASHES.items():
        actual = digest(path)
        if actual != expected:
            fail(f"{path}: sha256 {actual}, expected {expected}")

    verifier = Path(os.environ.get(
        "D8_CORE_SUPERSET_VERIFIER", HERE / "verify_core_superset"
    ))
    if not verifier.is_file():
        fail(f"independent verifier is not a regular file: {verifier}")

    # This independently locks the complete cubic catalogue, its exact
    # round-robin split, and the common first ten generator counters.
    base = subprocess.run(
        ["python3", str(HERE / "verify_run_parts.py")],
        text=True, capture_output=True,
    )
    if base.returncode != 0:
        fail(f"base manifest failed: {base.stdout}{base.stderr}")

    generator_rows = []
    verifier_rows = []
    for shard in range(16):
        core_row = numeric_row(
            read_one_line(RUN / f"coreD_{shard}.log"),
            GENERATOR_KEYS, f"coreD_{shard}.log",
        )
        sup_row = numeric_row(
            read_one_line(RUN / f"supD_{shard}.log"),
            GENERATOR_KEYS, f"supD_{shard}.log",
        )
        if sup_row[:-1] != core_row[:-1]:
            fail(f"supD_{shard}.log: traversal counters differ from exact run")
        if sup_row[-1] != EXPECTED_EMITTED[shard]:
            fail(f"supD_{shard}.log: emitted count differs from locked result")
        generator_rows.append(sup_row)

        stream = RUN / f"supD_{shard}.plc"
        actual = digest(stream)
        if actual != SUPERSET_HASHES[shard]:
            fail(f"{stream}: sha256 {actual}, expected {SUPERSET_HASHES[shard]}")
        if (RUN / f"supD_{shard}.out").read_bytes():
            fail(f"supD_{shard}.out: expected empty stdout capture")

        checked = subprocess.run(
            [str(verifier), str(stream)],
            text=True, capture_output=True,
        )
        if checked.returncode != 0:
            fail(f"fresh verifier shard {shard} failed: {checked.stderr.strip()}")
        if checked.stdout:
            fail(f"fresh verifier shard {shard}: expected empty stdout")
        fresh = checked.stderr.strip()
        recorded = read_one_line(RUN / f"supverify_{shard}.log")
        if fresh != recorded:
            fail(f"supverify_{shard}.log differs from fresh verifier output")
        if (RUN / f"supverify_{shard}.out").read_bytes():
            fail(f"supverify_{shard}.out: expected empty stdout capture")
        if not fresh.startswith("certificate_result=NO_COUNTEREXAMPLE "):
            fail(f"fresh verifier shard {shard} did not report NO_COUNTEREXAMPLE")
        verifier_rows.append(numeric_row(
            fresh.removeprefix("certificate_result=NO_COUNTEREXAMPLE "),
            VERIFY_KEYS, f"supverify_{shard}.log",
        ))

    generator_totals = tuple(map(sum, zip(*generator_rows)))
    verifier_totals = tuple(map(sum, zip(*verifier_rows)))
    if generator_totals[-1] != 52169:
        fail(f"aggregate emitted={generator_totals[-1]}, expected 52169")
    if verifier_totals != EXPECTED_VERIFY_TOTALS:
        fail(f"aggregate verifier totals {verifier_totals!r}")

    print(
        "PASS superset_generator shards=16 emitted=52169 "
        "source_and_stream_hashes=locked traversal_matches_exact=yes"
    )
    print(
        "PASS fresh_independent_verifier maps=52169 valid_D=52169 "
        "phases=30049344 simple_R=3847248 exact_R=0 profile_R=0 "
        "typeX_choices=0 a1_choices=0"
    )


if __name__ == "__main__":
    main()
