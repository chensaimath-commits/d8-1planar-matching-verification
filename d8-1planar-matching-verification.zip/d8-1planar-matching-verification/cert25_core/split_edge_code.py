#!/usr/bin/env python3
"""Split a one-byte plantri edge_code stream round-robin, without decoding maps."""

from pathlib import Path
import sys

HEADER = b">>edge_code<<"


def records(data: bytes):
    pos = len(HEADER)
    while pos < len(data):
        start = pos
        first = data[pos]
        pos += 1
        if first:
            size = first
        else:
            if pos >= len(data):
                raise ValueError("truncated long record header")
            descriptor = data[pos]
            pos += 1
            k, width = descriptor >> 4, descriptor & 15
            if not (k and width) or pos + k > len(data):
                raise ValueError("invalid long record header")
            size = int.from_bytes(data[pos:pos + k], "big")
            pos += k
        if pos + size > len(data):
            raise ValueError("truncated record body")
        pos += size
        yield data[start:pos]


def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: split_edge_code.py INPUT OUT_PREFIX PARTS")
    raw = Path(sys.argv[1]).read_bytes()
    if not raw.startswith(HEADER):
        raise SystemExit("missing edge_code header")
    parts = int(sys.argv[3])
    if parts < 1:
        raise SystemExit("PARTS must be positive")
    streams = [bytearray(HEADER) for _ in range(parts)]
    count = 0
    for count, record in enumerate(records(raw), 1):
        streams[(count - 1) % parts].extend(record)
    for i, stream in enumerate(streams):
        Path(f"{sys.argv[2]}{i}.ec").write_bytes(stream)
    print(f"records={count} parts={parts}")


if __name__ == "__main__":
    main()
