# 19-vertex core certificate for the two residual 25-vertex cases

This directory contains an independently checkable finite reduction for the
two common residual skeleton cases with

```text
V=25, E=50, faces=8 triangles + 19 quadrilaterals,
(degree,tau) = (5,2), (4,0), (3,0), 22*(4,1).
```

Here `tau(v)` is the number of incident triangular faces.  The files are:

* `enumerate_core_duals.c`: exhaustive inverse generator from the complete
  catalogue of 14-vertex connected cubic plane multigraphs;
* `verify_core_duals.c`: independent compiled checker with dart-level
  dualisation, all 576 local inverse patches, both distinguished marks, and
  a blossom matching implementation;
* `verify_25_core.py`: a separately written Python checker for the same
  dart-level dualisation, all 576 local
  inverse patches, the two distinguished inverse marks, kite completion, and
  factor-criticality checks;
* `split_edge_code.py`: a record-aware round-robin splitter for a plantri
  `edge_code` stream;
* `verify_run_parts.py`: the locked manifest checker for the completed
  16-shard run.  It checks the original catalogue hash and record structure,
  exact round-robin reconstruction, every logged counter, and every output
  byte;
* `plantri.c` and `PLANTRI-LICENSE-2.0.txt`: the exact official plantri 5.8
  source used to generate the cubic catalogue and its Apache 2.0 license;
* `cert25_core_plugin.c`: an older direct plantri filter for the same
  19-vertex dual class.  It is useful as a cross-check but is not needed by
  the smaller cubic-catalogue route.

The complete run has been performed.  Section 4 gives its commands, locked
counts, and hashes.

The common profile arises as follows.  In Type-X the three `(5,3)` vertices
form a TT-edge graph of minimum degree at least one, hence a path or a
triangle.  Choose a degree-two vertex `r` and one incident TT edge `pr`.
The two triangular sides of `pr` have third vertices `q` (the remaining high
vertex) and an ordinary vertex `a`; deleting `pr` merges them into the
quadrilateral `p-q-r-a` and gives the displayed residual profile.  In the
simple-new `a=1` type-3 branch, the augmented skeleton itself has this same
profile, with its new pole edge `q-a` incident with two quadrilaterals.

## 1. Why the common residual has a nine-vertex core

Let the exceptional vertices be

```text
q=(5,2), a=(4,0), z=(3,0).
```

The unique vertex with `tau>=2` is `q`; consequently there is no TT edge.
The eight triangular faces therefore have 24 distinct boundary edges.  Six
triangles are vertex-disjoint and the other two meet only at `q`.  Contract a
closed regular neighbourhood of each of the six triangle disks and of the
two-disk bowtie at `q`, retaining every external edge dart.  This gives a
connected plane pseudograph `P` with

```text
V(P)=9, E(P)=26, degree multiset 9,6,6,6,6,6,6,4,3.
```

Every original quadrilateral contains at most two triangle-boundary edges,
so its contracted facial walk has length 2, 3, or 4.  Here is a purely local
argument that also covers the non-3-connected Type-X residual.  If the two
quadrilateral edges adjacent at a vertex `v` are both triangle-boundary
edges and belong to the same triangle on their other side, that triangle and
the quadrilateral occupy the two complementary rotation sectors between the
same pair of darts.  The two darts are then adjacent in both cyclic
directions, forcing `degree_R(v)=2`, contrary to `delta(R)>=3`.  If the two
edges belong to different triangles, then `tau(v)>=2`.  Three selected edges
on a 4-cycle contain adjacent selected pairs centred at two distinct
vertices, so a quadrilateral with at least three triangle-boundary edges
would force two distinct vertices with `tau>=2`; only `q` has this property.
Consequently every quadrilateral contains at most two such edges, and `P`
has 19 faces of lengths 2 through 4.

The needed edge-connectivity statement differs slightly in the two source
branches.

* In the simple augmented `a=1` branch, the residual itself is 3-connected,
  hence has edge-connectivity at least three.
* In Type-X, write the residual as `R=S-pr`, where `S` is the 3-connected
  Type-X skeleton and the two faces of `pr` have distinct third vertices
  `q,a`.  If `R` had an edge cut of size at most two, `p,r` would have to be
  on opposite sides.  The two internally distinct paths `p-q-r` and `p-a-r`
  force two cut edges; adding `pr` gives a nontrivial 3-edge cut of `S` that
  is not a matching.  A nontrivial 3-edge cut in a 3-connected graph is a
  matching, a contradiction.  Hence again `lambda(R)>=3`.

Every nontrivial edge cut of `P` lifts verbatim to a cut of `R`, so `P` has no
one- or two-edge cut.  It may nevertheless have loops.

Let `D=P*`.  Then

```text
V(D)=19, E(D)=26, F(D)=9,
2 <= degree_D <= 4,
face lengths(D) = 3,4,6,6,6,6,6,6,9.
```

`D` is simple: a loop or a parallel pair in `D` is dual to a one- or two-edge
cut in `P`.  However, `D` may have bridges, dual to loops of `P`; no
2-connectivity restriction may be imposed on `D`.

## 2. The smaller complete cubic catalogue

Let `h` be the number of degree-two vertices of `D`.  Handshaking gives

```text
n2=h, n3=24-2h, n4=h-5,  5<=h<=12.
```

Suppress all degree-two vertices, recording the nonnegative subdivision
count on every resulting core edge.  At every degree-four core vertex, split
the four cyclic darts into two adjacent pairs and insert a new split edge.
The result is a connected cubic plane multigraph `C` with 14 vertices and 21
edges.  All split edges are non-loop and form a matching.

Conversely, enumerate every connected cubic plane multigraph `C` on 14
vertices, every non-loop matching `M`, contract `M`, and distribute
`|M|+5` subdivision vertices over the remaining edges.  This recovers every
possible `D`.  Loops and parallel edges in the suppressed core are retained;
the reconstructed `D` is explicitly required to be simple.

The planar dual of `C` is a general 9-vertex plane triangulation.  The bundled
official plantri 5.8 source has SHA-256

```text
3f70de5a3cacc78b2ed25b6a257588da94a518d8ae1dae74bcd0bf259cea07e8  plantri.c
```

From this directory, compile it and regenerate the complete class with:

```sh
cc -O3 -o plantri58 plantri.c
./plantri58 -E -d -m1c1t 9 cubic14_all.rebuilt.ec \
  >cubic14_all.rebuilt.out 2>cubic14_all.rebuilt.log
cmp cubic14_all.rebuilt.ec cubic14_all.ec
```

`-E` is essential.  It writes `edge_code`, which distinguishes the two darts
of loops and parallel edges.  With official plantri 5.8 (March 4, 2026), the
catalogue has

```text
152706 maps
sha256 e7c085b6069431e0b6da51102d8412fa92f96a5d81333a727e45e97f573587c7  cubic14_all.ec
```

Compile and run the inverse generator as follows:

```sh
cc -O3 -std=c99 -Wall -Wextra -Werror \
  -o enumerate_core_duals enumerate_core_duals.c
./enumerate_core_duals cubic14_all.ec core_duals.plc
```

The generator does all of the following with explicit edge darts:

1. enumerate every non-loop matching;
2. contract it using the plane-map rotation splice;
3. solve the nine nonnegative facial-incidence equations for subdivisions;
4. reconstruct and check a simple spherical `D` with the exact degree and
   face data;
5. dualise `D`, apply a safe face-sector constraint, and retain `D` only if
   at least one exact `8T+19Q` inverse patch exists;
6. canonically deduplicate plane-isomorphic `D` and write planar_code.

The face-sector prefilter is exact for face lengths.  At a triangle core the
six cyclic gap costs are `0,1,0,1,0,1` up to the two offsets.  At the bowtie
core, in cyclic order `U1,U2,V1,V2,s,X1,X2,Y1,Y2`, they are
`0,1,0,1,1,0,1,0,2`.  For every face `F` of `P`, the inverse boundary length is

```text
length_P(F) + sum(corner gap costs).
```

It must equal four.  Loops are processed as two distinct occurrences.
Before solving the full system, the generator also bounds every subdivision
run by explicitly comparing all cyclic starts and both directions of the two
endpoint cost sequences.  The longest complementary run (costs summing to
two) is one for triangle--triangle, triangle--bowtie, and bowtie--singleton,
two for bowtie--bowtie, and zero for the remaining pairs.  The code computes
these bounds by enumeration rather than assuming the stated values.

For historical reference, the 100-record smoke test before the latest safe
subdivision prefilter gave:

```text
input=100 matchings=212154 dominance=61427 assignments=4726889
subdivision_solutions=756385 bad_contraction=0 simple_D=726794
capacity_possible=735614 exact_patch_phases=0
D_with_exact_patch=0 emitted=0
```

This is only a historical smoke test, not a certificate count.  The complete
post-prefilter result is in Section 4.

## 3. The 576 inverse patches and independent verification

For each degree-six core rotation `(h0,...,h5)`, a triangle patch has exactly
two offsets, partitioning the darts into three consecutive pairs.  If these
are `(A1,A2),(B1,B2),(C1,C2)`, use

```text
rot(A)=(AB,AC,A1,A2)
rot(B)=(BC,BA,B1,B2)
rot(C)=(CA,CB,C1,C2).
```

For the degree-nine core, choose the singleton `s` in any of nine positions.
The only legal cyclic form, modulo bowtie automorphisms, is

```text
(U1,U2,V1,V2,s,X1,X2,Y1,Y2),
```

with rotations

```text
rot(q)=(qU,qV,s,qX,qY)
rot(U)=(UV,Uq,U1,U2)   rot(V)=(Vq,VU,V1,V2)
rot(X)=(XY,Xq,X1,X2)   rot(Y)=(Yq,YX,Y1,Y2).
```

Hence there are exactly `9*2^6=576` inverse parameters.  A bridge of `D`
becomes a loop of `P`; its two darts are never deduplicated.  Such a loop can
occasionally survive at the bowtie core by joining leaves in different
lobes, which is why bridges cannot be rejected in advance.

The following candidate-checker commands apply only if a modified or fresh
exact run emits a nonempty `core_duals.plc`:

```sh
cc -O3 -std=c99 -Wall -Wextra -Werror \
  -o verify_core_duals verify_core_duals.c
./verify_core_duals core_duals.plc
```

The separately written Python implementation is an additional candidate
cross-check:

```sh
python3 verify_25_core.py core_duals.plc
```

It reconstructs all facial walks and Euler identities from rotations,
checks global simplicity and the exact residual profile, and then treats the
two source branches separately:

* `a=1`: require `R` itself to be 3-connected and require the pole edge
  `q-a` to have a quadrilateral on each side; fill all 19 kites and delete
  `q-a`.
* Type-X: require `q,a` opposite in a distinguished quadrilateral, add its
  other diagonal `p-r`, and require the resulting skeleton `S` (not `R`) to
  be simple and 3-connected; fill only the other 18 kites.

Every globally simple 87-edge completion is checked to have degree sequence
`7^24,6` and is then tested for factor-criticality by deleting each vertex
and solving the resulting perfect-matching problem.

These two programs are *candidate checkers*: they deliberately reject a
header-only input because there is then no candidate on which their
independent reconstruction can be exercised.  In the completed run below,
the exhaustive generator's own exact sector CSP and exact residual rebuild
found no patch phase at all.  Thus the zero result is certified by the
complete catalogue, the exhaustive generator, and the run-manifest checker;
it would be incorrect to claim that either candidate checker was run on a
nonempty final output.  They remain an independent check of every candidate
if a modified rerun ever emits one.  For the recorded certificate, run the
locked main manifest and the nonempty wider independent audit instead:

```sh
python3 verify_run_parts.py
python3 verify_superset_manifest.py
```

## 4. Completed 16-shard run

> **Preserve the locked release.** The commands in this section describe the
> historical in-place run and overwrite checked-in binaries, streams, and
> logs. Run them only in a disposable copy of the repository. The script
> `verify_run_parts.py` deliberately locks the archived generator binary hash,
> so it verifies the recorded run; a fresh build on another toolchain should
> be compared by source, catalogue, stream, and counter results rather than by
> expecting that archived binary hash to match.

The checked-in generator was compiled on Ubuntu with GCC 13.3.0 by

```sh
cc -O3 -std=c99 -Wall -Wextra -Werror \
  -o enumerate_core_duals enumerate_core_duals.c
```

The source and resulting binary are locked by

```text
sha256 3c5718b60bbc2649ecf638e0184a3dc659e9800344b972e5116b73942c6cf567  enumerate_core_duals.c
sha256 df06d8331f1df7427261578127422ee24b4aa66e988d0e97252a1b6bc383bdcd  enumerate_core_duals
```

The checked-in binary is retained to lock the completed run environment; a
freshly compiled binary can be used for regeneration.

The following commands reproduce the record-level partition and the 16
generator invocations:

```sh
python3 split_edge_code.py cubic14_all.ec run_parts/rr_ 16
for i in $(seq 0 15); do
  ./enumerate_core_duals \
    "run_parts/rr_${i}.ec" "run_parts/coreD_${i}.plc" 1000000 \
    >"run_parts/coreD_${i}.out" 2>"run_parts/coreD_${i}.log" &
done
wait
python3 verify_run_parts.py
```

The third generator argument switches off the single-file 152706-record
assertion; EOF still terminates each shard.  `verify_run_parts.py` compensates
by strictly parsing the original catalogue and every shard and requiring

```text
record j of cubic14_all.ec = record floor(j/16) of rr_(j mod 16).ec
```

byte for byte.  It finds 9545 records in shards 0 and 1, 9544 in each other
shard, and 152706 in total.  It also locks every shard SHA-256 internally, so
the run cannot silently be verified against a different partition.

Summing the one-line summaries in `run_parts/coreD_0.log` through
`run_parts/coreD_15.log` gives

```text
input=152706
matchings=276001884
dominance=41391399
assignments=1742712513
subdivision_solutions=140931
bad_contraction=0
simple_D=139893
capacity_possible=140931
exact_patch_phases=0
D_with_exact_patch=0
emitted=0
```

Thus none of the 139893 reconstructed simple dual instances has even one of
the 576 phases whose exact inverse rebuild is a simple `8T+19Q` residual with
the required degree--triangle profile.  In particular there is no residual
skeleton in either source branch.

Every `run_parts/coreD_i.plc` consists of the 15-byte planar-code header and
nothing else, with common hash

```text
sha256 83c95d9e2ff250b84978fd44d0b8008d4b3b97387d1d0f1334f1de91077dda50  coreD_i.plc
```

Every corresponding `.out` file is empty.  The manifest checker prints

```text
PASS shards=16 exact_round_robin=yes input=152706 matchings=276001884 dominance=41391399 assignments=1742712513 subdivision_solutions=140931 bad_contraction=0 simple_D=139893 capacity_possible=140931 exact_patch_phases=0 D_with_exact_patch=0 emitted=0
PASS every coreD_i.plc is header-only sha256=83c95d9e2ff250b84978fd44d0b8008d4b3b97387d1d0f1334f1de91077dda50
PASS generator_source_sha256=3c5718b60bbc2649ecf638e0184a3dc659e9800344b972e5116b73942c6cf567
PASS generator_binary_sha256=df06d8331f1df7427261578127422ee24b4aa66e988d0e97252a1b6bc383bdcd
```

## 5. Wider independent superset audit

As an additional cross-check, compile the same inverse generator so that it
emits every reconstructed simple `D` surviving the safe abstract capacity
test, rather than only a `D` already known by the generator to have an exact
patch:

```sh
cc -O3 -std=c99 -Wall -Wextra -Werror \
  -DCORE_EMIT_SIMPLE_SUPERSET -o enumerate_core_superset \
  enumerate_core_duals.c
cc -O3 -std=c99 -Wall -Wextra -Werror \
  -DCORE_ACCEPT_SUPERSET -o verify_core_superset verify_core_duals.c
for i in $(seq 0 15); do
  ./enumerate_core_superset \
    "run_parts/rr_${i}.ec" "run_parts/supD_${i}.plc" 1000000 \
    >"run_parts/supD_${i}.out" 2>"run_parts/supD_${i}.log"
  ./verify_core_superset "run_parts/supD_${i}.plc" \
    >"run_parts/supverify_${i}.out" 2>"run_parts/supverify_${i}.log"
done
python3 verify_superset_manifest.py
```

The superset generator emits 52169 maps over the 16 shards.  The separately
compiled verifier processes every one of its 576 inverse phases, obtaining

```text
maps=52169 valid_D=52169 phases=30049344 simple_R=3847248
exact_R=0 profile_R=0 typeX_choices=0 a1_choices=0
```

Thus this wider route independently reaches the same zero before either
source-branch completion test.  `verify_superset_manifest.py` first reruns the
main manifest, locks the superset generator/checker source and binary hashes,
locks all 16 superset stream hashes and generator rows, and freshly reruns the
compiled checker on every stream.  Its output is

```text
PASS superset_generator shards=16 emitted=52169 source_and_stream_hashes=locked traversal_matches_exact=yes
PASS fresh_independent_verifier maps=52169 valid_D=52169 phases=30049344 simple_R=3847248 exact_R=0 profile_R=0 typeX_choices=0 a1_choices=0
```
