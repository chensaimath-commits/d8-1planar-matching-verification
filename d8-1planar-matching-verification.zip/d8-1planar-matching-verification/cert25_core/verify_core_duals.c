/*
 * Independent second-stage checker for the 19-vertex core-dual certificate.
 *
 * Input is planar_code produced by enumerate_core_duals.c (or by the
 * plantri core plug-in).  Every input D is checked from scratch, dualised
 * to a nine-vertex plane pseudograph P, and expanded in all
 *
 *                  2^6 * 9 = 576
 *
 * local phases.  Each degree-six vertex of P is replaced by a facial
 * triangle (the two pairings of its six cyclic darts), while its unique
 * degree-nine vertex is replaced by the facial bow-tie (the nine choices
 * of the singleton dart at the common vertex).  Edge identifiers, not
 * endpoint pairs, are retained during dualisation and expansion.  Thus
 * loops, parallel edges and bridges of P are treated without ambiguity.
 *
 * Compile:
 *   cc -O3 -std=c99 -Wall -Wextra -o verify_core_duals \
 *      verify_core_duals.c
 * Run (optional last argument is a record limit for smoke tests):
 *   ./verify_core_duals core_duals.plc [limit]
 *
 * A surviving residual R is independently required to be a simple
 * connected 25-vertex plane graph with 50 edges, facial inventory
 * 3^8 4^19, and labelled profile
 *
 *   q:(5,2), a:(4,0), z:(3,0), and 22 vertices (4,1).
 *
 * Both inverse cases are then tested.
 *   Type X: q,a are opposite on a distinguished quadrilateral Q*.  Add
 *   only its other diagonal and both diagonals of all other quadrilaterals.
 *   a=1: qa is a skeleton edge with a quadrilateral on both sides.  Add
 *   both diagonals of every quadrilateral and delete the skeleton qa copy.
 * Every added diagonal must be absent from the residual skeleton and all
 * added diagonals must be pairwise distinct.  Finally H must have 87 edges, degree multiset
 * 7^24,6 (z is the degree-six vertex), and be factor-critical.
 */

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DN 19
#define DM 26
#define DF 9
#define PN 9
#define RN 25
#define RM 50
#define RF 27
#define MAXN 25
#define MAXM 50
#define MAXD 9
#define MAXF 27
#define MAXFL 9

typedef struct {
    int n, m;
    int deg[MAXN];
    int row[MAXN][MAXD];
    int occ_v[MAXM][2];
    int occ_p[MAXM][2];
} Map;

static Map D, P, R;
static int p_bow, p_a, p_z, p_tri[6];
static int r_q, r_a, r_z;
static int r_face_len[MAXF], r_face_vert[MAXF][MAXFL];
static int r_face_of[MAXN][MAXD];

static unsigned long long maps_read, maps_valid_D, phase_trials;
static unsigned long long simple_residuals, exact_residuals, profile_residuals;
static unsigned long long typeX_choices, typeX_simple, typeX_degree, typeX_fc;
static unsigned long long a1_choices, a1_simple, a1_degree, a1_fc;

static void die(const char *s)
{
    fprintf(stderr, "verify_core_duals: ERROR: %s\n", s);
    exit(2);
}

/* phi = sigma^{-1} alpha.  Optional edge/vertex facial walks are returned
   in traversal order.  This routine is valid for loops and parallel edges. */
static int map_faces(const Map *g, int face_of[MAXN][MAXD], int *lengths,
                     int face_edge[MAXF][MAXFL],
                     int face_vert[MAXF][MAXFL], int max_faces)
{
    unsigned char seen[MAXN][MAXD];
    int v, p, f = 0;
    memset(seen, 0, sizeof(seen));
    for (v = 0; v < g->n; ++v)
        for (p = 0; p < g->deg[v]; ++p)
        {
            int cv, cp, len = 0;
            if (seen[v][p]) continue;
            if (f >= max_faces) return -1;
            cv = v; cp = p;
            do
            {
                int e, side, nv, np;
                if (seen[cv][cp] || len >= MAXFL) return -1;
                seen[cv][cp] = 1;
                if (face_of) face_of[cv][cp] = f;
                e = g->row[cv][cp];
                if (face_edge) face_edge[f][len] = e;
                if (face_vert) face_vert[f][len] = cv;
                ++len;
                if (g->occ_v[e][0] == cv && g->occ_p[e][0] == cp)
                    side = 1;
                else if (g->occ_v[e][1] == cv && g->occ_p[e][1] == cp)
                    side = 0;
                else return -1;
                nv = g->occ_v[e][side];
                np = g->occ_p[e][side];
                cp = (np + g->deg[nv] - 1) % g->deg[nv];
                cv = nv;
            }
            while (cv != v || cp != p);
            lengths[f++] = len;
        }
    return f;
}

static int fill_occurrences(Map *g)
{
    int count[MAXM] = {0}, v, p, e, k;
    memset(g->occ_v, 0, sizeof(g->occ_v));
    memset(g->occ_p, 0, sizeof(g->occ_p));
    for (v = 0; v < g->n; ++v)
        for (p = 0; p < g->deg[v]; ++p)
        {
            e = g->row[v][p];
            if (e < 0 || e >= g->m) return 0;
            k = count[e]++;
            if (k >= 2) return 0;
            g->occ_v[e][k] = v;
            g->occ_p[e][k] = p;
        }
    for (e = 0; e < g->m; ++e)
        if (count[e] != 2) return 0;
    return 1;
}

static int read_planar_record(FILE *in)
{
    int n = getc(in), v, p, x, e = 0;
    int edge_id[DN][DN];
    if (n == EOF) return 0;
    if (n != DN) die("input is not byte planar_code on 19 vertices");
    memset(&D, 0, sizeof(D));
    for (v = 0; v < DN; ++v)
        for (p = 0; p < DN; ++p) edge_id[v][p] = -1;
    D.n = DN; D.m = DM;
    for (v = 0; v < DN; ++v)
    {
        unsigned char row_seen[DN] = {0};
        p = 0;
        while ((x = getc(in)) != 0)
        {
            int w;
            if (x == EOF || x < 1 || x > DN || p >= MAXD)
                die("truncated or malformed planar_code row");
            w = x - 1;
            if (w == v) die("D has a loop");
            if (row_seen[w]) die("D has parallel adjacency entries");
            row_seen[w] = 1;
            if (v < w)
            {
                if (e >= DM) die("D has too many edges");
                edge_id[v][w] = edge_id[w][v] = e++;
            }
            else if (edge_id[v][w] < 0)
                die("planar_code adjacency is asymmetric or out of order");
            D.row[v][p++] = edge_id[v][w];
        }
        D.deg[v] = p;
    }
    if (e != DM || !fill_occurrences(&D)) die("D does not have 26 simple edges");
    return 1;
}

static int validate_D_and_build_dual(void)
{
    int lengths[MAXF], fe[MAXF][MAXFL], fv[MAXF][MAXFL];
    int counts[10] = {0}, nf, f, j, n6 = 0;
    int face_of[MAXN][MAXD];
    for (j = 0; j < DN; ++j)
        if (D.deg[j] < 2 || D.deg[j] > 4) return 0;
    nf = map_faces(&D, face_of, lengths, fe, fv, MAXF);
    if (nf != DF || D.n - D.m + nf != 2) return 0;
    for (f = 0; f < nf; ++f)
    {
        if (lengths[f] < 1 || lengths[f] > 9) return 0;
        ++counts[lengths[f]];
    }
    if (counts[3] != 1 || counts[4] != 1 || counts[6] != 6 ||
        counts[9] != 1) return 0;
    for (j = 1; j <= 9; ++j)
        if (j != 3 && j != 4 && j != 6 && j != 9 && counts[j]) return 0;

    memset(&P, 0, sizeof(P));
    P.n = PN; P.m = DM;
    p_bow = p_a = p_z = -1;
    for (f = 0; f < DF; ++f)
    {
        P.deg[f] = lengths[f];
        /* Use the primal facial orbit as the corresponding dual rotation.
           Reversing every row would only globally mirror P, so phase
           existence is unchanged; this convention matches the explicit
           patch rotations in the audit notes. */
        for (j = 0; j < lengths[f]; ++j)
            P.row[f][j] = fe[f][j];
        if (lengths[f] == 9) p_bow = f;
        else if (lengths[f] == 4) p_a = f;
        else if (lengths[f] == 3) p_z = f;
        else if (lengths[f] == 6) p_tri[n6++] = f;
    }
    if (p_bow < 0 || p_a < 0 || p_z < 0 || n6 != 6 ||
        !fill_occurrences(&P)) return 0;
    /* This also checks that the chosen dual rotation is cellular and has
       the required nineteen facial orbits, even when P has loops. */
    nf = map_faces(&P, NULL, lengths, NULL, NULL, MAXF);
    return nf == DN && P.n - P.m + nf == 2;
}

static void set_row(int v, int d, const int *edges)
{
    int i;
    R.deg[v] = d;
    for (i = 0; i < d; ++i) R.row[v][i] = edges[i];
}

static int build_residual(int phase_mask, int bow_phase)
{
    int member[PN][5];
    int v, j, nv = 0, ne = DM, ti = 0;
    memset(&R, 0, sizeof(R));
    R.n = RN; R.m = RM;
    /* Allocate replacement vertices. */
    for (v = 0; v < PN; ++v)
    {
        int cnt = P.deg[v] == 9 ? 5 : (P.deg[v] == 6 ? 3 : 1);
        for (j = 0; j < cnt; ++j) member[v][j] = nv++;
    }
    if (nv != RN) return 0;
    r_q = member[p_bow][0];
    r_a = member[p_a][0];
    r_z = member[p_z][0];

    for (v = 0; v < PN; ++v)
    {
        if (P.deg[v] == 3 || P.deg[v] == 4)
            set_row(member[v][0], P.deg[v], P.row[v]);
        else if (P.deg[v] == 6)
        {
            int o = (phase_mask >> ti++) & 1;
            int A = member[v][0], B = member[v][1], C = member[v][2];
            int ab = ne++, bc = ne++, ca = ne++;
            int ra[4] = {P.row[v][o], P.row[v][(o+1)%6], ab, ca};
            int rb[4] = {P.row[v][(o+2)%6], P.row[v][(o+3)%6], bc, ab};
            int rc[4] = {P.row[v][(o+4)%6], P.row[v][(o+5)%6], ca, bc};
            set_row(A, 4, ra); set_row(B, 4, rb); set_row(C, 4, rc);
        }
        else if (P.deg[v] == 9)
        {
            int q = member[v][0], u = member[v][1], x = member[v][2];
            int w = member[v][3], y = member[v][4], h = bow_phase;
            int qu = ne++, qx = ne++, ux = ne++;
            int qw = ne++, qy = ne++, wy = ne++;
            int rq[5] = {P.row[v][h], qu, qx, qw, qy};
            int ru[4] = {P.row[v][(h+1)%9], P.row[v][(h+2)%9], ux, qu};
            int rx[4] = {P.row[v][(h+3)%9], P.row[v][(h+4)%9], qx, ux};
            int rw[4] = {P.row[v][(h+5)%9], P.row[v][(h+6)%9], wy, qw};
            int ry[4] = {P.row[v][(h+7)%9], P.row[v][(h+8)%9], qy, wy};
            set_row(q,5,rq); set_row(u,4,ru); set_row(x,4,rx);
            set_row(w,4,rw); set_row(y,4,ry);
        }
        else return 0;
    }
    return ti == 6 && ne == RM && fill_occurrences(&R);
}

static int simple_connected_R(void)
{
    unsigned char pair[RN][RN], seen[RN] = {0};
    int queue[RN], head = 0, tail = 0, e, u, v, i;
    memset(pair, 0, sizeof(pair));
    for (e = 0; e < RM; ++e)
    {
        u = R.occ_v[e][0]; v = R.occ_v[e][1];
        if (u == v || pair[u][v]) return 0;
        pair[u][v] = pair[v][u] = 1;
    }
    seen[0] = 1; queue[tail++] = 0;
    while (head < tail)
    {
        u = queue[head++];
        for (i = 0; i < R.deg[u]; ++i)
        {
            e = R.row[u][i];
            v = R.occ_v[e][0] == u ? R.occ_v[e][1] : R.occ_v[e][0];
            if (!seen[v]) { seen[v] = 1; queue[tail++] = v; }
        }
    }
    return tail == RN;
}

static void base_adjacency(unsigned char adj[RN][RN]);

static int connected_without_vertices(unsigned char adj[RN][RN], int x, int y)
{
    unsigned char seen[RN] = {0};
    int q[RN], head=0,tail=0,u,v;
    for (u=0;u<RN;++u) if (u!=x && u!=y)
    { seen[u]=1;q[tail++]=u;break; }
    while(head<tail)
    {
        u=q[head++];
        for(v=0;v<RN;++v) if(v!=x&&v!=y&&adj[u][v]&&!seen[v])
        { seen[v]=1;q[tail++]=v; }
    }
    for(u=0;u<RN;++u) if(u!=x&&u!=y&&!seen[u]) return 0;
    return 1;
}

static int vertex_connectivity_at_least(unsigned char adj[RN][RN], int k)
{
    int u,v;
    if (!connected_without_vertices(adj,-1,-1)) return 0;
    if (k>=2) for(u=0;u<RN;++u)
        if(!connected_without_vertices(adj,u,-1)) return 0;
    if (k>=3) for(u=0;u<RN;++u) for(v=u+1;v<RN;++v)
        if(!connected_without_vertices(adj,u,v)) return 0;
    return 1;
}

static int connected_without_edges(int e1, int e2)
{
    unsigned char seen[RN]={0};
    int q[RN],head=0,tail=0,u,v,i,e;
    seen[0]=1;q[tail++]=0;
    while(head<tail)
    {
        u=q[head++];
        for(i=0;i<R.deg[u];++i)
        {
            e=R.row[u][i]; if(e==e1||e==e2) continue;
            v=R.occ_v[e][0]==u?R.occ_v[e][1]:R.occ_v[e][0];
            if(!seen[v]){seen[v]=1;q[tail++]=v;}
        }
    }
    return tail==RN;
}

static int residual_has_lambda_at_least_three(void)
{
    int e,f;
    for(e=0;e<RM;++e) if(!connected_without_edges(e,-1)) return 0;
    for(e=0;e<RM;++e) for(f=e+1;f<RM;++f)
        if(!connected_without_edges(e,f)) return 0;
    return 1;
}

static int validate_profile(void)
{
    unsigned char adj[RN][RN];
    int f, j, nf, nt = 0, nq = 0, tau[RN] = {0};
    nf = map_faces(&R, r_face_of, r_face_len, NULL, r_face_vert, MAXF);
    if (nf != RF || R.n - R.m + nf != 2) return 0;
    for (f = 0; f < nf; ++f)
    {
        int len = r_face_len[f];
        if (len != 3 && len != 4) return 0;
        for (j = 0; j < len; ++j)
        {
            int k;
            for (k = j+1; k < len; ++k)
                if (r_face_vert[f][j] == r_face_vert[f][k]) return 0;
        }
        if (len == 3)
        {
            ++nt;
            for (j = 0; j < 3; ++j) ++tau[r_face_vert[f][j]];
        }
        else ++nq;
    }
    if (nt != 8 || nq != 19) return 0;
    for (j = 0; j < RN; ++j)
    {
        if (j == r_q) { if (R.deg[j] != 5 || tau[j] != 2) return 0; }
        else if (j == r_a) { if (R.deg[j] != 4 || tau[j] != 0) return 0; }
        else if (j == r_z) { if (R.deg[j] != 3 || tau[j] != 0) return 0; }
        else if (R.deg[j] != 4 || tau[j] != 1) return 0;
    }
    ++exact_residuals;
    base_adjacency(adj);
    /* Both residual sources are 2-connected and have edge-connectivity
       at least three.  Type X need not be 3-connected. */
    return vertex_connectivity_at_least(adj,2) &&
           residual_has_lambda_at_least_three();
}

/* Edmonds' blossom algorithm, specialised to n<=25. */
static int blossom_lca(int n, int a, int b, int match[RN], int parent[RN],
                       int base[RN])
{
    unsigned char used[RN] = {0};
    (void)n;
    for (;;)
    {
        a = base[a]; used[a] = 1;
        if (match[a] < 0) break;
        a = parent[match[a]];
    }
    for (;;)
    {
        b = base[b];
        if (used[b]) return b;
        b = parent[match[b]];
    }
}

static void blossom_mark_path(int v, int b, int child, int match[RN],
                              int parent[RN], int base[RN],
                              unsigned char blossom[RN])
{
    while (base[v] != b)
    {
        blossom[base[v]] = blossom[base[match[v]]] = 1;
        parent[v] = child;
        child = match[v];
        v = parent[match[v]];
    }
}

static int blossom_path(int n, unsigned char adj[RN][RN], int root,
                        int match[RN], int parent[RN], int base[RN])
{
    int q[RN], head = 0, tail = 0, v, u, cur, b, i;
    unsigned char used[RN] = {0}, blossom[RN];
    for (i = 0; i < n; ++i) { parent[i] = -1; base[i] = i; }
    used[root] = 1; q[tail++] = root;
    while (head < tail)
    {
        v = q[head++];
        for (u = 0; u < n; ++u) if (adj[v][u] && base[v] != base[u] && match[v] != u)
        {
            if (u == root || (match[u] >= 0 && parent[match[u]] >= 0))
            {
                b = blossom_lca(n,v,u,match,parent,base);
                memset(blossom,0,sizeof(blossom));
                blossom_mark_path(v,b,u,match,parent,base,blossom);
                blossom_mark_path(u,b,v,match,parent,base,blossom);
                for (i = 0; i < n; ++i) if (blossom[base[i]])
                {
                    base[i] = b;
                    if (!used[i]) { used[i] = 1; q[tail++] = i; }
                }
            }
            else if (parent[u] < 0)
            {
                parent[u] = v;
                if (match[u] < 0)
                {
                    cur = u;
                    while (cur >= 0)
                    {
                        int pv = parent[cur];
                        int next = pv < 0 ? -1 : match[pv];
                        match[cur] = pv;
                        if (pv >= 0) match[pv] = cur;
                        cur = next;
                    }
                    return 1;
                }
                {
                    int mu = match[u];
                    used[mu] = 1; q[tail++] = mu;
                }
            }
        }
    }
    return 0;
}

static int perfect_after_delete(unsigned char full[RN][RN], int deleted)
{
    unsigned char adj[RN][RN] = {{0}};
    int old_of[RN], n = 0, u, v, match[RN], parent[RN], base[RN], size = 0;
    for (u = 0; u < RN; ++u) if (u != deleted) old_of[n++] = u;
    for (u = 0; u < n; ++u)
        for (v = 0; v < n; ++v) adj[u][v] = full[old_of[u]][old_of[v]];
    for (u = 0; u < n; ++u) match[u] = -1;
    for (u = 0; u < n; ++u)
        if (match[u] < 0) size += blossom_path(n,adj,u,match,parent,base);
    return 2 * size == n;
}

static int factor_critical(unsigned char adj[RN][RN])
{
    int v;
    for (v = 0; v < RN; ++v)
        if (!perfect_after_delete(adj,v)) return 0;
    return 1;
}

static void base_adjacency(unsigned char adj[RN][RN])
{
    int e, u, v;
    memset(adj,0,RN*RN);
    for (e = 0; e < RM; ++e)
    {
        u = R.occ_v[e][0]; v = R.occ_v[e][1];
        adj[u][v] = adj[v][u] = 1;
    }
}

static int locate_edge(int u, int v)
{
    int i, e;
    for (i = 0; i < R.deg[u]; ++i)
    {
        e = R.row[u][i];
        if ((R.occ_v[e][0] == u ? R.occ_v[e][1] : R.occ_v[e][0]) == v)
            return e;
    }
    return -1;
}

static int final_degree_test(unsigned char adj[RN][RN])
{
    int u,v,d,m=0;
    for (u=0;u<RN;++u)
    {
        d=0;
        for (v=0;v<RN;++v) if (adj[u][v]) {++d;if(u<v)++m;}
        if (u==r_z) { if (d!=6) return 0; }
        else if (d!=7) return 0;
    }
    return m==87;
}

/* Add the selected diagonal set.  distinguished=-1 means all Q faces get
   both diagonals (a=1); otherwise that Q gets only its non-qa diagonal.
   The added-pair matrix enforces global distinctness.  Every new diagonal,
   including qa in a=1, must be absent from the residual skeleton. */
static int reconstruct(unsigned char out[RN][RN], int distinguished, int a1)
{
    unsigned char added[RN][RN] = {{0}};
    int f,j;
    base_adjacency(out);
    for (f=0;f<RF;++f) if (r_face_len[f]==4)
    {
        int x0=r_face_vert[f][0],x1=r_face_vert[f][1];
        int x2=r_face_vert[f][2],x3=r_face_vert[f][3];
        int du[2]={x0,x1}, dv[2]={x2,x3};
        int first=0,last=2;
        if (f==distinguished)
        {
            /* q,a occupy one opposite pair, so the other is x1,x3. */
            if (!((x0==r_q&&x2==r_a)||(x0==r_a&&x2==r_q)))
            { du[0]=x0;dv[0]=x2; }
            else { du[0]=x1;dv[0]=x3; }
            first=0;last=1;
        }
        for (j=first;j<last;++j)
        {
            int u=du[j],v=dv[j];
            if (u==v || added[u][v]) return 0;
            added[u][v]=added[v][u]=1;
            if (out[u][v]) return 0;
            out[u][v]=out[v][u]=1;
        }
    }
    if (a1)
    {
        out[r_q][r_a]=out[r_a][r_q]=0;
    }
    return 1;
}

static int typeX_source_ok(int f)
{
    unsigned char adj[RN][RN];
    int *x=r_face_vert[f],p=-1,r=-1,tau[RN]={0},i,j,nhigh=0;
    if ((x[0]==r_q&&x[2]==r_a)||(x[0]==r_a&&x[2]==r_q))
        p=x[1],r=x[3];
    else if ((x[1]==r_q&&x[3]==r_a)||(x[1]==r_a&&x[3]==r_q))
        p=x[0],r=x[2];
    else return 0;
    base_adjacency(adj);
    if (adj[p][r]) return 0;
    adj[p][r]=adj[r][p]=1;
    if (!vertex_connectivity_at_least(adj,3)) return 0;
    for(i=0;i<RF;++i) if(r_face_len[i]==3)
        for(j=0;j<3;++j) ++tau[r_face_vert[i][j]];
    tau[p]+=2;tau[r]+=2;++tau[r_q];++tau[r_a];
    for(i=0;i<RN;++i)
    {
        int ds=R.deg[i]+(i==p||i==r);
        if(ds==5&&tau[i]==3) ++nhigh;
        else if(i==r_z) { if(ds!=3||tau[i]!=0) return 0; }
        else if(ds!=4||tau[i]!=1) return 0;
    }
    return nhigh==3;
}

static void evaluate_inverse_cases(void)
{
    unsigned char adj[RN][RN];
    int f, eqa = locate_edge(r_q,r_a);
    /* Type X distinguished quadrilateral. */
    for (f=0;f<RF;++f) if (r_face_len[f]==4)
    {
        int *x=r_face_vert[f];
        if (!((x[0]==r_q&&x[2]==r_a)||(x[0]==r_a&&x[2]==r_q)||
              (x[1]==r_q&&x[3]==r_a)||(x[1]==r_a&&x[3]==r_q))) continue;
        ++typeX_choices;
        if (!typeX_source_ok(f)) continue;
        if (!reconstruct(adj,f,0)) continue;
        ++typeX_simple;
        if (!final_degree_test(adj)) continue;
        ++typeX_degree;
        if (factor_critical(adj)) ++typeX_fc;
    }
    /* a=1 pole edge: both incident faces are quadrilaterals. */
    if (eqa>=0)
    {
        int f0=r_face_of[R.occ_v[eqa][0]][R.occ_p[eqa][0]];
        int f1=r_face_of[R.occ_v[eqa][1]][R.occ_p[eqa][1]];
        if (f0!=f1 && r_face_len[f0]==4 && r_face_len[f1]==4)
        {
            ++a1_choices;
            base_adjacency(adj);
            if (!vertex_connectivity_at_least(adj,3)) return;
            if (reconstruct(adj,-1,1))
            {
                ++a1_simple;
                if (final_degree_test(adj))
                {
                    ++a1_degree;
                    if (factor_critical(adj)) ++a1_fc;
                }
            }
        }
    }
}

int main(int argc, char **argv)
{
    FILE *in;
    char header[15];
    long limit=-1;
    int limited=argc==3;
    int mask,h;
    if (argc<2 || argc>3)
    {
        fprintf(stderr,"usage: %s core_duals.plc [record-limit]\n",argv[0]);
        return 2;
    }
    if (argc==3)
    {
        char *end;
        errno=0; limit=strtol(argv[2],&end,10);
        if (errno||*end||limit<0) die("bad nonnegative record limit");
    }
    in=fopen(argv[1],"rb"); if(!in) die("cannot open input");
    if (fread(header,1,15,in)!=15 || memcmp(header,">>planar_code<<",15)!=0)
        die("missing >>planar_code<< header");
    while ((limit<0 || (long)maps_read<limit) && read_planar_record(in))
    {
        unsigned long long exact_before=exact_residuals;
        ++maps_read;
        if (!validate_D_and_build_dual()) die("invalid core-dual input record");
        ++maps_valid_D;
        for (mask=0;mask<64;++mask) for(h=0;h<9;++h)
        {
            ++phase_trials;
            if (!build_residual(mask,h)) die("internal expansion failure");
            if (!simple_connected_R()) continue;
            ++simple_residuals;
            if (!validate_profile()) continue;
            ++profile_residuals;
            evaluate_inverse_cases();
        }
#ifndef CORE_ACCEPT_SUPERSET
        if(exact_residuals==exact_before)
            die("emitted D has no exact residual patch");
#else
        (void)exact_before;
#endif
        if (maps_read%10000==0)
            fprintf(stderr,"progress maps=%llu residual_profiles=%llu fc=%llu/%llu\n",
                    maps_read,profile_residuals,typeX_fc,a1_fc);
    }
    if (fclose(in)!=0) die("input close error");
    if (!limited && maps_read==0) die("empty full-certificate input");
    fprintf(stderr,
      "certificate_result=%s maps=%llu valid_D=%llu phases=%llu "
      "simple_R=%llu exact_R=%llu profile_R=%llu "
      "typeX_choices=%llu typeX_simple=%llu typeX_degree=%llu typeX_fc=%llu "
      "a1_choices=%llu a1_simple=%llu a1_degree=%llu a1_fc=%llu\n",
      (typeX_fc||a1_fc)?"COUNTEREXAMPLE":"NO_COUNTEREXAMPLE",
      maps_read,maps_valid_D,phase_trials,simple_residuals,exact_residuals,
      profile_residuals,
      typeX_choices,typeX_simple,typeX_degree,typeX_fc,
      a1_choices,a1_simple,a1_degree,a1_fc);
    return (typeX_fc||a1_fc)?1:0;
}
