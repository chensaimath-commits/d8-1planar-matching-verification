/*
 * Exhaustive inverse generator for the 19-vertex core-duals D used in
 * the last two n=25 cases.
 *
 * Input is the complete plantri edge_code catalogue of connected cubic
 * plane multigraphs on 14 vertices:
 *
 *   plantri -E -d -m1c1t 9 cubic14.ec
 *
 * Compile and run:
 *
 *   cc -O3 -std=c99 -Wall -Wextra -o enumerate_core_duals \
 *      enumerate_core_duals.c
 *   ./enumerate_core_duals cubic14.ec core_duals.plc
 *
 * An optional third argument N stops after N input maps (for smoke tests).
 *
 * For every cubic map C, the program enumerates every non-loop matching M.
 * It contracts M, then distributes |M|+5 subdivision vertices over the
 * remaining core edges.  The distribution is solved from the nine facial
 * incidence equations, not guessed with a bounded composition loop.  A
 * canonical planar_code record is emitted exactly when the resulting D is a simple connected
 * plane graph with 19 vertices, 26 edges, degrees 2..4, and face multiset
 * 3,4,6,6,6,6,6,6,9.  Records arising from different inverse descriptions
 * are deduplicated by a complete rooted plane-map canonical code.
 *
 * edge_code, rather than planar_code, is essential: C can have loops and
 * parallel edges and each of their two darts must remain distinguishable.
 */

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CV 14
#define CE 21
#define CF 9
#define DV 19
#define DE 26
#define MAXV 19
#define MAXE 26
#define MAXDEG 4
#define EXPECTED_CUBIC_MAPS 152706

typedef struct {
    int n, m;
    int deg[MAXV];
    int row[MAXV][MAXDEG];
    int occ_v[MAXE][2];
    int occ_p[MAXE][2];
} Map;

static Map cubic, base_map, final_map;
static int c_face_of[MAXV][MAXDEG], c_face_len[CF];
static int c_edge_face[CE][2];
static int chosen[CE], mate_edge[CV], matched_face_count[CF];
static int subdivision[CE], assigned[CE];
static int subdivision_upper[CE];
static int base_old_edges[CE], base_edge_count;
static int target_len[CF], remainder_face[CF];
static FILE *out_file;

#define D_RECORD_SIZE 72
static uint64_t *dedup_hash;
static unsigned char *dedup_key;
static size_t dedup_capacity, dedup_used;

static unsigned long long count_input;
static unsigned long long count_matchings;
static unsigned long long count_dominance;
static unsigned long long count_assignments;
static unsigned long long count_subdivision_solutions;
static unsigned long long count_capacity_possible;
static unsigned long long count_exact_patch_phases;
static unsigned long long count_D_with_exact_patch;
static unsigned long long count_bad_contraction;
static unsigned long long count_simple_D;
static unsigned long long count_emitted;

static void die(const char *message)
{
    fprintf(stderr, "enumerate_core_duals: %s\n", message);
    exit(2);
}

static int read_byte(FILE *f)
{
    int c = getc(f);
    if (c == EOF && ferror(f)) die("input read error");
    return c;
}

/* Read one edge_code body.  Return 0 only at clean EOF. */
static int read_edge_record(FILE *f, unsigned char **body_out, size_t *size_out,
                            int *width_out)
{
    int first = read_byte(f), descriptor, k, width, i;
    size_t size = 0;
    unsigned char *body;

    if (first == EOF) return 0;
    if (first != 0)
    {
        size = (unsigned int)first;
        width = 1;
    }
    else
    {
        descriptor = read_byte(f);
        if (descriptor == EOF) die("truncated long edge_code header");
        k = descriptor >> 4;
        width = descriptor & 15;
        if (k < 1 || width < 1) die("invalid long edge_code header");
        for (i = 0; i < k; ++i)
        {
            int c = read_byte(f);
            if (c == EOF) die("truncated edge_code body length");
            size = (size << 8) | (unsigned int)c;
        }
    }
    body = (unsigned char *)malloc(size ? size : 1);
    if (!body) die("out of memory");
    if (fread(body, 1, size, f) != size) die("truncated edge_code body");
    *body_out = body;
    *size_out = size;
    *width_out = width;
    return 1;
}

static void decode_cubic(const unsigned char *body, size_t size, int width)
{
    size_t pos = 0;
    int v = 0, p = 0, eid, e, j;
    int occ_count[CE];

    if (width != 1) die("this certificate expects one-byte edge identifiers");
    memset(&cubic, 0, sizeof(cubic));
    memset(occ_count, 0, sizeof(occ_count));
    cubic.n = CV;
    cubic.m = CE;
    while (pos < size)
    {
        int c = body[pos++];
        if (c == 255)
        {
            if (v >= CV - 1 || p != 3) die("malformed cubic vertex section");
            cubic.deg[v++] = p;
            p = 0;
            continue;
        }
        if (v >= CV || p >= 3 || c < 0 || c >= CE)
            die("invalid cubic edge identifier or degree");
        eid = c;
        cubic.row[v][p] = eid;
        j = occ_count[eid]++;
        if (j >= 2) die("cubic edge occurs more than twice");
        cubic.occ_v[eid][j] = v;
        cubic.occ_p[eid][j] = p;
        ++p;
    }
    if (v != CV - 1 || p != 3) die("wrong number of cubic vertex sections");
    cubic.deg[v] = p;
    for (e = 0; e < CE; ++e)
        if (occ_count[e] != 2) die("cubic edge identifiers are not 0,...,20 twice");
}

/* Faces use phi=sigma^{-1} alpha (the predecessor at the opposite dart). */
static int map_faces(const Map *g, int face_of[MAXV][MAXDEG],
                     int *lengths, int max_faces)
{
    unsigned char seen[MAXV][MAXDEG];
    int v, p, f = 0;
    memset(seen, 0, sizeof(seen));
    for (v = 0; v < g->n; ++v)
        for (p = 0; p < g->deg[v]; ++p)
        {
            int cv, cp, len = 0;
            if (seen[v][p]) continue;
            if (f >= max_faces) return -1;
            cv = v; cp = p;
            do
            {
                int eid, side, nv, np;
                if (seen[cv][cp]) return -1;
                seen[cv][cp] = 1;
                face_of[cv][cp] = f;
                ++len;
                eid = g->row[cv][cp];
                if (g->occ_v[eid][0] == cv && g->occ_p[eid][0] == cp)
                    side = 1;
                else if (g->occ_v[eid][1] == cv && g->occ_p[eid][1] == cp)
                    side = 0;
                else return -1;
                nv = g->occ_v[eid][side];
                np = g->occ_p[eid][side];
                cp = (np + g->deg[nv] - 1) % g->deg[nv];
                cv = nv;
            }
            while (cv != v || cp != p);
            lengths[f++] = len;
        }
    return f;
}

static void prepare_cubic_faces(void)
{
    int e, nf = map_faces(&cubic, c_face_of, c_face_len, CF + 1);
    if (nf != CF) die("input cubic rotation is not a connected spherical map");
    for (e = 0; e < CE; ++e)
    {
        c_edge_face[e][0] = c_face_of[cubic.occ_v[e][0]][cubic.occ_p[e][0]];
        c_edge_face[e][1] = c_face_of[cubic.occ_v[e][1]][cubic.occ_p[e][1]];
    }
}

static int int_compare(const void *aa, const void *bb)
{
    const int a = *(const int *)aa, b = *(const int *)bb;
    return (a > b) - (a < b);
}

static int necessary_face_dominance(int base_len[CF])
{
    static const int sorted_target[CF] = {3,4,6,6,6,6,6,6,9};
    int copy[CF], i;
    memcpy(copy, base_len, sizeof(copy));
    qsort(copy, CF, sizeof(int), int_compare);
    for (i = 0; i < CF; ++i)
        if (copy[i] > sorted_target[i]) return 0;
    return 1;
}

/* Contract the current matching, retaining every unmatched edge dart. */
static int build_base_map(int matching_size)
{
    int new_of[CV], old_to_new_edge[CE];
    int v, w, e, p, nv = 0, ne = 0;
    int occ_count[CE];
    int face_of[MAXV][MAXDEG], lens[CF + 1], nf, i;

    (void)matching_size;
    memset(&base_map, 0, sizeof(base_map));
    memset(new_of, -1, sizeof(new_of));
    memset(old_to_new_edge, -1, sizeof(old_to_new_edge));
    memset(occ_count, 0, sizeof(occ_count));

    for (v = 0; v < CV; ++v)
    {
        e = mate_edge[v];
        if (e < 0)
            new_of[v] = nv++;
        else
        {
            w = cubic.occ_v[e][0] == v ? cubic.occ_v[e][1]
                                            : cubic.occ_v[e][0];
            if (new_of[v] < 0 && new_of[w] < 0)
                new_of[v] = new_of[w] = nv++;
            else if (new_of[v] < 0) new_of[v] = new_of[w];
            else if (new_of[w] < 0) new_of[w] = new_of[v];
        }
    }
    for (e = 0; e < CE; ++e)
        if (!chosen[e])
        {
            old_to_new_edge[e] = ne;
            base_old_edges[ne++] = e;
        }
    base_edge_count = ne;
    base_map.n = nv;
    base_map.m = ne;

    for (v = 0; v < CV; ++v)
    {
        int dst = new_of[v];
        e = mate_edge[v];
        if (e < 0)
        {
            int d = 0;
            for (p = 0; p < 3; ++p)
                base_map.row[dst][d++] = old_to_new_edge[cubic.row[v][p]];
            base_map.deg[dst] = d;
        }
        else
        {
            int other = cubic.occ_v[e][0] == v ? cubic.occ_v[e][1]
                                                    : cubic.occ_v[e][0];
            int pe_v, pe_w, d = 0;
            if (v > other) continue;
            pe_v = cubic.row[v][0] == e ? 0 : (cubic.row[v][1] == e ? 1 : 2);
            pe_w = cubic.row[other][0] == e ? 0
                  : (cubic.row[other][1] == e ? 1 : 2);
            /* Cross-splicing the two sigma cycles gives the two after-e
               blocks in this order. */
            for (i = 1; i <= 2; ++i)
                base_map.row[dst][d++] =
                    old_to_new_edge[cubic.row[v][(pe_v + i) % 3]];
            for (i = 1; i <= 2; ++i)
                base_map.row[dst][d++] =
                    old_to_new_edge[cubic.row[other][(pe_w + i) % 3]];
            base_map.deg[dst] = d;
        }
    }

    for (v = 0; v < base_map.n; ++v)
        for (p = 0; p < base_map.deg[v]; ++p)
        {
            e = base_map.row[v][p];
            i = occ_count[e]++;
            if (i >= 2) return 0;
            base_map.occ_v[e][i] = v;
            base_map.occ_p[e][i] = p;
        }
    for (e = 0; e < base_map.m; ++e)
        if (occ_count[e] != 2) return 0;

    nf = map_faces(&base_map, face_of, lens, CF + 1);
    if (nf != CF) return 0;
    {
        int actual[CF], expected[CF];
        memcpy(actual, lens, sizeof(actual));
        for (i = 0; i < CF; ++i)
            expected[i] = c_face_len[i] - matched_face_count[i];
        qsort(actual, CF, sizeof(int), int_compare);
        qsort(expected, CF, sizeof(int), int_compare);
        if (memcmp(actual, expected, sizeof(actual)) != 0) return 0;
    }
    return 1;
}

static uint64_t key_hash(const unsigned char key[D_RECORD_SIZE])
{
    uint64_t h = UINT64_C(1469598103934665603);
    int i;
    for (i = 0; i < D_RECORD_SIZE; ++i)
    {
        h ^= key[i];
        h *= UINT64_C(1099511628211);
    }
    return h ? h : 1;
}

static void dedup_grow(void)
{
    size_t oldcap = dedup_capacity, i, pos;
    uint64_t *oldhash = dedup_hash;
    unsigned char *oldkey = dedup_key;
    dedup_capacity = oldcap ? 2 * oldcap : 65536;
    dedup_hash = (uint64_t *)calloc(dedup_capacity, sizeof(uint64_t));
    dedup_key = (unsigned char *)malloc(dedup_capacity * D_RECORD_SIZE);
    if (!dedup_hash || !dedup_key) die("out of memory in canonical deduplication");
    if (oldcap)
    {
        for (i = 0; i < oldcap; ++i)
            if (oldhash[i])
            {
                pos = (size_t)oldhash[i] & (dedup_capacity - 1);
                while (dedup_hash[pos]) pos = (pos + 1) & (dedup_capacity - 1);
                dedup_hash[pos] = oldhash[i];
                memcpy(dedup_key + pos * D_RECORD_SIZE,
                       oldkey + i * D_RECORD_SIZE, D_RECORD_SIZE);
            }
        free(oldhash);
        free(oldkey);
    }
}

/* Return 1 precisely for a key not seen before. */
static int dedup_insert(const unsigned char key[D_RECORD_SIZE])
{
    uint64_t h;
    size_t pos;
    if (!dedup_capacity || 10 * (dedup_used + 1) > 7 * dedup_capacity)
        dedup_grow();
    h = key_hash(key);
    pos = (size_t)h & (dedup_capacity - 1);
    while (dedup_hash[pos])
    {
        if (dedup_hash[pos] == h &&
            memcmp(dedup_key + pos * D_RECORD_SIZE, key, D_RECORD_SIZE) == 0)
            return 0;
        pos = (pos + 1) & (dedup_capacity - 1);
    }
    dedup_hash[pos] = h;
    memcpy(dedup_key + pos * D_RECORD_SIZE, key, D_RECORD_SIZE);
    ++dedup_used;
    return 1;
}

/* Canonical planar_code of a connected simple embedded graph.  A directed
   root dart and a global orientation determine BFS labels and a starting
   dart in every cyclic row.  Minimising over all 2E roots and both mirror
   orientations is an isomorphism invariant and is complete for plane maps. */
static void canonical_planar_record(const Map *g,
                                    unsigned char best[D_RECORD_SIZE])
{
    int rv, rp, dir, have_best = 0;
    for (rv = 0; rv < g->n; ++rv)
        for (rp = 0; rp < g->deg[rv]; ++rp)
            for (dir = -1; dir <= 1; dir += 2)
            {
                int label[MAXV], vertex[MAXV], start[MAXV];
                unsigned char code[D_RECORD_SIZE];
                int next_label = 0, q, pos = 0, i, ov, op, e, side, w, wp;
                memset(label, -1, sizeof(label));
                label[rv] = next_label;
                vertex[next_label++] = rv;
                start[rv] = rp;
                for (q = 0; q < next_label; ++q)
                {
                    ov = vertex[q];
                    op = start[ov];
                    for (i = 0; i < g->deg[ov]; ++i)
                    {
                        int pp = (op + dir * i) % g->deg[ov];
                        if (pp < 0) pp += g->deg[ov];
                        e = g->row[ov][pp];
                        if (g->occ_v[e][0] == ov && g->occ_p[e][0] == pp)
                            side = 1;
                        else side = 0;
                        w = g->occ_v[e][side];
                        wp = g->occ_p[e][side];
                        if (label[w] < 0)
                        {
                            label[w] = next_label;
                            vertex[next_label++] = w;
                            start[w] = wp;
                        }
                    }
                }
                if (next_label != g->n) die("canonicalisation saw disconnected D");
                code[pos++] = (unsigned char)g->n;
                for (q = 0; q < g->n; ++q)
                {
                    ov = vertex[q];
                    op = start[ov];
                    for (i = 0; i < g->deg[ov]; ++i)
                    {
                        int pp = (op + dir * i) % g->deg[ov];
                        if (pp < 0) pp += g->deg[ov];
                        e = g->row[ov][pp];
                        if (g->occ_v[e][0] == ov && g->occ_p[e][0] == pp)
                            side = 1;
                        else side = 0;
                        w = g->occ_v[e][side];
                        code[pos++] = (unsigned char)(label[w] + 1);
                    }
                    code[pos++] = 0;
                }
                if (pos != D_RECORD_SIZE) die("canonical planar record size error");
                if (!have_best || memcmp(code, best, D_RECORD_SIZE) < 0)
                {
                    memcpy(best, code, D_RECORD_SIZE);
                    have_best = 1;
                }
            }
}

static int has_exact_patch(void);

static int validate_and_emit_final(void)
{
    int chain_first[CE], chain_last[CE];
    int v, p, be, olde, t, i, e, nv, ne = 0;
    int occ_count[MAXE], face_of[MAXV][MAXDEG], lens[CF + 1], nf;
    int pair_seen[MAXV][MAXV];
    int sorted_lens[CF], expected[CF] = {3,4,6,6,6,6,6,6,9};
    unsigned char record[D_RECORD_SIZE];

    memset(&final_map, 0, sizeof(final_map));
    memset(occ_count, 0, sizeof(occ_count));
    memset(pair_seen, 0, sizeof(pair_seen));
    final_map.n = DV;
    final_map.m = DE;
    nv = base_map.n;

    /* Allocate each subdivided chain and remember its two endpoint edges. */
    for (be = 0; be < base_map.m; ++be)
    {
        olde = base_old_edges[be];
        t = subdivision[olde];
        chain_first[be] = ne;
        chain_last[be] = ne + t;
        ne += t + 1;
    }
    if (ne != DE) return 0;

    /* Original core rotations, with each dart replaced by its chain end. */
    for (v = 0; v < base_map.n; ++v)
    {
        final_map.deg[v] = base_map.deg[v];
        for (p = 0; p < base_map.deg[v]; ++p)
        {
            be = base_map.row[v][p];
            if (base_map.occ_v[be][0] == v && base_map.occ_p[be][0] == p)
            {
                final_map.row[v][p] = chain_first[be];
            }
            else
            {
                final_map.row[v][p] = chain_last[be];
            }
        }
    }
    /* Degree-two vertices along every core edge. */
    for (be = 0; be < base_map.m; ++be)
    {
        olde = base_old_edges[be];
        t = subdivision[olde];
        for (i = 0; i < t; ++i)
        {
            if (nv >= DV) return 0;
            final_map.deg[nv] = 2;
            final_map.row[nv][0] = chain_first[be] + i;
            final_map.row[nv][1] = chain_first[be] + i + 1;
            ++nv;
        }
    }
    if (nv != DV) return 0;

    for (v = 0; v < DV; ++v)
        for (p = 0; p < final_map.deg[v]; ++p)
        {
            e = final_map.row[v][p];
            if (e < 0 || e >= DE) return 0;
            i = occ_count[e]++;
            if (i >= 2) return 0;
            final_map.occ_v[e][i] = v;
            final_map.occ_p[e][i] = p;
        }
    for (e = 0; e < DE; ++e)
    {
        int u, w;
        if (occ_count[e] != 2) return 0;
        u = final_map.occ_v[e][0];
        w = final_map.occ_v[e][1];
        if (u == w) return 0;
        if (u > w) { int tmp = u; u = w; w = tmp; }
        if (pair_seen[u][w]) return 0;
        pair_seen[u][w] = 1;
    }

    nf = map_faces(&final_map, face_of, lens, CF + 1);
    if (nf != CF) return 0;
    memcpy(sorted_lens, lens, sizeof(sorted_lens));
    qsort(sorted_lens, CF, sizeof(int), int_compare);
    if (memcmp(sorted_lens, expected, sizeof(expected)) != 0) return 0;

    /* The graph is connected because it is obtained from connected C by
       non-loop contractions and subdivisions.  Euler was checked by the
       nine facial orbits above. */
    ++count_simple_D;
#ifdef CORE_EMIT_SIMPLE_SUPERSET
    canonical_planar_record(&final_map, record);
    if (dedup_insert(record))
    {
        if (fwrite(record, 1, D_RECORD_SIZE, out_file) != D_RECORD_SIZE)
            die("output write error");
        ++count_emitted;
    }
    return 1;
#endif
    if (!has_exact_patch()) return 1;
    canonical_planar_record(&final_map, record);
    if (dedup_insert(record))
    {
        if (fwrite(record, 1, D_RECORD_SIZE, out_file) != D_RECORD_SIZE)
            die("output write error");
        ++count_emitted;
    }
    return 1;
}

/* Necessary abstract condition for a simple patch expansion of P=D*.  A
   target face of length 9 expands to five bowtie vertices, a length-6 face
   to three triangle vertices, and the length-4/3 faces to one vertex each.
   A core edge with t subdivisions becomes t+1 parallel P edges.  Loops can
   survive only at the bowtie core (and there only in its four cross-lobe
   nonedges); between distinct cores there are at most |patch_i||patch_j|
   different endpoint pairs.  This deliberately ignores rotations, so it
   is a safe over-approximation. */
static int patch_capacity_possible(void)
{
    int multiplicity[CF][CF], size[CF];
    int be, olde, f, g, amount, i, j;
    memset(multiplicity, 0, sizeof(multiplicity));
    for (i = 0; i < CF; ++i)
        size[i] = target_len[i] == 9 ? 5 : (target_len[i] == 6 ? 3 : 1);
    for (be = 0; be < base_map.m; ++be)
    {
        olde = base_old_edges[be];
        f = c_edge_face[olde][0];
        g = c_edge_face[olde][1];
        amount = subdivision[olde] + 1;
        if (f > g) { int tmp = f; f = g; g = tmp; }
        multiplicity[f][g] += amount;
    }
    for (i = 0; i < CF; ++i)
    {
        if (multiplicity[i][i])
        {
            if (target_len[i] != 9 || multiplicity[i][i] > 4) return 0;
        }
        for (j = i + 1; j < CF; ++j)
            if (multiplicity[i][j] > size[i] * size[j]) return 0;
    }
    return 1;
}

/* A run of t subdivision vertices produces t consecutive P-digons.  At
   each digon the two endpoint corner costs must sum to two.  This routine
   maximises the possible complementary run over both cyclic starts and
   both directions, deliberately ignoring all other phase constraints.
   kind 0 is a singleton patch (all costs zero), kind 1 a triangle, and
   kind 2 the bowtie. */
static int complementary_window_bound(int kind1, int kind2)
{
    static int cache[3][3]={{-1,-1,-1},{-1,-1,-1},{-1,-1,-1}};
    static const int singleton[1]={0};
    static const int triangle[6]={1,0,1,0,1,0};
    static const int bowtie[9]={1,1,0,1,0,2,0,1,0};
    const int *s1 = kind1==2 ? bowtie : (kind1==1 ? triangle : singleton);
    const int *s2 = kind2==2 ? bowtie : (kind2==1 ? triangle : singleton);
    int n1=kind1==2?9:(kind1==1?6:1);
    int n2=kind2==2?9:(kind2==1?6:1);
    int a,b,d1,d2,len,best=0,limit=2*n1*n2;
    if(cache[kind1][kind2]>=0)return cache[kind1][kind2];
    for(a=0;a<n1;++a)for(b=0;b<n2;++b)
        for(d1=-1;d1<=1;d1+=2)for(d2=-1;d2<=1;d2+=2)
        {
            for(len=0;len<limit;++len)
            {
                int i=(a+d1*len)%n1,j=(b+d2*len)%n2;
                if(i<0)i+=n1;
                if(j<0)j+=n2;
                if(s1[i]+s2[j]!=2)break;
            }
            if(len==limit)
            {
                cache[kind1][kind2]=cache[kind2][kind1]=1000;
                return 1000; /* a periodic unbounded run */
            }
            if(len>best)best=len;
        }
    cache[kind1][kind2]=cache[kind2][kind1]=best;
    return best;
}

/* Build P=D* with sigma_P equal to the D facial permutation.  Edge ids and
   both occurrences are retained, so a bridge of D becomes a genuine loop
   of P rather than being collapsed in a neighbour-list representation. */
static int build_dual_P(int pdeg[CF], int prow[CF][9])
{
    unsigned char seen[MAXV][MAXDEG];
    int v, p, f = 0;
    memset(seen, 0, sizeof(seen));
    for (v = 0; v < final_map.n; ++v)
        for (p = 0; p < final_map.deg[v]; ++p)
        {
            int cv, cp, len = 0;
            if (seen[v][p]) continue;
            if (f >= CF) return 0;
            cv = v; cp = p;
            do
            {
                int eid, side, nv, np;
                if (seen[cv][cp] || len >= 9) return 0;
                seen[cv][cp] = 1;
                eid = final_map.row[cv][cp];
                prow[f][len++] = eid;
                if (final_map.occ_v[eid][0] == cv &&
                    final_map.occ_p[eid][0] == cp) side = 1;
                else side = 0;
                nv = final_map.occ_v[eid][side];
                np = final_map.occ_p[eid][side];
                cv = nv;
                cp = (np + final_map.deg[nv] - 1) % final_map.deg[nv];
            }
            while (cv != v || cp != p);
            pdeg[f++] = len;
        }
    return f == CF;
}

static void r_put_row(int vertex, int degree, const int *items,
                      int rdeg[25], int rrow[25][5])
{
    int i;
    rdeg[vertex] = degree;
    for (i = 0; i < degree; ++i) rrow[vertex][i] = items[i];
}

/* Test one of the 576 inverse patch parameters.  This is only a generator
   filter; the Python verifier repeats the construction independently. */
static int exact_patch_phase(const int pdeg[CF], const int prow[CF][9],
                             int singleton, int phase_mask)
{
    int high = -1, av = -1, zv = -1, tri[6], nt = 0;
    int rdeg[25], rrow[25][5], occ_v[50][2], occ_p[50][2], occ_count[50];
    int i, j, core, phase, s, nextv = 0, nexte = 26;
    int q, a, z, row[5], ext[6];
    int pair_seen[25][25];
    unsigned char seen[25][5];
    int tau[25], faces3 = 0, faces4 = 0;

    for (i = 0; i < CF; ++i)
    {
        if (pdeg[i] == 9) high = i;
        else if (pdeg[i] == 6)
        {
            if (nt >= 6) return 0;
            tri[nt++] = i;
        }
        else if (pdeg[i] == 4) av = i;
        else if (pdeg[i] == 3) zv = i;
        else return 0;
    }
    if (high < 0 || av < 0 || zv < 0 || nt != 6) return 0;
    memset(rdeg, 0, sizeof(rdeg));
    memset(rrow, 0, sizeof(rrow));

    /* Bowtie: external cyclic order U,U,V,V,s,X,X,Y,Y. */
    s = singleton;
    {
        int qu = nexte++, qv = nexte++, qx = nexte++, qy = nexte++;
        int uv = nexte++, xy = nexte++;
        int U, V, X, Y;
        q = nextv++;
        U = nextv++; V = nextv++; X = nextv++; Y = nextv++;
        row[0]=qu; row[1]=qv; row[2]=prow[high][s]; row[3]=qx; row[4]=qy;
        r_put_row(q,5,row,rdeg,rrow);
        row[0]=uv; row[1]=qu; row[2]=prow[high][(s+5)%9];
        row[3]=prow[high][(s+6)%9]; r_put_row(U,4,row,rdeg,rrow);
        row[0]=qv; row[1]=uv; row[2]=prow[high][(s+7)%9];
        row[3]=prow[high][(s+8)%9]; r_put_row(V,4,row,rdeg,rrow);
        row[0]=xy; row[1]=qx; row[2]=prow[high][(s+1)%9];
        row[3]=prow[high][(s+2)%9]; r_put_row(X,4,row,rdeg,rrow);
        row[0]=qy; row[1]=xy; row[2]=prow[high][(s+3)%9];
        row[3]=prow[high][(s+4)%9]; r_put_row(Y,4,row,rdeg,rrow);
    }

    for (i = 0; i < 6; ++i)
    {
        int A=nextv++,B=nextv++,C=nextv++;
        int ab=nexte++,ac=nexte++,bc=nexte++;
        core=tri[i]; phase=(phase_mask>>i)&1;
        for(j=0;j<6;++j) ext[j]=prow[core][(phase+j)%6];
        row[0]=ab;row[1]=ac;row[2]=ext[0];row[3]=ext[1];
        r_put_row(A,4,row,rdeg,rrow);
        row[0]=bc;row[1]=ab;row[2]=ext[2];row[3]=ext[3];
        r_put_row(B,4,row,rdeg,rrow);
        row[0]=ac;row[1]=bc;row[2]=ext[4];row[3]=ext[5];
        r_put_row(C,4,row,rdeg,rrow);
    }
    a=nextv++; r_put_row(a,4,prow[av],rdeg,rrow);
    z=nextv++; r_put_row(z,3,prow[zv],rdeg,rrow);
    if(nextv!=25 || nexte!=50) return 0;

    memset(occ_count,0,sizeof(occ_count));
    for(i=0;i<25;++i)for(j=0;j<rdeg[i];++j)
    {
        int e=rrow[i][j], side;
        if(e<0 || e>=50) return 0;
        side=occ_count[e]++;
        if(side>=2)return 0;
        occ_v[e][side]=i;occ_p[e][side]=j;
    }
    memset(pair_seen,0,sizeof(pair_seen));
    for(i=0;i<50;++i)
    {
        int u,w;
        if(occ_count[i]!=2)return 0;
        u=occ_v[i][0];w=occ_v[i][1];
        if(u==w)return 0;
        if(u>w){int tmp=u;u=w;w=tmp;}
        if(pair_seen[u][w])return 0;
        pair_seen[u][w]=1;
    }

    memset(seen,0,sizeof(seen));
    memset(tau,0,sizeof(tau));
    for(i=0;i<25;++i)for(j=0;j<rdeg[i];++j)
    {
        int cv,cp,len=0,verts[8],k;
        if(seen[i][j])continue;
        cv=i;cp=j;
        do
        {
            int e,side,nv,np;
            if(seen[cv][cp] || len>=8)return 0;
            seen[cv][cp]=1;verts[len++]=cv;
            e=rrow[cv][cp];
            if(occ_v[e][0]==cv && occ_p[e][0]==cp)side=1;else side=0;
            nv=occ_v[e][side];np=occ_p[e][side];
            cv=nv;cp=(np+rdeg[nv]-1)%rdeg[nv];
        }while(cv!=i || cp!=j);
        if(len!=3 && len!=4)return 0;
        for(k=0;k<len;++k)
        {
            int l;
            for(l=k+1;l<len;++l)if(verts[k]==verts[l])return 0;
        }
        if(len==3){++faces3;for(k=0;k<3;++k)++tau[verts[k]];}
        else ++faces4;
    }
    if(faces3!=8 || faces4!=19)return 0;
    if(rdeg[q]!=5 || tau[q]!=2 || rdeg[a]!=4 || tau[a]!=0 ||
       rdeg[z]!=3 || tau[z]!=0)return 0;
    for(i=0;i<25;++i)
        if(i!=q && i!=a && i!=z && (rdeg[i]!=4 || tau[i]!=1))return 0;
    return 1;
}

static int has_exact_patch(void)
{
    static const int bow_corner[9]={1,1,0,1,0,2,0,1,0};
    int pdeg[CF], prow[CF][9], s, mask, found=0;
    int occ_v[DE][2],occ_p[DE][2],occ_count[DE];
    int high=-1,tri[6],tri_index[CF],nt=0;
    int need[DV],bcost[DV][9],tcost[DV][6][2];
    unsigned char seen[CF][9];
    int i,j,e,side,f=0;
    if(!build_dual_P(pdeg,prow))return 0;
    memset(occ_count,0,sizeof(occ_count));
    memset(tri_index,-1,sizeof(tri_index));
    for(i=0;i<CF;++i)
    {
        if(pdeg[i]==9)high=i;
        else if(pdeg[i]==6){tri[nt]=i;tri_index[i]=nt++;}
        for(j=0;j<pdeg[i];++j)
        {
            e=prow[i][j];side=occ_count[e]++;
            if(side>=2)return 0;
            occ_v[e][side]=i;occ_p[e][side]=j;
        }
    }
    if(high<0 || nt!=6)return 0;
    for(e=0;e<DE;++e)if(occ_count[e]!=2)return 0;
    (void)tri;
    memset(seen,0,sizeof(seen));
    memset(bcost,0,sizeof(bcost));
    memset(tcost,0,sizeof(tcost));
    for(i=0;i<CF;++i)for(j=0;j<pdeg[i];++j)
    {
        int cv,cp,len=0;
        if(seen[i][j])continue;
        if(f>=DV)return 0;
        cv=i;cp=j;
        do
        {
            int nv,np,k,t;
            if(seen[cv][cp])return 0;
            seen[cv][cp]=1;++len;
            e=prow[cv][cp];
            if(occ_v[e][0]==cv && occ_p[e][0]==cp)side=1;else side=0;
            nv=occ_v[e][side];np=occ_p[e][side];
            if(nv==high)
                for(k=0;k<9;++k)bcost[f][k]+=bow_corner[(np-k+9)%9];
            else if((t=tri_index[nv])>=0)
            {
                tcost[f][t][0]+=(np%2==0);
                tcost[f][t][1]+=(np%2==1);
            }
            cv=nv;cp=(np+pdeg[nv]-1)%pdeg[nv];
        }
        while(cv!=i || cp!=j);
        need[f]=4-len;
        if(need[f]<0)return 0;
        ++f;
    }
    if(f!=DV)return 0;

    for(s=0;s<9;++s)for(mask=0;mask<64;++mask)
    {
        for(f=0;f<DV;++f)
        {
            int cost=bcost[f][s];
            for(i=0;i<6;++i)cost+=tcost[f][i][(mask>>i)&1];
            if(cost!=need[f])break;
        }
        if(f==DV && exact_patch_phase(pdeg,(const int (*)[9])prow,s,mask))
        {
            ++count_exact_patch_phases;
            found=1;
        }
    }
    if(found)++count_D_with_exact_patch;
    return found;
}

static void solve_face_system(void);

static void assign_incident_edges(int face, const int *list, int nlist, int at)
{
    int e, olde, f, g, coeff, maxx, x;
    if (at == nlist)
    {
        if (remainder_face[face] == 0) solve_face_system();
        return;
    }
    e = list[at];
    olde = base_old_edges[e];
    f = c_edge_face[olde][0];
    g = c_edge_face[olde][1];
    coeff = (f == g) ? 2 : 1;
    maxx = remainder_face[face] / coeff;
    if (subdivision_upper[olde] < maxx) maxx = subdivision_upper[olde];
    if (f != g)
    {
        int other = f == face ? g : f;
        if (remainder_face[other] < maxx) maxx = remainder_face[other];
    }
    for (x = 0; x <= maxx; ++x)
    {
        subdivision[olde] = x;
        assigned[e] = 1;
        if (f == g) remainder_face[f] -= 2 * x;
        else { remainder_face[f] -= x; remainder_face[g] -= x; }
        assign_incident_edges(face, list, nlist, at + 1);
        if (f == g) remainder_face[f] += 2 * x;
        else { remainder_face[f] += x; remainder_face[g] += x; }
        assigned[e] = 0;
        subdivision[olde] = 0;
    }
}

/* Eliminate one face at a time.  Once a face is selected, all still-free
   variables incident with it are assigned together, so every nonnegative
   solution is reached once. */
static void solve_face_system(void)
{
    int f, e, olde, a, b, list[CE], nlist;
    int best_face = -1, best_count = 1000;

    for (f = 0; f < CF; ++f)
    {
        nlist = 0;
        for (e = 0; e < base_map.m; ++e)
        {
            if (assigned[e]) continue;
            olde = base_old_edges[e];
            a = c_edge_face[olde][0];
            b = c_edge_face[olde][1];
            if (a == f || b == f) ++nlist;
        }
        if (nlist == 0)
        {
            if (remainder_face[f] != 0) return;
            continue;
        }
        if (nlist < best_count ||
            (nlist == best_count && best_face >= 0 &&
             remainder_face[f] < remainder_face[best_face]))
        {
            best_face = f;
            best_count = nlist;
        }
    }
    if (best_face < 0)
    {
        for (f = 0; f < CF; ++f)
            if (remainder_face[f] != 0) return;
        ++count_subdivision_solutions;
        if (!patch_capacity_possible()) return;
        ++count_capacity_possible;
        validate_and_emit_final();
        return;
    }
    nlist = 0;
    for (e = 0; e < base_map.m; ++e)
    {
        if (assigned[e]) continue;
        olde = base_old_edges[e];
        a = c_edge_face[olde][0];
        b = c_edge_face[olde][1];
        if (a == best_face || b == best_face) list[nlist++] = e;
    }
    assign_incident_edges(best_face, list, nlist, 0);
}

static void process_matching(int matching_size)
{
    int base_len[CF], f9, f4, f3, f, e;
    static const int sorted_target[CF] = {3,4,6,6,6,6,6,6,9};
    (void)sorted_target;
    ++count_matchings;
    for (f = 0; f < CF; ++f)
        base_len[f] = c_face_len[f] - matched_face_count[f];
    if (!necessary_face_dominance(base_len)) return;
    ++count_dominance;
    if (!build_base_map(matching_size))
    {
        ++count_bad_contraction;
        return;
    }

    for (f9 = 0; f9 < CF; ++f9)
        for (f4 = 0; f4 < CF; ++f4)
        {
            if (f4 == f9) continue;
            for (f3 = 0; f3 < CF; ++f3)
            {
                if (f3 == f9 || f3 == f4) continue;
                for (f = 0; f < CF; ++f) target_len[f] = 6;
                target_len[f9] = 9;
                target_len[f4] = 4;
                target_len[f3] = 3;
                for (f = 0; f < CF; ++f)
                    if (base_len[f] > target_len[f]) break;
                if (f < CF) continue;
                ++count_assignments;
                {
                    int base_mult[CF][CF], patch_size[CF], patch_kind[CF];
                    int be, olde, x, y, cap, slack, impossible=0;
                    memset(base_mult,0,sizeof(base_mult));
                    for(f=0;f<CF;++f)
                    {
                        if(target_len[f]==9){patch_size[f]=5;patch_kind[f]=2;}
                        else if(target_len[f]==6){patch_size[f]=3;patch_kind[f]=1;}
                        else {patch_size[f]=1;patch_kind[f]=0;}
                    }
                    for(be=0;be<base_map.m;++be)
                    {
                        olde=base_old_edges[be];
                        x=c_edge_face[olde][0];y=c_edge_face[olde][1];
                        if(x>y){int tmp=x;x=y;y=tmp;}
                        ++base_mult[x][y];
                    }
                    for(x=0;x<CF;++x)for(y=x;y<CF;++y)
                    {
                        if(x==y)cap=(target_len[x]==9)?4:0;
                        else cap=patch_size[x]*patch_size[y];
                        if(base_mult[x][y]>cap)impossible=1;
                    }
                    if(impossible)continue;
                    memset(subdivision_upper,0,sizeof(subdivision_upper));
                    for(be=0;be<base_map.m;++be)
                    {
                        olde=base_old_edges[be];
                        x=c_edge_face[olde][0];y=c_edge_face[olde][1];
                        if(x>y){int tmp=x;x=y;y=tmp;}
                        if(x==y)cap=(target_len[x]==9)?4:0;
                        else cap=patch_size[x]*patch_size[y];
                        slack=cap-base_mult[x][y];
                        /* Consecutive inserted vertices give consecutive
                           complementary corner-cost constraints. */
                        {
                            int window=complementary_window_bound(
                                patch_kind[x],patch_kind[y]);
                            if(window<slack)slack=window;
                        }
                        subdivision_upper[olde]=slack;
                    }
                    {
                        int total_upper=0;
                        for(be=0;be<base_map.m;++be)
                            total_upper+=subdivision_upper[base_old_edges[be]];
                        if(total_upper<matching_size+5)impossible=1;
                    }
                    for(f=0;f<CF && !impossible;++f)
                    {
                        int face_upper=0;
                        for(be=0;be<base_map.m;++be)
                        {
                            olde=base_old_edges[be];
                            x=c_edge_face[olde][0];y=c_edge_face[olde][1];
                            if(x==f)face_upper+=subdivision_upper[olde];
                            if(y==f)face_upper+=subdivision_upper[olde];
                        }
                        if(face_upper<target_len[f]-base_len[f])impossible=1;
                    }
                    if(impossible)continue;
                }
                for (f = 0; f < CF; ++f)
                    remainder_face[f] = target_len[f] - base_len[f];
                memset(assigned, 0, sizeof(assigned));
                memset(subdivision, 0, sizeof(subdivision));
                for (e = 0; e < CE; ++e)
                    if (chosen[e]) subdivision[e] = -1;
                solve_face_system();
            }
        }
}

static void enumerate_matchings(uint32_t available, int matching_size)
{
    int u, p, e, a, b, v, f, g;
    uint32_t bit;
    if (available == 0)
    {
        process_matching(matching_size);
        return;
    }
    bit = available & (uint32_t)(-(int32_t)available);
    u = 0;
    while (((uint32_t)1 << u) != bit) ++u;

    /* u is unmatched. */
    enumerate_matchings(available & ~bit, matching_size);

    /* u is matched through each distinct non-loop incident edge. */
    for (p = 0; p < 3; ++p)
    {
        e = cubic.row[u][p];
        a = cubic.occ_v[e][0];
        b = cubic.occ_v[e][1];
        if (a == b) continue;
        v = a == u ? b : a;
        if ((available & ((uint32_t)1 << v)) == 0) continue;
        chosen[e] = 1;
        mate_edge[u] = mate_edge[v] = e;
        f = c_edge_face[e][0];
        g = c_edge_face[e][1];
        ++matched_face_count[f];
        ++matched_face_count[g];
        enumerate_matchings(available & ~bit & ~((uint32_t)1 << v),
                            matching_size + 1);
        --matched_face_count[f];
        --matched_face_count[g];
        mate_edge[u] = mate_edge[v] = -1;
        chosen[e] = 0;
    }
}

int main(int argc, char **argv)
{
    static const unsigned char header[] = ">>edge_code<<";
    unsigned char input_header[sizeof(header) - 1];
    unsigned char *body;
    size_t size;
    int width;
    long limit = -1;
    int limited = argc == 4;
    FILE *in;

    if (argc < 3 || argc > 4)
    {
        fprintf(stderr, "usage: %s cubic14.ec core_duals.plc [record-limit]\n",
                argv[0]);
        return 2;
    }
    if (argc == 4)
    {
        char *end;
        errno = 0;
        limit = strtol(argv[3], &end, 10);
        if (errno || *end || limit < 0) die("invalid nonnegative record limit");
    }
    in = fopen(argv[1], "rb");
    if (!in) die("cannot open input edge_code");
    out_file = fopen(argv[2], "wb");
    if (!out_file) die("cannot open output edge_code");
    if (fread(input_header, 1, sizeof(input_header), in) != sizeof(input_header)
        || memcmp(input_header, header, sizeof(input_header)) != 0)
        die("missing >>edge_code<< input header");
    if (fwrite(">>planar_code<<", 1, 15, out_file) != 15)
        die("cannot write output header");

    while ((limit < 0 || (long)count_input < limit) &&
           read_edge_record(in, &body, &size, &width))
    {
        decode_cubic(body, size, width);
        free(body);
        prepare_cubic_faces();
        memset(chosen, 0, sizeof(chosen));
        memset(matched_face_count, 0, sizeof(matched_face_count));
        memset(mate_edge, -1, sizeof(mate_edge));
        ++count_input;
        enumerate_matchings(((uint32_t)1 << CV) - 1, 0);
        if ((count_input % 10000) == 0)
            fprintf(stderr, "progress input=%llu matchings=%llu emitted=%llu\n",
                    count_input, count_matchings, count_emitted);
    }
    if (!limited && count_input != EXPECTED_CUBIC_MAPS)
        die("full cubic catalogue count is not 152706");
    if (fclose(in) != 0 || fclose(out_file) != 0) die("file close error");
    fprintf(stderr,
      "input=%llu matchings=%llu dominance=%llu assignments=%llu "
      "subdivision_solutions=%llu bad_contraction=%llu simple_D=%llu "
      "capacity_possible=%llu exact_patch_phases=%llu "
      "D_with_exact_patch=%llu emitted=%llu\n",
      count_input, count_matchings, count_dominance, count_assignments,
      count_subdivision_solutions, count_bad_contraction, count_simple_D,
      count_capacity_possible,
      count_exact_patch_phases, count_D_with_exact_patch,
      count_emitted);
    free(dedup_hash);
    free(dedup_key);
    return 0;
}
