/*
 * Nineteen-vertex core generator for the two remaining n=25 cases in the
 * d=8 exact-bound proof.
 *
 * Compile beside official plantri 5.8:
 *
 *   cc -O3 -o plantri_core25 \
 *      -DPLUGIN=cert25_core_plugin.c plantri.c
 *   ./plantri_core25 -p -c1 -m2 -e26 -f9 19 core25.plc
 *
 * The output maps D are precisely the simple connected plane graphs with
 * 19 vertices, 26 edges, vertex degrees in {2,3,4}, and face multiset
 *
 *       3, 4, 6,6,6,6,6,6, 9.
 *
 * They are the plane duals of the nine-vertex pseudograph cores obtained by
 * contracting the eight edge-disjoint triangular faces (two sharing their
 * unique common vertex) of the common 25-vertex residual skeleton.
 *
 * PRE_FILTER_POLY uses only necessary monotone conditions.  In particular,
 * deleting a non-bridge plane edge merges two faces and preserves the sum
 * of (face_length-2), so the current face weights must pack into the nine
 * target capacities 1,2,4^6,7.  Connectivity of the merge parts is ignored,
 * hence this is an over-approximation and cannot discard a target.
 */

#define FILTER core25_filter
#define SUMMARY core25_summary
#define PRE_FILTER_POLY core25_pre_filter()
#define FAST_FILTER_POLY core25_pre_filter()

static unsigned long long core25_seen_final;
static unsigned long long core25_emitted;

static int
core25_scan_faces(int counts[10], int *nf_out)
{
    EDGE *e,*last,*p;
    int i,len,nf=0;

    for (i=0;i<10;++i) counts[i]=0;
    RESETMARKS;
    for (i=0;i<nv;++i)
    {
        e=last=firstedge[i];
        do
        {
            if (!ISMARKED(e))
            {
                len=0;
                p=e;
                do
                {
                    if (++len>9) return FALSE;
                    MARK(p);
                    p=p->invers->next;
                }
                while (p!=e);
                if (len<1 || len>9) return FALSE;
                ++counts[len];
                ++nf;
            }
            e=e->next;
        }
        while (e!=last);
    }
    *nf_out=nf;
    return TRUE;
}

/* Exact bin packing into capacities 7,4^6,2,1.  Items are face_length-2.
   Equal capacities are symmetry-pruned. */
static int
core25_pack_rec(const int items[40], int nitems, int at, int caps[9])
{
    int i,old=-1,w;
    if (at==nitems) return TRUE;
    w=items[at];
    for (i=0;i<9;++i)
    {
        if (caps[i]<w || caps[i]==old) continue;
        old=caps[i];
        caps[i]-=w;
        if (core25_pack_rec(items,nitems,at+1,caps)) return TRUE;
        caps[i]+=w;
    }
    return FALSE;
}

static int
core25_face_capacity_possible(const int counts[10], int nf)
{
    int items[40],caps[9]={7,4,4,4,4,4,4,2,1};
    int i,j,k=0;
    if (nf<9 || nf>34) return FALSE;
    for (i=9;i>=3;--i)
        for (j=0;j<counts[i];++j)
        {
            if (k>=40) return FALSE;
            items[k++]=i-2;
        }
    /* A cellular simple ancestor has no 1- or 2-faces. */
    if (counts[1] || counts[2] || k!=nf) return FALSE;
    return core25_pack_rec(items,k,0,caps);
}

static int
core25_pre_filter(void)
{
    int counts[10],nf,rem,i,excess=0;

    if (nv!=19) return TRUE;
    if (ne<52) return FALSE;
    rem=ne/2-26;
    if (rem<0) return FALSE;

    for (i=0;i<nv;++i)
    {
        if (degree[i]<2) return FALSE;
        if (degree[i]>4)
        {
            excess += degree[i]-4;
            if (degree[i]-4>rem) return FALSE;
        }
    }
    if (excess>2*rem) return FALSE;
    if (!core25_scan_faces(counts,&nf)) return FALSE;
    return core25_face_capacity_possible(counts,nf);
}

static int
core25_filter(int nbtot, int nbop, int doflip)
{
    int counts[10],nf,i;
    (void)nbtot;(void)nbop;(void)doflip;

    if (nv!=19 || ne!=52) return FALSE;
    ++core25_seen_final;
    for (i=0;i<nv;++i)
        if (degree[i]<2 || degree[i]>4) return FALSE;
    if (!core25_scan_faces(counts,&nf) || nf!=9) return FALSE;
    if (counts[3]!=1 || counts[4]!=1 || counts[6]!=6
        || counts[9]!=1) return FALSE;
    for (i=1;i<=9;++i)
        if (i!=3 && i!=4 && i!=6 && i!=9 && counts[i]) return FALSE;
    ++core25_emitted;
    return TRUE;
}

static void
core25_summary(void)
{
    fprintf(msgfile,
      "core25 certificate: final_degree_candidates=%llu emitted=%llu\n",
      core25_seen_final,core25_emitted);
}

