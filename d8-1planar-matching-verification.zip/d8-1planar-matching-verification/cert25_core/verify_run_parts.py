#!/usr/bin/env python3
"""Verify the complete 16-shard core-dual exclusion run.

This verifier does not trust the shard boundaries: it parses the original
edge_code catalogue and every shard, then checks the exact byte-for-byte
round-robin identity.  It also locks the generator source/binary, every
recorded counter, and the fact that every generated planar_code stream is
header-only.
"""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import re
from typing import NoReturn


HERE = Path(__file__).resolve().parent
RUN = HERE / "run_parts"
EDGE_HEADER = b">>edge_code<<"
PLANAR_HEADER = b">>planar_code<<"
PARTS = 16

EXPECTED_FULL_SHA256 = (
    "e7c085b6069431e0b6da51102d8412fa92f96a5d81333a727e45e97f573587c7"
)
EXPECTED_SOURCE_SHA256 = (
    "3c5718b60bbc2649ecf638e0184a3dc659e9800344b972e5116b73942c6cf567"
)
EXPECTED_BINARY_SHA256 = (
    "df06d8331f1df7427261578127422ee24b4aa66e988d0e97252a1b6bc383bdcd"
)
EXPECTED_EMPTY_PLANAR_SHA256 = (
    "83c95d9e2ff250b84978fd44d0b8008d4b3b97387d1d0f1334f1de91077dda50"
)

EXPECTED_SHARD_SHA256 = (
    "15ff61facfb5b3ed8be60cf939640e658084b0f2c84ceb43f6e532ebc8597e65",
    "08c62b6a92254a1f15046b59c243536ee01041ce87d682a7162519780f8d3ed1",
    "59649af145ade2636e18e301a730cf4d8d16b48bd9787ee6c32edb00f87c7580",
    "6f4192119fa8fc6f7e28f20d8c876b729ce923b6def30fdd8d29541746e479e0",
    "4bfcc9eaadd2e1ba092f03a09e2257fe00157e75c3635d0e0e6720e0bb28eec8",
    "a748e07d1a37721a58ef417155c37f697e267c95be4b03ddd2fefda211a7e121",
    "b33f3c3910b9b029e205bf227019534eb94e6fefad25f35a414b6e3a70f42283",
    "c2e0e2a2897b47a5852ddf3336a568b70f2f27145b08851bea2dca8de1a61039",
    "489e5c7205c2ed673b1e2d8d8996fa1efa93c49e5f76cdcbfddba401eb69d48a",
    "33f999cd8dfee9a7352f3e46f30691d737ccaa7e814635bcbbfbcca9d131767c",
    "de919b14ddcee8230626b3016a76ba99ab60f2190e4bab7d2f33601cd93a2ae5",
    "9d972ec910000015fab2b90bb0c92c90f096e5c185961ec62e60d14425405cd4",
    "95bad525d487ad5716e528fbe193636e7b169994bb4c9ff7e6704e17d74d5eec",
    "8e6645b199af6388b0337359f9e43138dcb6d10293b90d53607e1f9ef999d71d",
    "81bda330326d37d322dc347da87204bbfce0e1e6e911f84e4c268053365f6d7b",
    "99a88cdf226e9bdcd9d36175816e6d8f75c74950b4beb3d9360e70c69b759cd3",
)

KEYS = (
    "input",
    "matchings",
    "dominance",
    "assignments",
    "subdivision_solutions",
    "bad_contraction",
    "simple_D",
    "capacity_possible",
    "exact_patch_phases",
    "D_with_exact_patch",
    "emitted",
)

# One row per rr_i.ec/coreD_i.log, in KEYS order.
EXPECTED_ROWS = (
    (9545, 17321114, 2606480, 109066376, 8091, 0, 8059, 8091, 0, 0, 0),
    (9545, 17291548, 2655483, 116016207, 22677, 0, 22613, 22677, 0, 0, 0),
    (9544, 17237654, 2552903, 107637638, 6740, 0, 6708, 6740, 0, 0, 0),
    (9544, 17220690, 2570443, 107641400, 2957, 0, 2929, 2957, 0, 0, 0),
    (9544, 17293816, 2632305, 110035952, 5975, 0, 5945, 5975, 0, 0, 0),
    (9544, 17289294, 2665316, 114364630, 12005, 0, 11931, 12005, 0, 0, 0),
    (9544, 17236794, 2549991, 106700993, 6183, 0, 5993, 6183, 0, 0, 0),
    (9544, 17165456, 2517257, 106401412, 8031, 0, 8003, 8031, 0, 0, 0),
    (9544, 17264010, 2622035, 112480304, 17479, 0, 17317, 17479, 0, 0, 0),
    (9544, 17307390, 2599335, 108364151, 4694, 0, 4692, 4694, 0, 0, 0),
    (9544, 17243210, 2569439, 107194015, 3026, 0, 2996, 3026, 0, 0, 0),
    (9544, 17170138, 2503788, 104957632, 10589, 0, 10555, 10589, 0, 0, 0),
    (9544, 17172014, 2538898, 104608648, 17684, 0, 17674, 17684, 0, 0, 0),
    (9544, 17260910, 2587783, 109330013, 7284, 0, 7258, 7284, 0, 0, 0),
    (9544, 17233062, 2609940, 108246367, 3714, 0, 3526, 3714, 0, 0, 0),
    (9544, 17294784, 2610003, 109666775, 3802, 0, 3694, 3802, 0, 0, 0),
)

EXPECTED_TOTALS = (
    152706,
    276001884,
    41391399,
    1742712513,
    140931,
    0,
    139893,
    140931,
    0,
    0,
    0,
)


def fail(message: str) -> NoReturn:
    raise SystemExit(f"FAIL: {message}")


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


def read_required(path: Path) -> bytes:
    try:
        data = path.read_bytes()
    except OSError as exc:
        fail(f"cannot read {path}: {exc}")
    return data


def edge_records(path: Path) -> tuple[bytes, list[bytes]]:
    """Strictly parse a plantri edge_code stream into framed records."""
    data = read_required(path)
    if not data.startswith(EDGE_HEADER):
        fail(f"{path}: missing exact edge_code header")
    pos = len(EDGE_HEADER)
    answer: list[bytes] = []
    while pos < len(data):
        start = pos
        first = data[pos]
        pos += 1
        if first:
            size = first
        else:
            if pos >= len(data):
                fail(f"{path}: truncated long-record descriptor")
            descriptor = data[pos]
            pos += 1
            count_bytes = descriptor >> 4
            code_width = descriptor & 15
            if count_bytes == 0 or code_width == 0:
                fail(f"{path}: invalid long-record descriptor 0x{descriptor:02x}")
            if pos + count_bytes > len(data):
                fail(f"{path}: truncated long-record length")
            size = int.from_bytes(data[pos : pos + count_bytes], "big")
            pos += count_bytes
            if size == 0:
                fail(f"{path}: zero-size long record")
        if pos + size > len(data):
            fail(f"{path}: truncated record body at byte {start}")
        pos += size
        answer.append(data[start:pos])
    if pos != len(data):
        fail(f"{path}: trailing unparsed bytes")
    return data, answer


def parse_summary(path: Path) -> tuple[int, ...]:
    raw = read_required(path)
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError:
        fail(f"{path}: log is not ASCII")
    lines = text.splitlines()
    if len(lines) != 1 or not lines[0]:
        fail(f"{path}: expected exactly one nonempty summary line")
    tokens = lines[0].split()
    if len(tokens) != len(KEYS):
        fail(f"{path}: expected {len(KEYS)} counters, found {len(tokens)}")
    row: list[int] = []
    for expected_key, token in zip(KEYS, tokens):
        match = re.fullmatch(r"([A-Za-z_]+)=([0-9]+)", token)
        if not match or match.group(1) != expected_key:
            fail(f"{path}: expected counter {expected_key}, found {token!r}")
        row.append(int(match.group(2)))
    return tuple(row)


def require_hash(path: Path, expected: str) -> None:
    actual = digest(read_required(path))
    if actual != expected:
        fail(f"{path}: sha256 {actual}, expected {expected}")


def main() -> None:
    require_hash(HERE / "enumerate_core_duals.c", EXPECTED_SOURCE_SHA256)
    require_hash(HERE / "enumerate_core_duals", EXPECTED_BINARY_SHA256)

    full_path = HERE / "cubic14_all.ec"
    full_data, full_records = edge_records(full_path)
    if digest(full_data) != EXPECTED_FULL_SHA256:
        fail(f"{full_path}: catalogue SHA-256 mismatch")
    if len(full_records) != EXPECTED_TOTALS[0]:
        fail(
            f"{full_path}: {len(full_records)} records, "
            f"expected {EXPECTED_TOTALS[0]}"
        )

    observed_rows: list[tuple[int, ...]] = []
    for part in range(PARTS):
        shard_path = RUN / f"rr_{part}.ec"
        shard_data, shard_records = edge_records(shard_path)
        if digest(shard_data) != EXPECTED_SHARD_SHA256[part]:
            fail(f"{shard_path}: shard SHA-256 mismatch")
        expected_records = full_records[part::PARTS]
        if shard_records != expected_records:
            fail(f"{shard_path}: not exact round-robin shard {part}")

        log_path = RUN / f"coreD_{part}.log"
        row = parse_summary(log_path)
        if row != EXPECTED_ROWS[part]:
            fail(f"{log_path}: counter row differs from locked result")
        if row[0] != len(shard_records):
            fail(
                f"{log_path}: input={row[0]} but shard has "
                f"{len(shard_records)} records"
            )
        observed_rows.append(row)

        output_path = RUN / f"coreD_{part}.plc"
        output = read_required(output_path)
        if output != PLANAR_HEADER:
            fail(f"{output_path}: expected a header-only planar_code stream")
        if digest(output) != EXPECTED_EMPTY_PLANAR_SHA256:
            fail(f"{output_path}: header-only SHA-256 mismatch")

        stdout_path = RUN / f"coreD_{part}.out"
        if read_required(stdout_path):
            fail(f"{stdout_path}: expected empty stdout capture")

    totals = tuple(sum(row[column] for row in observed_rows) for column in range(len(KEYS)))
    if totals != EXPECTED_TOTALS:
        fail(f"aggregate counters {totals!r}, expected {EXPECTED_TOTALS!r}")

    rendered = " ".join(f"{key}={value}" for key, value in zip(KEYS, totals))
    print(f"PASS shards={PARTS} exact_round_robin=yes {rendered}")
    print(f"PASS every coreD_i.plc is header-only sha256={EXPECTED_EMPTY_PLANAR_SHA256}")
    print(f"PASS generator_source_sha256={EXPECTED_SOURCE_SHA256}")
    print(f"PASS generator_binary_sha256={EXPECTED_BINARY_SHA256}")


if __name__ == "__main__":
    main()
