#!/usr/bin/env python3
"""Independent dart-level verifier for the 19-vertex core certificate.

Each input record is a simple plane graph D with 19 vertices, 26 edges,
degrees 2..4 and facial lengths 3,4,6^6,9.  The verifier dualizes D without
discarding bridge occurrences, expands the degree-9 dual vertex in all nine
bowtie phases and each of the six degree-6 vertices in both triangle phases,
and therefore checks all 9*2^6=576 residual skeletons R.

For every simple 8T+19Q residual it independently tries both inverse marks:

* a1: q-a is a Q/Q edge, R itself is 3-connected, all 19 quadrilaterals
  are completed as kites, and q-a is then deleted;
* Type-X: q and a are opposite in a distinguished quadrilateral, its other
  diagonal p-r is inserted, the resulting type-X skeleton S is simple and
  3-connected, and only the other 18 quadrilaterals are completed as kites.

Every globally simple completion with degree sequence 7^24,6 is tested for
factor-criticality.  The certificate passes only if none is factor-critical.
"""

from collections import Counter
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import sys


HEADER = b">>planar_code<<"


class VerificationError(RuntimeError):
    pass


def fail(message):
    raise VerificationError(message)


def read_planar_strict(path):
    if not path:
        fail("empty input path")
    pth = Path(path)
    if not pth.is_file():
        fail(f"not a regular file: {path}")
    data = pth.read_bytes()
    if not data:
        fail(f"empty file: {path}")
    if not data.startswith(HEADER):
        fail(f"missing planar_code header: {path}")
    pos = len(HEADER)
    record = 0
    while pos < len(data):
        n = data[pos]
        pos += 1
        if n != 19:
            fail(f"{path}: record {record}: order {n}, expected 19")
        rows = []
        for v in range(n):
            row = []
            while True:
                if pos >= len(data):
                    fail(f"{path}: record {record}: truncated row {v}")
                x = data[pos]
                pos += 1
                if x == 0:
                    break
                if not 1 <= x <= n:
                    fail(f"{path}: record {record}: neighbour out of range")
                row.append(x - 1)
            rows.append(row)
        yield record, rows
        record += 1


def simple_edge_rotation(rows, label, expected_n, expected_m):
    if len(rows) != expected_n:
        fail(f"{label}: wrong order")
    edge_id = {}
    edge_ends = []
    dart_edge = {}
    occurrences = []
    for v, row in enumerate(rows):
        if v in row or len(row) != len(set(row)):
            fail(f"{label}: loop or repeated neighbour at {v}")
        for pos, w in enumerate(row):
            if not 0 <= w < expected_n or v not in rows[w]:
                fail(f"{label}: nonreciprocal adjacency {v}-{w}")
            key = (v, w) if v < w else (w, v)
            if key not in edge_id:
                edge_id[key] = len(edge_ends)
                edge_ends.append(key)
                occurrences.append([])
            eid = edge_id[key]
            dart_edge[(v, pos)] = eid
            occurrences[eid].append((v, pos))
    if len(edge_ends) != expected_m or sum(map(len, rows)) != 2 * expected_m:
        fail(f"{label}: wrong edge count")
    inverse = {}
    for eid, occ in enumerate(occurrences):
        if len(occ) != 2:
            fail(f"{label}: edge {eid} does not have two darts")
        a, b = occ
        inverse[a] = b
        inverse[b] = a
    return dart_edge, occurrences, inverse, edge_ends


def edge_rotation(rows, label, expected_n, expected_m):
    """Validate rows of explicit edge identifiers (loops allowed here)."""
    if len(rows) != expected_n:
        fail(f"{label}: wrong order")
    occ = {}
    for v, row in enumerate(rows):
        if not row:
            fail(f"{label}: isolated vertex {v}")
        for pos, eid in enumerate(row):
            occ.setdefault(eid, []).append((v, pos))
    if set(occ) != set(range(expected_m)):
        fail(f"{label}: edge ids are not 0,...,{expected_m - 1}")
    inverse = {}
    endpoints = []
    for eid in range(expected_m):
        if len(occ[eid]) != 2:
            fail(f"{label}: edge {eid} has {len(occ[eid])} occurrences")
        a, b = occ[eid]
        inverse[a] = b
        inverse[b] = a
        endpoints.append((a[0], b[0]))
    return occ, inverse, endpoints


def facial_darts(rows, inverse, label):
    """Facial orbits of phi=sigma^{-1} alpha."""
    darts = {(v, p) for v, row in enumerate(rows) for p in range(len(row))}
    seen = set()
    faces = []
    face_of = {}
    for start in sorted(darts):
        if start in seen:
            continue
        cur = start
        local = []
        local_set = set()
        while cur not in local_set:
            if cur in seen:
                fail(f"{label}: face merges into a previous orbit")
            local.append(cur)
            local_set.add(cur)
            w, q = inverse[cur]
            cur = (w, (q - 1) % len(rows[w]))
        if cur != start:
            fail(f"{label}: facial orbit closes prematurely")
        f = len(faces)
        for dart in local:
            face_of[dart] = f
        seen.update(local_set)
        faces.append(local)
    if seen != darts:
        fail(f"{label}: not all darts occur in a face")
    if len(rows) - len(darts) // 2 + len(faces) != 2:
        fail(f"{label}: nonspherical rotation system")
    return faces, face_of


def dual_map(d_rows, dart_edge, d_inverse, d_faces, label):
    p_rows = [[dart_edge[d] for d in face] for face in d_faces]
    p_occ, p_inverse, _ = edge_rotation(p_rows, label + ": dual P", 9, 26)
    p_faces, _ = facial_darts(p_rows, p_inverse, label + ": dual P")
    if Counter(map(len, p_faces)) != Counter(map(len, d_rows)):
        fail(f"{label}: dual face lengths do not equal D degrees")
    return p_rows, p_occ


def add_internal_edge(counter):
    eid = counter[0]
    counter[0] += 1
    return eid


def expand_patch(p_rows, triangle_phases, singleton):
    high = [v for v, row in enumerate(p_rows) if len(row) == 9]
    triangles = [v for v, row in enumerate(p_rows) if len(row) == 6]
    av = [v for v, row in enumerate(p_rows) if len(row) == 4]
    zv = [v for v, row in enumerate(p_rows) if len(row) == 3]
    if not (len(high) == len(av) == len(zv) == 1 and len(triangles) == 6):
        fail("dual P has wrong degree signature")

    rows = []
    counter = [26]
    hrow = p_rows[high[0]]
    s = singleton
    uext = [hrow[(s - 4) % 9], hrow[(s - 3) % 9]]
    vext = [hrow[(s - 2) % 9], hrow[(s - 1) % 9]]
    xext = [hrow[(s + 1) % 9], hrow[(s + 2) % 9]]
    yext = [hrow[(s + 3) % 9], hrow[(s + 4) % 9]]
    qu, qv = add_internal_edge(counter), add_internal_edge(counter)
    qx, qy = add_internal_edge(counter), add_internal_edge(counter)
    uv, xy = add_internal_edge(counter), add_internal_edge(counter)
    q = len(rows)
    rows.append([qu, qv, hrow[s], qx, qy])
    rows.append([uv, qu] + uext)
    rows.append([qv, uv] + vext)
    rows.append([xy, qx] + xext)
    rows.append([qy, xy] + yext)

    for core, phase in zip(triangles, triangle_phases):
        ext = p_rows[core]
        blocks = [
            [ext[(phase + 2 * j) % 6], ext[(phase + 2 * j + 1) % 6]]
            for j in range(3)
        ]
        ab, ac, bc = (add_internal_edge(counter) for _ in range(3))
        rows.append([ab, ac] + blocks[0])
        rows.append([bc, ab] + blocks[1])
        rows.append([ac, bc] + blocks[2])

    a = len(rows)
    rows.append(list(p_rows[av[0]]))
    z = len(rows)
    rows.append(list(p_rows[zv[0]]))
    if len(rows) != 25 or counter[0] != 50:
        fail("internal patch construction count failed")
    return rows, q, a, z


def simple_abstract(rows, endpoints):
    pairs = set()
    for u, v in endpoints:
        if u == v:
            return None
        e = (u, v) if u < v else (v, u)
        if e in pairs:
            return None
        pairs.add(e)
    return pairs


def vertex_connected(n, edges, connectivity):
    adjacency = [set() for _ in range(n)]
    for u, v in edges:
        adjacency[u].add(v)
        adjacency[v].add(u)

    def survives(removed):
        alive = [v for v in range(n) if v not in removed]
        if not alive:
            return True
        reached = {alive[0]}
        stack = [alive[0]]
        while stack:
            v = stack.pop()
            for w in adjacency[v]:
                if w not in removed and w not in reached:
                    reached.add(w)
                    stack.append(w)
        return len(reached) == len(alive)

    if not survives(set()):
        return False
    if connectivity >= 2 and any(not survives({u}) for u in range(n)):
        return False
    if connectivity >= 3:
        for u in range(n):
            for v in range(u + 1, n):
                if not survives({u, v}):
                    return False
    return True


def edge(u, v):
    return (u, v) if u < v else (v, u)


def exact_final_degrees(n, edges, z):
    degree = [0] * n
    for u, v in edges:
        degree[u] += 1
        degree[v] += 1
    return degree[z] == 6 and Counter(degree) == Counter({6: 1, 7: 24})


def kite_complete(base, quads, skip=None):
    answer = set(base)
    for idx, face in enumerate(quads):
        if idx == skip:
            continue
        for u, v in ((face[0], face[2]), (face[1], face[3])):
            e = edge(u, v)
            if u == v or e in answer:
                return None
            answer.add(e)
    return answer


def has_perfect_matching(mask, neighbours):
    @lru_cache(maxsize=None)
    def visit(current):
        if current == 0:
            return True
        best = None
        best_options = None
        scan = current
        while scan:
            bit = scan & -scan
            v = bit.bit_length() - 1
            options = neighbours[v] & current
            if best_options is None or options.bit_count() < best_options.bit_count():
                best, best_options = v, options
                if not options:
                    return False
            scan ^= bit
        vbit = 1 << best
        options = best_options
        while options:
            wbit = options & -options
            if visit(current ^ vbit ^ wbit):
                return True
            options ^= wbit
        return False
    return visit(mask)


def factor_critical(n, edges):
    neighbours = [0] * n
    for u, v in edges:
        neighbours[u] |= 1 << v
        neighbours[v] |= 1 << u
    all_mask = (1 << n) - 1
    return all(has_perfect_matching(all_mask ^ (1 << v), neighbours)
               for v in range(n))


def check_residual(rows, q, a, z, counts, label):
    occ, inverse, endpoints = edge_rotation(rows, label, 25, 50)
    base = simple_abstract(rows, endpoints)
    if base is None:
        return
    counts["simple_R"] += 1
    faces, face_of = facial_darts(rows, inverse, label)
    if Counter(map(len, faces)) != Counter({3: 8, 4: 19}):
        return
    vertex_faces = [[dart[0] for dart in face] for face in faces]
    if any(len(face) != len(set(face)) for face in vertex_faces):
        return
    tau = [0] * 25
    for face in vertex_faces:
        if len(face) == 3:
            for v in face:
                tau[v] += 1
    profile = Counter((len(rows[v]), tau[v]) for v in range(25))
    target = Counter({(5, 2): 1, (4, 0): 1, (3, 0): 1, (4, 1): 22})
    if profile != target or (len(rows[q]), tau[q]) != (5, 2) \
            or (len(rows[a]), tau[a]) != (4, 0) \
            or (len(rows[z]), tau[z]) != (3, 0):
        fail(f"{label}: wrong residual profile {profile}")
    counts["exact_residual"] += 1
    quads = [face for face in vertex_faces if len(face) == 4]

    # a1 mark: q-a is an edge with a quadrilateral on each side.
    qa = edge(q, a)
    if qa in base and vertex_connected(25, base, 3):
        qa_eid = next(eid for eid, (u, v) in enumerate(endpoints)
                      if edge(u, v) == qa)
        side_faces = [face_of[d] for d in occ[qa_eid]]
        if len(set(side_faces)) == 2 and all(
                len(vertex_faces[f]) == 4 for f in side_faces):
            counts["a1_marks"] += 1
            completed = kite_complete(base, quads)
            if completed is not None:
                completed.remove(qa)
                if len(completed) != 87 or not exact_final_degrees(25, completed, z):
                    fail(f"{label}: a1 completion has wrong size/degrees")
                counts["a1_degree_completions"] += 1
                if factor_critical(25, completed):
                    counts["factor_critical"] += 1
                    print(f"FOUND a1 factor-critical completion: {label}")

    # Type-X mark: q,a are opposite in Q; insert the other diagonal p-r.
    for mark, face in enumerate(quads):
        if q not in face or a not in face:
            continue
        iq, ia = face.index(q), face.index(a)
        if (iq - ia) % 4 != 2:
            continue
        p, r = face[(iq + 1) % 4], face[(iq - 1) % 4]
        pr = edge(p, r)
        if pr in base:
            continue
        skeleton = set(base)
        skeleton.add(pr)
        if not vertex_connected(25, skeleton, 3):
            continue
        source_tau = list(tau)
        source_tau[q] += 1
        source_tau[a] += 1
        source_tau[p] += 2
        source_tau[r] += 2
        source_degree = [len(row) for row in rows]
        source_degree[p] += 1
        source_degree[r] += 1
        source_profile = Counter(zip(source_degree, source_tau))
        if source_profile != Counter({(5, 3): 3, (4, 1): 21, (3, 0): 1}) \
                or (source_degree[z], source_tau[z]) != (3, 0):
            continue
        counts["typeX_marks"] += 1
        completed = kite_complete(skeleton, quads, skip=mark)
        if completed is None:
            continue
        if len(completed) != 87 or not exact_final_degrees(25, completed, z):
            fail(f"{label}: Type-X completion has wrong size/degrees")
        counts["typeX_degree_completions"] += 1
        if factor_critical(25, completed):
            counts["factor_critical"] += 1
            print(f"FOUND Type-X factor-critical completion: {label}, Q={mark}")


def main(argv):
    if not argv:
        fail("no planar_code input paths supplied")
    counts = Counter()
    hashes = []
    for path in argv:
        raw = Path(path).read_bytes() if Path(path).is_file() else b""
        hashes.append((path, sha256(raw).hexdigest()))
        for record, d_rows in read_planar_strict(path):
            counts["D_maps"] += 1
            exact_before = counts["exact_residual"]
            label = f"{path}: record {record}"
            if not all(2 <= len(row) <= 4 for row in d_rows):
                fail(f"{label}: D degree outside 2..4")
            dart_edge, _occ, d_inverse, _ends = simple_edge_rotation(
                d_rows, label, 19, 26)
            d_faces, _ = facial_darts(d_rows, d_inverse, label)
            if Counter(map(len, d_faces)) != Counter({3: 1, 4: 1, 6: 6, 9: 1}):
                fail(f"{label}: wrong D face multiset")
            p_rows, _ = dual_map(d_rows, dart_edge, d_inverse, d_faces, label)
            for singleton in range(9):
                for phases in product((0, 1), repeat=6):
                    counts["patch_parameters"] += 1
                    r_rows, q, a, z = expand_patch(p_rows, phases, singleton)
                    check_residual(r_rows, q, a, z, counts,
                                   f"{label}, s={singleton}, phases={phases}")
            if counts["exact_residual"] == exact_before:
                fail(f"{label}: emitted D has no exact residual patch")
    if counts["D_maps"] == 0:
        fail("all supplied files are header-only")
    if counts["patch_parameters"] != 576 * counts["D_maps"]:
        fail("not all 576 patch parameters were checked")
    for key in (
        "D_maps", "patch_parameters", "simple_R", "exact_residual", "a1_marks",
        "a1_degree_completions", "typeX_marks", "typeX_degree_completions",
        "factor_critical",
    ):
        print(f"{key}={counts[key]}")
    for path, digest in hashes:
        print(f"sha256 {digest}  {path}")
    if counts["factor_critical"]:
        print("certificate_result=FAIL: factor-critical completion found")
        return 1
    print("certificate_result=PASS: no factor-critical completion")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except VerificationError as exc:
        print(f"certificate_result=ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
