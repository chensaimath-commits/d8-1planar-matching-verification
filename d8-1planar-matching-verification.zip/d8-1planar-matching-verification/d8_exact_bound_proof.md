# 最大度小于 8、匹配数小于 s 的简单 1-planar 图的精确边数

下文的图均为有限简单图；只在把 1-planar drawing 增广为三角化 drawing
的中间步骤中允许平行增广边。记 `nu(G)` 为匹配数。

## 定理

令 `s` 为正整数，`t=s-1`，并写成

```text
t=13q+r,  0<=r<=12.
```

在所有满足 `Delta(G)<8`、`nu(G)<s` 的简单 1-planar 图中，最大边数为

```text
7t+3q                         (0<=r<=6),
7t+3q+1                       (7<=r<=9),
7t+3q+2                       (10<=r<=12).
```

等价地，若

```text
B(t)=max{x+2y+3z: 7x+10y+13z<=t, x,y,z nonnegative integers},
```

则精确答案是 `7t+B(t)`，且

```text
B(13q+r)=3q+1[r>=7]+1[r>=10].
```

证明分上界和达到性两部分。

这是一个计算机辅助的完全证明：所有无限族归约均在正文中手工证明；最后
四个固定参数例外用若干可复现、带源码与哈希的有限平面图穷举证书排除。

## 1. Gallai--Edmonds 归约

对任意 `Delta(G)<=7` 的图作 Gallai--Edmonds 分解 `(D,A,C)`。所需的标准
性质见 Lovasz--Plummer 的 Gallai--Edmonds 结构定理；这里把实际使用的
三条逐项列出：

1. `G[D]` 的每个分量 `D_i` 是 factor-critical；
2. `G[C]` 有完美匹配，且没有 `D--C` 边；
3. 若 `|D_i|=2r_i+1`，则

```text
nu(G)=|A|+|C|/2+sum_i r_i.
```

所有至少一端在 `A` 中的边先按其 `A` 端计数；`A` 内的边被度数和计了
两次，这只会使上界变松。因此

```text
e(A)+e(A,C)+e(A,D) <= sum_{a in A} d(a) <= 7|A|,
e(C) <= 7|C|/2.
```

从而

```text
e(G) <= 7 nu(G) + sum_i (e(D_i)-7r_i).                 (1)
```

若一个非平凡 factor-critical 图 `F` 有割点 `v`，设 `F-v` 的分量为
`Q_1,...,Q_h`。因为 `F-v` 有完美匹配，每个 `Q_j` 均为偶阶且有完美
匹配。令 `F_j=F[V(Q_j) union {v}]`。删去 `v` 时 `Q_j` 有完美匹配；
删去 `x in Q_j` 时，`F-x` 的完美匹配由奇偶性必把 `v` 匹配到 `Q_j`
中，限制到 `F_j-x` 就是完美匹配。因此每个 `F_j` 仍 factor-critical，且

```text
e(F)=sum_j e(F_j),
(|F|-1)/2=sum_j (|F_j|-1)/2.
```

递归拆分后，式 (1) 中每个 bonus `e(D_i)-7r_i` 都可加性地拆成
2-connected factor-critical 1-planar 块的 bonus。复制割点不会增加任一
新块中的度数，且每块继承原 drawing，故仍满足 `Delta<=7` 和
1-planarity。若丢掉 bonus 非正的块，则总 bonus 只会增大，而保留下来
的正 bonus 块所用的 `R` 之和不超过原来的匹配预算；孤立块也无贡献。

所以只需研究一个 2-connected factor-critical 块 `H`。写

```text
|V(H)|=2R+1,  e(H)=7R+k.
```

由度数和

```text
2e(H)<=7(2R+1)
```

可知正 bonus 只有 `k=1,2,3`。核心结论是

```text
k=1  => R>=7,
k=2  => R>=10,
k=3  => R>=13.                                      (2)
```

## 2. 三角化增广给出的初步门槛

固定 `H` 的一个 good 1-plane drawing（交叉均为两条非相邻边的横截
交叉，没有三边共点；从任意 1-planar drawing 局部消去相邻边交叉即可
得到这种 drawing）。下面使用的是 Biedl 的三角化增广论证；为使计数
自足，细节也一并写出。因为 `H` 二连通，drawing 的
planarization 删去任一原顶点 `w` 后仍连通：`H-w` 中的路在每个交叉处
细分后仍给出 walk；若被删的关联边上留有 false crossing，该 crossing
还在与之相交的另一条边上，因而也接回这个连通部分。在连通平面图中，
若某个 facial walk 重复经过一个顶点，则该点是割点；所以这里的面界不会
重复原顶点。一个
至少四角的 region 又不可能有相邻的两个 crossing corners，故可在 region
内连接两个不同、非相邻的真顶点。反复加入这种不交叉边，可把 drawing
三角化：每次都连接面界上的非相邻角，所以不会产生 1-face 或 2-face，
而非三角 region 的角数或边界分量数严格下降，过程必定终止。新边可能与
旧边平行，但不会是 loop。设共加了 `a` 条边，交叉数
为 `x`，完全不含 crossing 的三角 region 数为 `p`。

三角化 drawing 的 planarization 应用 Euler 公式，得到

```text
e(H)+a=3|V(H)|-6+x,
2|V(H)|-4=2x+p.
```

第一式也可看成：每个交叉任选删去一条 crossed edge 后得到平面三角剖分，
其边数为 `3|V(H)|-6`；把删去的 `x` 条边加回。第二式中，这个平面三角
剖分的面恰由 `p` 个真三角面和每个交叉贡献的两个面组成。

代入 `|V(H)|=2R+1,e(H)=7R+k`：

```text
x=R+k+a+3,
p=2(R-k-a-4).                                        (3)
```

删掉每个 crossing 中的两条 crossed edges，得到只含三角面和四边形
kite 面的平面骨架。令 `tau(v)` 为 `v` 入射的三角面数，`q(v)` 为入射
四边形面数；两者都按 facial incidence（面角）计数。每个入射四边形恰给
`v` 一条 crossed edge，故在增广图中

```text
d_plus(v)=tau(v)+2q(v),
```

特别地 `d_plus(v)` 与 `tau(v)` 同奇偶。

原图相对于 7-正则的总亏损为

```text
D=7(2R+1)-2(7R+k)=7-2k.
```

所以原图至少有

```text
2R+1-D=2R+2k-6
```

个 7 度点。至多 `2a` 个这样的点是增广边端点；其余点在增广图中仍为
奇度，因而其 `tau` 是正奇数。又 `sum_v tau(v)=3p`，于是

```text
2R+2k-6-2a <= 3p=6(R-k-a-4).
```

整理并利用整数性：

```text
R>=2k+a+5.                                           (4)
```

这已证明 `k=1 => R>=7`。对 `k=2` 只剩 `(R,a)=(9,0)`；对 `k=3`
只剩 `(R,a)=(11,0),(12,0),(12,1)`。以下逐一排除。

## 3. 无增广边时的 full-kite 骨架

先处理 `a=0`。令 `S` 是删掉所有 crossed edges 后的骨架。它是简单
平面图，每个面是三角形或四边形；每个四边形的两条对角线正是原图中
的一对 crossing edges。确切地说，若 `ab` 与 `cd` 相交，则 crossing
周围的四个 region 在三角化后均为三角形，故循环相邻端点间的四条边均为
uncrossed side；删去 `ab,cd` 后这四个三角 region 合成一个四边形面。
good drawing 保证四个端点互异，而 `a=0` 与原图简单性保证四条 side 和
两条对角线都不会是增广造成的伪重合，故这里确为 full kite。

`S` 实为 3-connected。先证二连通：对任意顶点 `w`，`H-w` 连通；其
路径上的每条 crossed edge 都可沿所在 kite 的两条长为 2 的边界路之一
替换，至少一条避开 `w`，故 `S-w` 连通。于是所有面界都是简单圈。

若 `{u,v}` 是 `S` 的 2-cut，考察平面嵌入中 `uv`-bridges 的环序。两个
相邻非平凡 bridge 之间的面由各 bridge 内的一条 `u--v` 路组成。因面长
至多 4 且每条路长至少 2，该面只能是以 `u,v` 为对顶点的四边形。
若 `uv` 不是骨架边，环序中至少有两个这样的界面四边形，迫使同一条
crossed edge `uv` 在两个 kite 中重复；若 `uv` 是骨架边，边 bridge 之外
仍至少有两个非平凡 bridge，其中相邻的一对又迫使一个 crossed `uv`，
与已有 uncrossed `uv` 重复。两者都违背原图简单性。因此 `S` 三连通。

对任意顶点，记其骨架度数为 `d_S(v)`，则

```text
d_H(v)=2d_S(v)-tau(v).                                (5)
```

称两侧都是三角面的骨架边为 TT-edge。若长度 `d` 的循环面序中有
`tau` 个 T，则该点至少入射

```text
max(0,2tau-d)
```

条 TT-edge；TT-edge 的另一端也有 `tau>=2`。这个局部事实将把候选型
降到极少数。

### 3.1 排除 `(R,k)=(9,2)`

此时 `H` 有 19 点、65 边，总度亏损 3；`S` 有 37 边、6 个三角面和
14 个四边形面。度亏损的三个分拆给出：

1. `7^16,6^3`：由 (5) 和骨架度数和，只可能是
   `(5,3),(3,0)^3,(4,1)^15`，或
   `(3,0)^2,(4,2),(4,1)^16`。前者的唯一 `(5,3)` 点被迫有 TT-edge，
   但没有第二个 `tau>=2` 点，矛盾。
2. `7^17,6,5`：唯一可能为
   `(3,0),(3,1),(4,1)^17`。
3. `7^18,4`：度数和等式迫使型为 `(4,1)^18,(2,0)`，但 `S` 三连通
   因而最小度至少 3，矛盾。

剩下的两个型由 `cert19` 穷尽。先证明它所枚举的三角剖分确实覆盖每个
候选 `S`。两型都恰有两个骨架度为 3 的点，而且每点至少入射两个
四边形。每个四边形的两条对角线本来就是 `H` 中相交的两条边；由于
`H` 简单，它们都不是骨架边，而且来自不同四边形的对角线不会重复
（否则同一条 `H` 边要在两个 crossing 中出现）。给两个 3 度点分别选
一个互不相同的关联四边形，并在其中选择经过该点的对角线；这是可行的，
因为二者各有至少两个关联四边形。其余四边形任取一条对角线，并把所选
对角线改画在相应面内，得到简单平面三角剖分 `T`。

每个骨架度 3 的点至少得到一条新边，故 `delta(T)>=4`。另一方面，每点
从每个关联四边形至多得到一条新边，所以

```text
d_T(v)<=d_S(v)+q(v)=2d_S(v)-tau(v)=d_H(v)<=7.
```

故 `T` 的所有度数均在 4 到 7 之间。每个原四边形在 `T` 中被分成两个
三角面，且不同四边形内部不交，故所加的 14 条边在 `T` 的对偶中成匹配。

反过来，`S` 由这样的三角剖分删去 14 条在对偶中成匹配的边得到。官方
plantri 共生成 312552 个此类三角剖分；独立 DFS 穷尽全部 14-匹配，并
检查上述必要度数条件、骨架型及全局对角线唯一性，连一个完整匹配都没有
存活。因此 `R=9` 不存在，得到 `k=2 => R>=10`。

### 3.2 排除 `(R,k)=(11,3)`

此时 `H` 为 23 点、80 边，度序 `7^22,6`；`S` 有 46 边、8 个三角面
和 17 个四边形面。由 (5) 及度数和只有两型：

```text
(5,3),(3,0),(4,1)^21,
(4,2),(4,1)^22.
```

第一型仍因唯一 `tau>=2` 点被迫有 TT-edge 而矛盾。第二型要求 `S` 是
四正则 3-connected 平面图，三角入射多重集为 `1^22,2`。其对偶是 25
点四边形剖分，顶点度数为 `3^8,4^17`。作者公开的相应 plantri 目录完整
给出 33 个嵌入，
独立检查器逐个重建面并验 3-connectivity；没有一个有目标入射多重集。
故 `R=11` 不存在。

### 3.3 排除 `(R,k,a)=(12,3,0)`

此时 `H` 为 25 点、87 边，度序 `7^24,6`；`S` 有 51 边、10 个三角面
和 18 个四边形面。对 7 度点写

```text
(d_S,tau)=(4+alpha,1+2alpha),
```

对唯一 6 度点写

```text
(d_S,tau)=(3+beta,2beta).
```

度数和给出 `sum alpha+beta=3`。用上面的 TT-edge 下界检查 3 的所有
分拆，只有两型未立即矛盾。具体地，参数为 `j` 的 7 度点至少关联
`max(0,3j-2)` 条 TT-edge，参数为 `j` 的 6 度点至少关联
`max(0,3j-3)` 条 TT-edge。若分拆是 `3`，只有一个点有 `tau>=2`，但它
被迫关联 TT-edge；若分拆是 `2+1`，参数 2 的点至少关联 3 条 TT-edge，
而可作为另一端的点只有另一个参数正的点，简单性使二者之间至多一条边。
两种情形均矛盾。分拆 `1+1+1` 中，参数 1 或全落在三个 7 度点上，或
落在两个 7 度点和唯一 6 度点上，恰给出：

```text
X: (5,3)^3,(3,0),(4,1)^21;
Y: (5,3)^2,(4,2),(4,1)^22.
```

对 Y 型，每个 `(5,3)` 点至少入射一条 TT-edge，而唯一 `(4,2)` 点至多
入射一条；故两个 `(5,3)` 点 `p,q` 之间必有 TT-edge `pq`。删去它，得到四正则平面
图 `S_0`，有 8 个三角面和 19 个四边形面。两侧三角形的第三点不同，
否则同一个三角圈同时成为 `pq` 两侧的面，三连通的 `S` 将只能是这个
三角圈，与 `|V(S)|=25` 矛盾。因此它们
给出两条内部不交的两步路 `p-x-q,p-y-q`。若 `S_0` 有割点 `v`，则
`v` 不是 `p,q`（否则 `S-v=S_0-v` 不连通）；而加回 `pq` 能恢复连通
又迫使 `p,q` 分居 `S_0-v` 的两侧，这与两条路中至少一条避开 `v`
矛盾。因此 `S_0` 无割点。四正则图的每个边割为偶数。若有
2-edge-cut，它必须分开 `p,q`，否则也是 `S` 的 2-edge-cut；上面两条
路各贡献一条割边，加回 `pq` 后便得到 `S` 的一个 3-edge-cut；四正则性
排除原 2-edge-cut 的任一侧为单点，故这个 3-edge-cut 非平凡，而且三条
割边不是匹配。但三连通图的每个非平凡 3-edge-cut 都是匹配：
若两条割边在一侧共端点 `u`，删去 `u` 和第三条割边在另一侧的端点便
分离割的两侧；若三条都在一侧共端点，删去该公共端点已经造成分离。
非平凡性保证删除后两侧仍各有点，二者都违背三连通性。矛盾。因此
`S_0` 4-edge-connected。于是其平面对偶是简单二连通的四边形剖分：
loop 或重边将分别对应 `S_0` 的 1-或 2-edge-cut；而简单四边形剖分若有
割点，就会有 facial walk 重复该点，这也与四个互异角的面界矛盾。故它
正好属于下面所用目录的生成类（反向对偶也保留完整的 rotation system）。
完整的 51 图四正则目录，对每图
尝试 19 个四边形及两条对角线，共 1938 次逆操作；没有 Y 型复原。

下面把 X 型以及第 4 节中尚会出现的一个型统一降到一个很小的残余类。
X 型的 TT-edge 两端只能是三个 `(5,3)` 点；而每个这样的点至少入射一条
TT-edge，所以三个点上的 TT 子图是路径或三角形。取其中 TT 度为 2 的点
`r`，并取一条关联 TT-edge `pr`。在 `r` 周围，三个 T 位置构成一个连续
块；块的中间三角形是 `p-r-q`，其中 `q` 是第三个 `(5,3)` 点。`pr` 另一
侧的三角形写成 `p-r-a`。两侧第三点不同，否则同一个三角圈会成为
`pr` 两侧的面，迫使这个三连通平面图只有该三角圈；又因 `a` 入射三角面
且不是三个高点之一，它必是普通 `(4,1)` 点。删去 `pr` 后两个三角形
合并为四边形 `p-q-r-a`，得到平面图
`R`：

```text
|V(R)|=25, |E(R)|=50, faces(R)=3^8 4^19,
(d_R,tau_R)=(5,2)_q,(4,0)_a,(3,0)_z,(4,1)^22.       (R)
```

先验证这个 X 型 `R` 的连通性。这里 `R=S-pr` 且 `S` 三连通；删去一条
边后 `R` 仍二连通。若 `R` 有至多二条边的割，则割必须分开 `p,r`，否则
它仍是 `S` 的至多二边割。两条内部不交的路 `p-q-r`、`p-a-r` 迫使割
至少含两条边；加回 `pr` 后便得到 `S` 的一个非平凡三边割，而且三条
割边不是匹配（`delta(R)>=3` 排除原二边割的一侧为单点）。这与上面已经
证明的三边割引理矛盾。因此
`lambda(R)>=3`。

下面证明更强的统一残余引理：不存在满足 (R)、二连通且
`lambda(R)>=3` 的简单平面图。唯一满足 `tau>=2` 的点是 `q`，故 `R`
没有 TT-edge；八个三角面因而由一个在 `q` 相交的 bowtie 和另外六个互不
相交的三角形组成。收缩这七个闭三角面片（保留所有外部 edge darts），
得到连通平面伪图 `P`，其参数为

```text
|V(P)|=9, |E(P)|=26,
degree multiset(P)=9,6,6,6,6,6,6,4,3.
```

每个原四边形至多含两条三角形边界边。事实上，若在四边形某点相邻的两条
边在另一侧属于同一三角面，则该三角面和四边形占满这两条 dart 间的两个
扇区，迫使该点度数为 2；若属于不同三角面，则该点的 `tau>=2`。而一个
四圈中任取至少三条边，会在两个不同顶点处出现相邻对，这将迫使两个
`tau>=2` 点，矛盾。因此 `P` 的 19 个面长度均为 2、3 或 4。

任一 `P` 的边割，按收缩块取顶点并集后会原样提升成 `R` 的等大边割；
故 `lambda(P)>=3`。

令 `D=P*`。于是 `D` 是简单连通平面图（但允许有桥），并且

```text
|V(D)|=19, |E(D)|=26, |F(D)|=9,
2<=delta(D)<=Delta(D)<=4,
face lengths(D)=3,4,6,6,6,6,6,6,9.
```

这里简单性正来自 `P` 无一边割和二边割；`P` 的 loop 在 `D` 中只变成
桥，所以不能错误地给 `D` 加二连通假设。设 `D` 的二度点数为 `h`，握手
式给出

```text
(n_2,n_3,n_4)=(h,24-2h,h-5),  5<=h<=12.
```

压掉所有二度点，再把每个四度点按 rotation 中相邻的 `2+2` darts 分裂
成两个三度点并用一条新边连接，得到 14 点、21 边的连通三正则平面多重图
`C`；所有新分裂边都是非 loop 且构成匹配。反过来，从任意这样的 `C`
选择一个非 loop 匹配 `M`，收缩 `M`，再在余下的边上总共放置
`|M|+5` 个二度细分点（正向中 `|M|=h-5`），就覆盖每个可能的简单
`D`；压缩核中可能出现的 loop、重边，`D` 中可能出现的桥以及全部
rotation 情形都被保留，复原后的 `D` 再显式检查简单性。

官方 plantri 5.8 用

```text
plantri -E -d -m1c1t 9
```

完整生成 152706 个这样的 14 点三正则平面多重图。证书逐个枚举非 loop
匹配、收缩和所有细分分配，复原上述 `D`，再对偶回 `P`。细分数由九个
面的精确 incidence 方程求出。这里的完备性可概括为：压缩/分裂把每个
目标 `D` 映到目录中的某个带非 loop 匹配的 `C`；反向时遍历全部这类
匹配和全部非负细分分配，所以必定重建该 `D` 的至少一个描述。生成期的
`subdivision_upper` 与 complementary-window 容量界，均对两个端点的
所有循环起点、两个方向和允许的局部相位取最大值；它们先删去端点间的
相容性条件再取上界，故只是不可能性必要条件，不会删掉任何可实现分配。
具体地，若 `D` 的一条核边细分 `t` 次，则在 `P=D*` 中变成同两收缩块
之间的 `t+1` 条相邻边，夹出 `t` 个连续二角面。逆展开后每个二角面必须
成为四边形，故其两端连续扇区的 corner cost 之和逐项为 2。singleton、
triangle、bowtie 三类块的循环 cost 分别为
`(0)`、`(1,0,1,0,1,0)`、`(0,1,0,1,1,0,1,0,2)`。因此对两端任意循环
起点、任意方向取最长互补段所得上界覆盖每个真实相位；端点对容量界也只
是忽略 rotation 相容性后的放松。源码正是枚举这些有限窗口后才取上界。
每个留下的实例再从 dart rotation 精确重建并检查简单性、面型和逐点
`(d,tau)`。

在一个 6 度收缩点处，三角面片的三个原顶点各承接两个连续外部 darts，
循环序中只有奇、偶两种配对相位。在 9 度收缩点处，bowtie 中心承接一个
外部 dart，四个叶点各承接连续的两个；指定中心 dart 的 9 个位置后，其余
分组在固定外部 rotation 下、模 bowtie 的全部平面自同构唯一；源码按
九个 singleton 位置逐一重建 facial walks，而不是只按抽象图同构猜测。
因此每个候选恰检查
`9*2^6=576` 种逆展开。完整 16 分片运行共枚举 276001884 个匹配、
1742712513 个分配，得到 139893 个简单 `D` 描述（同一 `D` 可由不同逆
描述重复出现）；其中精确逆展开相位数
为 0。故满足 `lambda(R)>=3` 的 (R) 型图不存在，从而 X 型不可能。

## 4. 排除 `(R,k,a)=(12,3,1)`

设唯一增广边为 `e^+=uv`。删掉它后，它两侧的两个三角化 region 合成
一个 region；设两侧第三角中有 `h` 个 crossing corners，则 `h<=2`，原
drawing 的 uncrossed 三角 region 数为

```text
p_0=6+h.
```

为把奇偶计数写清，记增广 drawing 与原 drawing 的真三角入射数分别为
`tau_+,tau_0`，并令 `b=2-h` 为 `e^+` 两侧的真三角数。对两个 pole 有

```text
d_H=d_+-1,  tau_0=tau_+-b,
tau_0-d_H = h-1 (mod 2).
```

每个真第三角只使它自己的 `tau` 奇偶翻转一次，其余点不变。原图有 24
个奇度点。若 `h=0`，异常点至多为两个 poles 和两个真第三角，故至少
20 个点有正奇 `tau_0`，但 `sum tau_0=3p_0=18`；若 `h=1`，poles 的
奇偶关系不异常，只有一个真第三角异常，故至少 23 个点有正奇
`tau_0`，但 `sum tau_0=3p_0=21`。均矛盾。所以 `h=2`，即 `e^+`
两侧都是 full-kite 四边形。

若旧图已有 crossed `uv`，删去其旧轨迹，在旧 kite 内把 crossing partner
平滑成不交叉对角线，再让旧 `uv` 占用 `e^+` 的轨迹；这给出同一个简单
图 `H` 的无增广边、18-crossing 三角化 drawing，已由上一节排除。

只剩 `uv` 原来不是边（simple-new）或旧 `uv` 是 uncrossed（parallel）两类。
令 `S^+` 为增广 drawing 的 full-kite 骨架；它有 25 点、50 边、8 个
三角面、19 个四边形面。令 `I(v)` 表示 `v` 是否为 pole，则

```text
d_H(v)=2d_{S+}(v)-tau(v)-I(v).                        (6)
```

记唯一 6 度点为 `z`。由 `sum d_{S+}=100`，(6) 只给出以下型：

为核对“只”字，令 `epsilon(v)=d_{S+}(v)-4`，则 `sum epsilon=0`。对非
pole 的 7 度点、非 pole 的 `z`、pole 的 7 度点、pole 的 `z`，(6)
依次给出

```text
tau=1+2epsilon,  2+2epsilon,  2epsilon,  1+2epsilon.  (6a)
```

除“非 pole 的 `z`”外，其余三类都要求 `epsilon>=0`；只有非 pole 的 `z`
允许 `epsilon=-1`。若 `z` 是 pole，则所有 `epsilon=0`。若 `z` 不是
pole，则或仍全部为 0，或 `epsilon(z)=-1` 且恰有另一个点的
`epsilon=1`；后一个点只能是 pole 或普通非 pole。于是恰有以下四型：

1. `z` 是 pole：`S^+` 四正则，`tau` 多重集为 `0,1^24`；
2. `z` 非 pole 且额外骨架度给 `z`：`S^+` 四正则，型为
   `(4,0)^2,(4,2),(4,1)^22`；
3. 额外骨架度给一个 pole：
   `(5,2),(4,0),(3,0),(4,1)^22`；
4. 额外骨架度给普通非 pole：出现唯一 `(5,3)`，又被迫有 TT-edge 而无
   第二个 `tau>=2` 点，立即矛盾。

在 simple-new 情形，增广图简单，故 `S^+` 3-connected。对前两个四正则
型，四正则性使每个边割为偶数，而三连通性给边连通度至少 3，故实际
至少 4-edge-connected，恰落在同一个 51 图完整目录中：`0,1^24` 型数量
为 0；第二型的入射多重集
虽有 2 图，但两 `tau=0` 点在任何一图中都不是一个两侧均为四边形的 pole
edge，故无合法标记。第三型恰是第 3.3 节的共同残余型 (R)；这里
`S^+=R` 本身三连通，因而当然满足该节归约所需的 `lambda(R)>=3`。
共同 core 证书证明不存在任何满足 `lambda(R)>=3` 的 (R) 型平面骨架；
所以无需再使用 pole edge `q-a` 两侧均为四边形这一附加标记，第三型也被
排除。

在 parallel 情形，`S^+` 只有 `e^+` 与旧 uncrossed `e^0` 这一对平行边。
planarization 删去任一原顶点仍连通，所以 `S^+` 的每个 T/Q facial walk
都是简单圈。因而两平行边的四个 edge-sides 在每个 pole 处必须属于四个
不同面扇区：若同一面使用两条平行边的两个 sides，则它们在 rotation 中
相邻时形成 2-face；不相邻时该 facial walk 会重复经过这个 pole。两者都
与面界为简单的 T/Q 圈矛盾。`e^+` 两侧为四边形；含 `tau=0` pole 的
`e^0` 两侧也为四边形，所以在另一个 pole 处这四个不同扇区全是 Q。
这立即排除型 1（另一个 pole 只有三个 Q 扇区）和型 3（`(5,2)` pole
也只有三个 Q 扇区）。故只剩型 2。

型 2 是四正则 plane multigraph，面型 `3^8 4^19`，三角入射为
`0^2,1^22,2`，且唯一 double edge 连接两个 `tau=0` poles。取对偶得到
27 点一般四边形剖分，度序 `3^8,4^19`。官方 plantri `-Q -m3 27`
完整生成这个允许重边的类；安全的生成期必要剪枝后共有 1189 个叶结点
进入最终过滤，其中 51 个具有度数/面型，2 个具有目标三角入射多重集，
但没有一个具有连接两个 `tau=0` 点的唯一 double edge。作为独立复核，
过滤器另输出上述 51 个 map 的 edge-code 超集，独立检查器逐一重建对偶
骨架，得到同样的 `51,2,0` 三级计数。因此 parallel 型也不存在；后续的
kite completion 和 factor-criticality 检查不再被触发。

至此 (2) 完全证明。

## 5. 有限穷举证书

每个证书都在自己的 README 中固定具体的 plane-map 类和 plantri 选项，
而不依赖一句笼统的“所有图只输出一次”：`cert19` 生成指定度数范围的平面
三角剖分；`cert23`、`cert25B` 生成相应四边形剖分的对偶；共同 core 用
`-E -d -m1c1t 9` 生成允许 loop、重边和桥的连通三正则 plane multigraph，
其中 `-E` 保留每条 edge 的两个独立 darts；parallel 用 `-E -Q -m3 27`
生成一般四边形剖分。各证书所用的一般 plane-map 类按其 rotation system
生成，`edge_code` 保留 loop、重边两侧的独立 darts；具体完整性由对应
README 中固定的 plantri 类与选项保证。检查器拒绝
malformed/truncated code，重建 rotation 和所有 facial walks，验证 Euler
恒等式、所需连通度、全局对角线不重复、最终度序，并在确有 25 点完成
候选时逐点计算完美匹配。

最终计数（完整运行结束后锁定）：

```text
分支                         完整输入/中间计数                         决定性末级计数
R=9,k=2                    312552 triangulations                    complete_matchings=0
R=11,k=3                   33 quartic maps                          target_tau=0
R=12,a=0,Y                 51 quartic maps, 1938 inverse marks      type_Y=0
R=12,a=1,simple quartic    51 quartic maps                          tau型1=0;
                                                                     tau型2=2, pole_marks=0
共同 residual (R), λ>=3    152706 cubic maps; 276001884 matchings;  simple_D=139893;
                              1742712513 assignments                 exact_patch_phases=0
R=12,a=1,parallel          final-filter leaves=1189; shape=51;      tau型=2;
                                                                     exact_double_poles=0
```

共同 residual 的 16 个分片由 record-aware 脚本从同一个 edge-code 目录作
round-robin 切分；manifest 检查器逐 record 反交织后与原目录逐字节相等，
并锁定源文件、可执行文件、每个分片和每个空输出的 SHA-256。其完整累计
计数还包括

```text
dominance=41391399,
subdivision_solutions=140931,
bad_contraction=0,
capacity_possible=140931,
D_with_exact_patch=0, emitted=0.
```

为避免共同 residual 的零结论只由同一个生成器的末级判定给出，另行编译
一个更宽的安全超集版本：它在末级相位判定之前输出 52169 个简单 `D`
记录（允许不同逆描述重复）。分开编译的 dart-level 检查器对它们重新遍历全部
`52169*576=30049344` 个相位，其中 3847248 个逆展开在简单性检查处通过，但
`exact_R=0`、`profile_R=0`。`verify_superset_manifest.py` 锁定 16 个
非空流及源码/二进制哈希，并在验证时鲜活重跑检查器。因此共同 core 的
`exact_patch_phases=0` 还有一条非空超集上的独立复核。

parallel 搜索也同时保留了一个 51-map 的较早阶段超集；独立 Python
edge-code 检查器从零重建 rotation、对偶、三角入射和重边，输出

```text
maps=51, degree_signature=51, quadrangular_embedding=51,
tau_signature=2, exact_tau_one_double=0.
```

所以两个最大的零结果都不是只相信“最终文件为空”：各自都有一个锁定的
完整生成 manifest，也都由非空安全超集经过独立检查器复核。

证书目录：

```text
cert19/              R=9,k=2
cert23/              R=11,k=3
cert25B/             R=12,a=0,Y 型及 a=1 两个 simple quartic 型
cert25_core/          X 型与 a=1 simple 非四正则型的共同 residual
cert25_parallel/      a=1 parallel 的分片输出、日志及独立检查日志
constructions/        三个达到性块及其独立验证器
```

parallel 分支的生成和独立检查源码分别为根目录中的
`cert25_parallel_quartic_plugin.c` 与 `verify_25_parallel_quartic.py`。
各目录 README 给出 plantri 版本/来源、精确命令、固定计数、文件哈希以及
每个生成期剪枝为何只是必要条件；仓库还附带所用的 plantri 5.8 源码、顶层
`MANIFEST.sha256` 和 `verify_all.sh`。后者逐字节审计已记录的目录、分片、
日志与非空安全超集，并不冒充重新执行最昂贵的完整生成；完整重跑命令见各
目录 README。源码和输出可独立复核，而编译后二进制逐字节相同仍依赖原构建
环境。
工作目录中若还保留早期探索性的 `cert25_remaining` 等旧分支，它们均已
弃用，既不参与上述计数，也不作为证明依据；证明只依赖本节明确列出的
五个证书目录与 `constructions/`。

## 6. 上界的 knapsack 收尾

由 (2)，bonus 为 1、2、3 的每个正 bonus 块至少分别花费 7、10、13 个
匹配单位。若三类块数为 `x,y,z`，则

```text
7x+10y+13z<=nu(G)<=t,
sum bonus <=x+2y+3z<=B(t).
```

结合 (1) 及 `B` 单调：

```text
e(G)<=7nu(G)+B(nu(G))<=7t+B(t).                       (7)
```

为算出 `B`，令 `P=x+2y+3z,C=7x+10y+13z`。有

```text
3C-13P=8x+4y.
```

若利润 `P` 模 3 分别为 `0,1,2`，则 `x+2y` 也分别模 3 为 `0,1,2`。
在非负整数中，`8x+4y` 在这三个同余类的最小值分别是 `0,8,4`。
因此利润为 `3Q,3Q+1,3Q+2` 时，最小成本依次为

```text
13Q, 13Q+7, 13Q+10,
```

分别由 `Q` 个 13-块、`Q` 个 13-块再加一个 7-块、`Q` 个 13-块再加
一个 10-块达到。利润 `3q+3` 已至少花费 `13(q+1)>13q+r`；再与
`t=13q+r` 比较即得

```text
B(t)=3q+1[r>=7]+1[r>=10].
```

## 7. 达到上界

证书给出三个简单 1-planar factor-critical 块：

```text
匹配数 R     顶点数     边数       bonus
7             15         50          1
10            21         72          2
13            27         94          3
```

每块均有证书中的奇 Hamilton 圈；删任一顶点后余下 Hamilton 路的交替边
形成完美匹配，故确为 factor-critical。rotation/face 证书同时逐面验证其
1-planar drawing 和 `Delta<=7`。

写 `t=13q+r`。取 `q` 个 13-块；若 `r>=10` 再取一个 10-块，若
`7<=r<=9` 再取一个 7-块；最后用若干 `K_{1,7}` 把匹配数补到恰为 `t`。
每个星贡献匹配数 1 和 7 条边。所得不交并仍简单、1-planar、最大度 7，
且边数恰为

```text
7t+B(t).
```

它与上界 (7) 相等，定理得证。

## 参考与枚举来源

1. L. Lovasz and M. D. Plummer, [*Matching Theory*](https://ir.cwi.nl/pub/2626/2626D.pdf),
   North-Holland Mathematics Studies 121, 1986；其中的 Edmonds--Gallai
   结构定理给出这里使用的分解性质。
2. T. Biedl, [*A note on 1-planar graphs with minimum degree 7*](https://arxiv.org/abs/1910.01683),
   Discrete Applied Mathematics 289 (2021), 230--232；其中给出 good drawing
   的三角化增广、`m=3n-6+x`、`2n-4=2x+p` 以及奇度点的真三角入射计数。
3. G. Brinkmann and B. D. McKay, *Fast generation of planar graphs*, MATCH
   Commun. Math. Comput. Chem. 58 (2007), 323--357；以及
   [plantri 5.8 官方主页与使用指南](https://users.cecs.anu.edu.au/~bdm/plantri/)。
   指南明确规定按嵌入同构类各输出一次，并说明 `edge_code` 对 loop 和重边
   的两个 darts 作无歧义编码。
4. G. Brinkmann, S. Greenberg, C. Greenhill, B. D. McKay, R. Thomas and
   P. Wollan, *Generation of simple quadrangulations of the sphere*, Discrete
   Mathematics 305 (2005), 33--54；用于四边形剖分目录的生成背景。
5. Y. Huang, L. Zhang and F. Dong,
   [*A new note on 1-planar graphs with minimum degree 7*](https://doi.org/10.1016/j.dam.2024.01.026),
   Discrete Applied Mathematics 348 (2024), 165--183；以及作者公开的
   [4-regular plane graph 目录与生成源码（固定提交）](https://github.com/lichengzhang1/4-regular-plane-graphs-with-given-faces/tree/23d75d009948a868c7bf6fdb1486051b192d0d52)。
   本文只把该目录当作平面 map 数据源；目标 `tau` 型的排除仍由本证明的
   独立检查器完成，并不作为该论文的定理引用。
