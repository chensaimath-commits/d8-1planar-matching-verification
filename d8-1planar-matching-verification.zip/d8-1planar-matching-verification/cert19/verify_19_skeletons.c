/* Exhaustive verifier for the two remaining 19-vertex skeleton types.
 *
 * Generate the input with plantri 5.5 and its distributed allowed_deg.c:
 *     cc -O3 -o plantri_ad '-DPLUGIN="allowed_deg.c"' plantri.c
 *     ./plantri_ad -F4F5F6F7 19 tri19_4567.plc
 *
 * Every desired skeleton can be triangulated by choosing one diagonal in
 * each of its 14 quadrilateral faces so that the resulting triangulation
 * has minimum degree 4.  Conversely, the verifier deletes a dual matching
 * of 14 flippable edges from every such triangulation and checks the exact
 * degree, face-incidence, non-repeated-diagonal, maximum-degree, and
 * factor-critical conditions.  The counter complete_matchings below counts
 * completions only after all of these sound partial-state bounds: deleted
 * degree at every vertex can still finish in {3,4}; at most one vertex can
 * finish with tau=2 and none with tau>2; every future added opposite
 * diagonal still respects degree at most 7; and added diagonals are absent
 * from the triangulation and globally unrepeated.  Thus it is deliberately
 * not the number of raw size-14 matchings in the dual.
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 19
#define NE 51
#define ND 102
#define NF 34

typedef struct { int u,v,f[2],opp[2],addkey,ok; } Edge;

static int rot[N][N], deg0[N], dart_u[ND], dart_v[ND], dart_rev[ND];
static int dart_face[ND], face_edge[NF][3], face_vert[NF][3];
static Edge edges[NE];
static int edge_of[N][N];
static signed char fstate[NF], chosen[NE], add_used[N*N];
static int dsel[N], oadd[N], tun[N];
static unsigned long long ngraphs, ndegok, ncomplete, nkite, ntype, nfc;

static void die(const char *s) { fprintf(stderr,"error: %s\n",s); exit(2); }

static int read_graph(FILE *in)
{
    int n, i, j, x;
    n=fgetc(in); if (n==EOF) return 0;
    if (n!=N) die("unexpected vertex count (only byte planar_code is supported)");
    for (i=0;i<N;i++) {
        deg0[i]=0;
        while ((x=fgetc(in))!=0) {
            if (x==EOF || x<1 || x>N || x-1==i || deg0[i]>=N)
                die("bad planar_code adjacency row");
            for (j=0;j<deg0[i];j++)
                if (rot[i][j]==x-1) die("repeated planar_code neighbour");
            rot[i][deg0[i]++]=x-1;
        }
    }
    for (i=0;i<N;i++) for (j=0;j<N;j++) edge_of[i][j]=-1;
    return 1;
}

static void build_embedding(void)
{
    int i,j,k,d=0,e=0,f=0,cur,start,len,u,v,w,rev,efcount[NE]={0};
    for (i=0;i<N;i++) for (j=0;j<deg0[i];j++) {
        if (d>=ND) die("too many darts");
        dart_u[d]=i; dart_v[d]=rot[i][j]; d++;
    }
    if (d!=ND) die("input is not a triangulation");
    for (i=0;i<ND;i++) {
        rev=-1;
        for (j=0;j<ND;j++) if (dart_u[j]==dart_v[i] && dart_v[j]==dart_u[i]) {rev=j;break;}
        if (rev<0) die("missing reverse dart");
        dart_rev[i]=rev; dart_face[i]=-1;
    }
    for (i=0;i<ND;i++) if (dart_u[i]<dart_v[i]) {
        if (e>=NE) die("too many edges");
        edges[e].u=dart_u[i]; edges[e].v=dart_v[i];
        edges[e].f[0]=edges[e].f[1]=-1;
        edge_of[dart_u[i]][dart_v[i]]=edge_of[dart_v[i]][dart_u[i]]=e++;
    }
    if (e!=NE) die("wrong edge count");
    for (i=0;i<ND;i++) if (dart_face[i]<0) {
        if (f>=NF) die("too many faces");
        start=cur=i; len=0;
        do {
            if (len>=3) die("non-triangular face in triangulation");
            dart_face[cur]=f;
            face_vert[f][len]=dart_u[cur];
            face_edge[f][len]=edge_of[dart_u[cur]][dart_v[cur]];
            u=dart_u[cur]; v=dart_v[cur];
            /* (u,v) -> (v, predecessor of u around v). */
            w=-1;
            for (j=0;j<deg0[v];j++) if (rot[v][j]==u) {w=rot[v][(j+deg0[v]-1)%deg0[v]];break;}
            if (w<0) die("rotation mismatch");
            for (k=0;k<ND;k++) if (dart_u[k]==v && dart_v[k]==w) break;
            if (k==ND) die("successor dart absent");
            cur=k; len++;
        } while (cur!=start);
        if (len!=3) die("non-triangular face");
        f++;
    }
    if (f!=NF) die("wrong face count");
    for (j=0;j<NF;j++) for (k=0;k<3;k++) {
        int q,ee=face_edge[j][k],a=edges[ee].u,b=edges[ee].v,t=efcount[ee]++;
        if (t>=2) die("edge on more than two faces");
        edges[ee].f[t]=j;
        q=face_vert[j][0]; if (q==a||q==b) q=face_vert[j][1];
        if (q==a||q==b) q=face_vert[j][2];
        edges[ee].opp[t]=q;
    }
    for (i=0;i<NE;i++) {
        if (efcount[i]!=2) die("edge not on two faces");
        {
            int c=edges[i].opp[0],q=edges[i].opp[1];
            edges[i].ok=(c!=q && edge_of[c][q]<0);
            edges[i].addkey=(c<q?c*N+q:q*N+c);
        }
    }
}

static int perfect_after_delete(uint32_t mask, uint32_t nbr[N], signed char *memo)
{
    uint32_t bit,opts;
    int v,w;
    if (!mask) return 1;
    if (memo[mask]>=0) return memo[mask];
    bit=mask & (0u-mask); v=__builtin_ctz(bit); opts=nbr[v]&mask;
    while (opts) {
        uint32_t q=opts & (0u-opts); w=__builtin_ctz(q); (void)w;
        if (perfect_after_delete(mask^bit^q,nbr,memo)) return memo[mask]=1;
        opts^=q;
    }
    return memo[mask]=0;
}

static int factor_critical(void)
{
    uint32_t nbr[N]={0}, all=(1u<<N)-1;
    int i,v,a,b;
    for (i=0;i<NE;i++) {
        a=edges[i].u;b=edges[i].v;nbr[a]|=1u<<b;nbr[b]|=1u<<a;
    }
    for (i=0;i<NE;i++) if (chosen[i]) {
        a=edges[i].opp[0];b=edges[i].opp[1];nbr[a]|=1u<<b;nbr[b]|=1u<<a;
    }
    for (v=0;v<N;v++) {
        signed char *memo=malloc(1u<<N); /* only masks avoiding v are reached */
        if (!memo) die("out of memory");
        memset(memo,-1,1u<<N); memo[0]=1;
        if (!perfect_after_delete(all^(1u<<v),nbr,memo)) {free(memo);return 0;}
        free(memo);
    }
    return 1;
}

static void evaluate(void)
{
    int i,j,ds[N],tau[N]={0},dh[N],n3=0,zeros=0,ones=0,twos=0;
    ncomplete++;
    for (i=0;i<N;i++) {ds[i]=deg0[i]-dsel[i]; if (ds[i]==3)n3++;}
    if (n3!=2) return;
    nkite++;
    for (i=0;i<NF;i++) if (fstate[i]==0)
        for (j=0;j<3;j++) tau[face_vert[i][j]]++;
    for (i=0;i<N;i++) {
        dh[i]=2*ds[i]-tau[i];
        if (dh[i]>7) return;
        if (tau[i]==0) zeros++; else if (tau[i]==1) ones++; else if (tau[i]==2) twos++;
    }
    /* The two unresolved types are (0^2,1^16,2) and (0,1^18). */
    if (!((zeros==2&&ones==16&&twos==1) || (zeros==1&&ones==18&&twos==0))) return;
    ntype++;
    if (factor_critical()) {
        nfc++;
        printf("FOUND factor-critical graph %llu; deleted edges:",ngraphs);
        for (i=0;i<NE;i++) if (chosen[i]) printf(" %d-%d",edges[i].u+1,edges[i].v+1);
        putchar('\n'); fflush(stdout);
    }
}

static int feasible_degrees(void)
{
    int i,e,pot,extra=0,potface;
    for (i=0;i<N;i++) {
        int lo=deg0[i]-4, hi=deg0[i]-3;
        if (oadd[i]>7-deg0[i] || tun[i]>2) return 0;
        if (dsel[i]>hi) return 0;
        if (dsel[i]>lo) extra+=dsel[i]-lo;
        pot=0;
        for (e=0;e<NE;e++) if (edges[e].ok && !chosen[e]
              && fstate[edges[e].f[0]]<0 && fstate[edges[e].f[1]]<0
              && (edges[e].u==i || edges[e].v==i)) pot++;
        if (dsel[i]+pot<lo) return 0;
        /* A final skeleton degree 4 needs tau at least one. */
        if (dsel[i]==lo && pot==0 && tun[i]==0) {
            potface=0;
            for (e=0;e<NF;e++) if (fstate[e]<0
                    && (face_vert[e][0]==i || face_vert[e][1]==i || face_vert[e][2]==i)) {potface=1;break;}
            if (!potface) return 0;
        }
    }
    return extra<=2;
}

static void search(int nsel,int nunmatched)
{
    int i,j,f=-1,best=4,opts,remaining=0,e,a,b,key;
    if (nsel>14 || nunmatched>6) return;
    for (i=0;i<NF;i++) if (fstate[i]<0) remaining++;
    if (remaining != 2*(14-nsel)+(6-nunmatched)) return;
    if (!feasible_degrees()) return;
    if (!remaining) {evaluate();return;}
    for (i=0;i<NF;i++) if (fstate[i]<0) {
        opts=0;
        for (j=0;j<3;j++) {
            e=face_edge[i][j];
            if (edges[e].ok && fstate[edges[e].f[0]]<0 && fstate[edges[e].f[1]]<0
                    && !add_used[edges[e].addkey]
                    && oadd[edges[e].opp[0]]<7-deg0[edges[e].opp[0]]
                    && oadd[edges[e].opp[1]]<7-deg0[edges[e].opp[1]]) opts++;
        }
        if (opts<best) {best=opts;f=i;if (!best)break;}
    }
    if (f<0) die("search state");
    if (nunmatched<6) {
        int ntwo=0,good=1;
        fstate[f]=0;
        for (i=0;i<3;i++) {tun[face_vert[f][i]]++;if(tun[face_vert[f][i]]>2)good=0;}
        for (i=0;i<N;i++) if(tun[i]==2)ntwo++;
        if (good && ntwo<=1) search(nsel,nunmatched+1);
        for (i=0;i<3;i++) tun[face_vert[f][i]]--;
        fstate[f]=-1;
    }
    for (j=0;j<3;j++) {
        e=face_edge[f][j]; a=edges[e].f[0]; b=edges[e].f[1]; key=edges[e].addkey;
        if (!edges[e].ok || fstate[a]>=0 || fstate[b]>=0 || add_used[key]
                || oadd[edges[e].opp[0]]>=7-deg0[edges[e].opp[0]]
                || oadd[edges[e].opp[1]]>=7-deg0[edges[e].opp[1]]) continue;
        fstate[a]=fstate[b]=1; chosen[e]=1; add_used[key]=1;
        dsel[edges[e].u]++;dsel[edges[e].v]++;
        oadd[edges[e].opp[0]]++;oadd[edges[e].opp[1]]++;
        search(nsel+1,nunmatched);
        oadd[edges[e].opp[0]]--;oadd[edges[e].opp[1]]--;
        dsel[edges[e].u]--;dsel[edges[e].v]--;
        add_used[key]=0;chosen[e]=0;fstate[a]=fstate[b]=-1;
    }
}

int main(int argc,char **argv)
{
    FILE *in; char header[16]={0}; int i,maxd,bad;
    if (argc!=2) {fprintf(stderr,"usage: %s tri19m4.plc\n",argv[0]);return 2;}
    in=fopen(argv[1],"rb"); if(!in) die("cannot open input");
    if (fread(header,1,15,in)!=15 || memcmp(header,">>planar_code<<",15)) die("bad planar_code header");
    while (read_graph(in)) {
        ngraphs++; maxd=0; for(i=0;i<N;i++) if(deg0[i]>maxd)maxd=deg0[i];
        if (maxd>7) continue;
        ndegok++; build_embedding();
        memset(fstate,-1,sizeof(fstate));memset(chosen,0,sizeof(chosen));
        memset(add_used,0,sizeof(add_used));memset(dsel,0,sizeof(dsel));
        memset(oadd,0,sizeof(oadd));memset(tun,0,sizeof(tun));
        search(0,0);
    }
    fclose(in);
    printf("graphs=%llu maxdeg<=7=%llu complete_matchings=%llu kite_simple=%llu target_type=%llu factor_critical=%llu\n",
      ngraphs,ndegok,ncomplete,nkite,ntype,nfc);
    bad=(ngraphs!=312552 || ndegok!=312552 || ncomplete!=0 ||
         nkite!=0 || ntype!=0 || nfc!=0);
    return bad?1:0;
}
