# 19-vertex skeleton certificate

Source: official `plantri` distribution, version 5.5 (17 May 2024), from
https://users.cecs.anu.edu.au/~bdm/plantri/ .  The two source files used are
copied here unchanged as `plantri.c` and `allowed_deg.c`.

Build and generate the complete input:

```sh
cc -O3 -o plantri_ad '-DPLUGIN="allowed_deg.c"' plantri.c
./plantri_ad -F4F5F6F7 19 tri19_4567.plc
```

`plantri` reports exactly 312552 triangulations.  Build and run the independent
checker from this directory:

```sh
cc -O3 -Wall -Wextra -o verify19 verify_19_skeletons.c
./verify19 tri19_4567.plc
```

Observed output:

```text
graphs=312552 maxdeg<=7=312552 complete_matchings=0 kite_simple=0 target_type=0 factor_critical=0
```

Here `complete_matchings` is not the number of all raw 14-matchings.  The DFS
counts a completion only after sound necessary partial-state tests enforce:
final skeleton degrees in `{3,4}`; at most one vertex with triangular-face
incidence two and none larger; degree at most seven after adding every opposite
diagonal; and opposite diagonals absent from the triangulation and unrepeated.
Zero therefore says no raw matching survives all necessary conditions.
The checker also rejects malformed adjacency rows and truncated or oversized
encodings, and exits successfully only for the exact displayed graph and
counter totals.  In particular, an empty or header-only input is a failure.

SHA-256:

```text
dff91dd22812e0344ffeaaa929a5c61b98cb50f35c1b4fa94fcb2b15e7a8085a  plantri.c
b0983fb0ad97812e34e1a578f9aba635f866f5291536bc4009205e268b12a9fb  allowed_deg.c
388ec7059d7aafbd91e9c136b46ea5ac9d04e9e3c14a1bea7bbf2e51ae9f181e  tri19_4567.plc
8972ce4439108136ff1532f620f4a416d83262182ae2370870759d883b5767da  verify_19_skeletons.c
```
