/* Exhaust the only surviving uncrossed-parallel a=1 branch directly in
 * the dual class of quartic plane multigraphs.
 *
 * Let S+ be the augmented full-kite skeleton.  In the surviving branch it
 * is 4-regular, has faces 8*3+19*4, tau signature 2,1^22,0^2, and has
 * exactly one parallel pair: the old uncrossed pole edge and the temporary
 * augmentation copy.  Its plane dual Q is a (possibly non-simple)
 * quadrangulation with 27 vertices and degrees 3^8 4^19.  plantri's -Q
 * generator is complete for precisely this class and is much smaller than
 * generating the 25-vertex hexagonal residual as a general polytope.
 *
 * Compile beside official plantri 5.8 and run (split res/mod as desired):
 *
 *   cc -O3 -o plantri_pq25 -DPLUGIN=cert25_parallel_quartic_plugin.c plantri.c
 *   ./plantri_pq25 -E -Q -m3 27 parallel_quartic25.ec
 *
 * The FILTER independently constructs the dual S+ and requires exactly one
 * double edge joining its two tau-zero vertices.  Every Q passing that
 * exact marked target is emitted in edge_code (-E is important because Q
 * can have parallel edges).  The filter also collapses
 * the pair to the single old edge of H, inserts the two diagonals of every
 * quadrilateral, and checks global simplicity, degree sequence 7^24,6, and
 * factor-criticality.  The emitted dual maps let a separate verifier redo
 * all reconstruction tests.  SUMMARY prints all intermediate counts.
 */

#include <stdint.h>

#define PRE_FILTER_MULTIQUAD pq25_pre_filter()
#define FAST_FILTER_MULTIQUAD pq25_pre_filter()
#define FILTER pq25_filter
#define SUMMARY pq25_summary

#ifdef PQ25_EMIT_SUPERSET
#define PQ25_LATE_REJECT TRUE
#else
#define PQ25_LATE_REJECT FALSE
#endif

static unsigned long long pq25_seen, pq25_degree_faces, pq25_tau;
static unsigned long long pq25_double, pq25_kite_simple, pq25_degok, pq25_fc;

/* Every general-quadrangulation expansion creates one vertex.  Relative
 * to the final allowed degrees {3,4}, a P1 step is the only operation
 * which can lower an old degree, and it lowers just one by one.  Hence it
 * can remove at most one unit of high-degree excess.  Low-degree deficit
 * can fall by at most two per step (P0/D1 create a new deficit of one/two),
 * and total distance from {3,4} can fall by at most three.  These three
 * inequalities are therefore necessary conditions, not heuristic prunes.
 */
static int pq25_pre_filter(void)
{
    int i,d,rem=27-nv,high=0,low=0,err=0;
    if(rem<0)return FALSE;
    for(i=0;i<nv;++i)
    {
        d=degree[i];
        if(d<3){low+=3-d;err+=3-d;}
        else if(d>4){high+=d-4;err+=d-4;}
    }
    return high<=rem && low<=2*rem && err<=3*rem;
}

static int pq25_perfect(uint32_t mask,const uint32_t nbr[25])
{
    uint32_t rest,bit,opts;int i,v=-1,best=26;
    if(!mask)return TRUE;
    rest=mask;
    while(rest)
    {
        bit=rest&(0u-rest);i=__builtin_ctz(bit);opts=nbr[i]&mask;
        if(__builtin_popcount(opts)<best)
        {best=__builtin_popcount(opts);v=i;if(best==0)return FALSE;}
        rest^=bit;
    }
    bit=1u<<v;opts=nbr[v]&mask;
    while(opts)
    {
        uint32_t q=opts&(0u-opts);
        if(pq25_perfect(mask^bit^q,nbr))return TRUE;
        opts^=q;
    }
    return FALSE;
}

static int pq25_factor_critical(unsigned char adj[25][25])
{
    uint32_t nbr[25]={0},all=(1u<<25)-1;int i,j,v;
    for(i=0;i<25;++i)for(j=0;j<25;++j)if(adj[i][j])nbr[i]|=1u<<j;
    for(v=0;v<25;++v)if(!pq25_perfect(all^(1u<<v),nbr))return FALSE;
    return TRUE;
}

static int pq25_filter(int nbtot,int nbop,int doflip)
{
    EDGE *darts[100],*e,*last,*p;
    int faceof[NUMEDGES],fv[25][4],nf=0,nd=0;
    int i,j,k,len,id,f,g,n3=0,n4=0,tau[25];
    int mult[25][25],double_u=-1,double_v=-1,ndouble=0;
    int around[4],unique_edges=0,m,deg,n6=0,n7=0;
    unsigned char adj[25][25];
    (void)nbtot;(void)nbop;(void)doflip;
    if(nv!=27||ne!=100)return FALSE;
    ++pq25_seen;
    for(i=0;i<nv;++i)
    {
        if(degree[i]==3)++n3;
        else if(degree[i]==4)++n4;
        else return FALSE;
        e=last=firstedge[i];
        do{if(nd>=100)return FALSE;darts[nd++]=e;e=e->next;}while(e!=last);
    }
    if(n3!=8||n4!=19||nd!=100)return FALSE;
    for(i=0;i<NUMEDGES;++i)faceof[i]=-1;
    RESETMARKS;
    for(i=0;i<100;++i)if(!ISMARKED(darts[i]))
    {
        if(nf>=25)return FALSE;
        len=0;p=darts[i];
        do
        {
            if(len>=4)return FALSE;
            id=(int)(p-edges);if(id<0||id>=NUMEDGES)return FALSE;
            MARK(p);faceof[id]=nf;fv[nf][len++]=p->start;
            p=p->invers->next;
        }while(p!=darts[i]);
        if(len!=4)return FALSE;
        for(j=0;j<4;++j)for(k=j+1;k<4;++k)
            if(fv[nf][j]==fv[nf][k])return FALSE;
        ++nf;
    }
    if(nf!=25)return FALSE;
    ++pq25_degree_faces;

    for(i=0;i<25;++i){tau[i]=0;for(j=0;j<25;++j)mult[i][j]=0;}
    for(f=0;f<25;++f)
        for(j=0;j<4;++j)if(degree[fv[f][j]]==3)++tau[f];
    {int c0=0,c1=0,c2=0;
     for(i=0;i<25;++i){if(tau[i]==0)++c0;else if(tau[i]==1)++c1;
                       else if(tau[i]==2)++c2;else return PQ25_LATE_REJECT;}
     if(c0!=2||c1!=22||c2!=1)return PQ25_LATE_REJECT;}
    ++pq25_tau;

    for(i=0;i<100;++i)if(darts[i]==darts[i]->min)
    {
        int ei=(int)(darts[i]-edges);
        int ri=(int)(darts[i]->invers-edges);
        if(ei<0||ei>=NUMEDGES||ri<0||ri>=NUMEDGES)return FALSE;
        f=faceof[ei];g=faceof[ri];
        if(f<0||g<0||f==g)return PQ25_LATE_REJECT;
        ++mult[f][g];++mult[g][f];
    }
    memset(adj,0,sizeof(adj));
    for(f=0;f<25;++f)for(g=f+1;g<25;++g)if(mult[f][g])
    {
        if(mult[f][g]==1){adj[f][g]=adj[g][f]=1;++unique_edges;}
        else if(mult[f][g]==2)
        {
            ++ndouble;double_u=f;double_v=g;
            adj[f][g]=adj[g][f]=1;++unique_edges;
        }
        else return PQ25_LATE_REJECT;
    }
    if(ndouble!=1||unique_edges!=49||tau[double_u]||tau[double_v])
        return PQ25_LATE_REJECT;
    ++pq25_double;

    /* A degree-4 primal vertex is a quadrilateral face of S+.  The four
       primal faces incident around it are the four vertices of that face. */
    for(i=0;i<27;++i)if(degree[i]==4)
    {
        e=last=firstedge[i];j=0;
        do
        {
            id=(int)(e-edges);
            if(id<0||id>=NUMEDGES||j>=4)return TRUE;
            around[j++]=faceof[id];e=e->next;
        }while(e!=last);
        if(j!=4)return TRUE;
        for(j=0;j<4;++j)for(k=j+1;k<4;++k)
            if(around[j]==around[k])return TRUE;
        for(j=0;j<2;++j)
        {
            f=around[j];g=around[j+2];
            if(f==g||adj[f][g])return TRUE;
            adj[f][g]=adj[g][f]=1;
        }
    }
    ++pq25_kite_simple;
    m=0;
    for(i=0;i<25;++i)
    {
        deg=0;for(j=0;j<25;++j)if(adj[i][j]){++deg;if(i<j)++m;}
        if(deg==6)++n6;else if(deg==7)++n7;else return TRUE;
    }
    if(m!=87||n6!=1||n7!=24)return TRUE;
    ++pq25_degok;
    if(pq25_factor_critical(adj))++pq25_fc;
    return TRUE;
}

static void pq25_summary(void)
{
    fprintf(msgfile,
      "parallel-quartic certificate: seen=%llu degree_faces=%llu tau=%llu "
      "emitted_one_double=%llu kite_simple=%llu degree_7^24_6=%llu "
      "factor_critical=%llu\n",
      pq25_seen,pq25_degree_faces,pq25_tau,pq25_double,pq25_kite_simple,
      pq25_degok,pq25_fc);
}
