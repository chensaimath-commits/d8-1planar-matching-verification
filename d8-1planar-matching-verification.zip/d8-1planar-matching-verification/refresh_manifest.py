#!/usr/bin/env python3
"""Regenerate the repository-wide SHA-256 manifest."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST.sha256"

PAPER_BUILD_SUFFIXES = (
    ".aux",
    ".bbl",
    ".blg",
    ".fdb_latexmk",
    ".fls",
    ".log",
    ".out",
    ".synctex.gz",
    ".toc",
)

LOCAL_REGENERATION_FILES = {
    "cert19/verify19.local",
    "cert25_core/plantri58",
    "cert25_parallel/plantri_pq25_exact",
    "cert25_parallel/plantri_pq25_superset",
}


def is_excluded(path: Path, root: Path = ROOT) -> bool:
    relative = path.relative_to(root)
    parts = relative.parts
    name = relative.name
    posix = relative.as_posix()
    if posix == "MANIFEST.sha256":
        return True
    if ".git" in parts or "__pycache__" in parts:
        return True
    if name.endswith((".pyc", ".pyo")):
        return True
    if relative.parent == Path("paper") and name.endswith(PAPER_BUILD_SUFFIXES):
        return True
    if posix in LOCAL_REGENERATION_FILES:
        return True
    if posix.startswith("cert25_core/cubic14_all.rebuilt."):
        return True
    return False


def iter_manifest_files(root: Path = ROOT):
    paths = (path for path in root.rglob("*") if path.is_file())
    yield from sorted(
        (path for path in paths if not is_excluded(path, root)),
        key=lambda path: path.relative_to(root).as_posix(),
    )


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    lines = [
        f"{digest(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in iter_manifest_files()
    ]
    temporary = MANIFEST.with_suffix(".sha256.tmp")
    temporary.write_text("\n".join(lines) + "\n", encoding="ascii")
    temporary.replace(MANIFEST)
    print(f"wrote {MANIFEST.name}: {len(lines)} files")


if __name__ == "__main__":
    main()

