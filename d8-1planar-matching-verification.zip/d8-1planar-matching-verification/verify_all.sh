#!/bin/sh
set -eu

export PYTHONDONTWRITEBYTECODE=1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

command -v python3 >/dev/null
command -v cc >/dev/null

VERIFY_TMP=$(mktemp -d "${TMPDIR:-/tmp}/d8-verify.XXXXXX")
cleanup()
{
    rm -rf -- "$VERIFY_TMP"
}
trap cleanup EXIT HUP INT TERM

python3 "$ROOT/verify_repository_manifest.py"

cc -O3 -std=c99 -Wall -Wextra -Werror \
  -o "$VERIFY_TMP/verify19" \
  "$ROOT/cert19/verify_19_skeletons.c"
"$VERIFY_TMP/verify19" "$ROOT/cert19/tri19_4567.plc"
printf '%s\n' "PASS case r09_k2_a0: no residual counterexample"

(
  cd "$ROOT/cert23"
  python3 verify_23_quartic.py quartic23_F3x8_F4x17.plc
)
printf '%s\n' "PASS case r11_k3_a0: no residual counterexample"

(
  cd "$ROOT/cert25B"
  python3 verify_typeB25.py octa25c2.plc
)

cc -O3 -std=c99 -Wall -Wextra -Werror -DCORE_ACCEPT_SUPERSET \
  -o "$VERIFY_TMP/verify_core_superset" \
  "$ROOT/cert25_core/verify_core_duals.c"
(
  cd "$ROOT/cert25_core"
  python3 verify_run_parts.py
  D8_CORE_SUPERSET_VERIFIER="$VERIFY_TMP/verify_core_superset" \
    python3 verify_superset_manifest.py
)
printf '%s\n' "PASS case r12_k3_a0: no residual counterexample"

(
  cd "$ROOT/cert25_parallel"
  python3 verify_manifest.py
)
printf '%s\n' "PASS case r12_k3_a1: no residual counterexample"

(
  cd "$ROOT/constructions"
  python3 verify_blocks.py
)

python3 - "$ROOT/release/d8_exact_bound_certificate_bundle.tar.gz" <<'PY'
from hashlib import sha256
from pathlib import Path
import sys

expected = "1604f65cc43a9c987fc1088ee2519d66069d8f08aa86f8ffa7f75da816128d0d"
actual = sha256(Path(sys.argv[1]).read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit(f"release archive SHA-256 mismatch: {actual}")
print(f"PASS paper-locked release archive sha256={actual}")
PY

printf '%s\n' "PASS all recorded certificate checks"
