# 上传到你自己的 GitHub 账户

建议仓库名：`d8-1planar-matching-verification`。这个名称直接说明仓库
保存的是论文中 $d=8$ 情形的计算机验证，而不是论文正文的另一个版本。

1. 解压交付的 ZIP。
2. 在 GitHub 新建一个**空仓库**，不要勾选自动创建 README、License 或
   `.gitignore`，并记下最终仓库 URL。
3. 进入解压后的目录，在
   `paper/d8_exact_1planar_matching_bound.tex` 的 “Data and code
   availability” 小节中，把

   ```text
   The public repository URL will be inserted here after deposit.
   ```

   替换为例如：

   ```tex
   The complete source repository is publicly available at
   \url{https://github.com/<YOUR-GITHUB-USERNAME>/d8-1planar-matching-verification}.
   ```

4. 根据你希望公开授予的权利添加顶层 `LICENSE`；现有
   `LICENSE-NOTICE.md` 只说明当前授权状态，不替你选择开源许可证。
5. 重新编译论文、刷新哈希并验证：

   ```sh
   cd paper
   pdflatex -interaction=nonstopmode -halt-on-error d8_exact_1planar_matching_bound.tex
   pdflatex -interaction=nonstopmode -halt-on-error d8_exact_1planar_matching_bound.tex
   cd ..
   python3 refresh_manifest.py
   python3 run_verification.py all
   ```

   论文编译产生的辅助文件已由 `.gitignore` 排除。

   正常结束时应明确出现四行 `PASS case ...`，分别对应
   `(9,2,0)`、`(11,3,0)`、`(12,3,0)` 和 `(12,3,1)`。
6. 把 `<YOUR-GITHUB-USERNAME>` 换成你的用户名，然后执行：

   ```sh
   git init
   git add .
   git commit -m "Initial public release"
   git branch -M main
   git remote add origin https://github.com/<YOUR-GITHUB-USERNAME>/d8-1planar-matching-verification.git
   git push -u origin main
   ```

如果使用 SSH，把远程地址改为：

```text
git@github.com:<YOUR-GITHUB-USERNAME>/d8-1planar-matching-verification.git
```
