# Computer verification for the $d=8$ 1-planar matching bound

This repository accompanies the paper **“Maximum Size of 1-Planar Graphs
with Maximum Degree Seven and Bounded Matching Number.”** The paper reduces
the upper bound to four finite plane-map exclusions. This repository records
and independently checks those exclusions, and also verifies the three blocks
used in the sharp constructions.

Here $d=8$ means that every graph has maximum degree less than $8$, or
equivalently at most $7$.

## Parameters and main result

For a 2-connected factor-critical block $H$, write

```text
|V(H)| = 2R+1,        |E(H)| = 7R+k.
```

Here $R=\nu(H)$ is the matching contribution of the block, $k$ is its edge
bonus over the baseline $7R$, and $a$ is the number of uncrossed edges added
when a fixed 1-plane drawing is completed to a triangulated augmentation.
For a plane skeleton, $\tau(v)$ denotes the number of triangular-face
incidences at $v$, counted with facial multiplicity.

Let $t=s-1=13q+\beta$, where $0\leq\beta\leq12$. Among simple 1-planar graphs
with maximum degree at most seven and matching number at most $t$, the maximum
number of edges is

```text
7t + 3q + rho(beta),

rho(beta) = 0  for 0 <= beta <= 6,
            1  for 7 <= beta <= 9,
            2  for 10 <= beta <= 12.
```

Equality is attained by disjoint unions of $K_{1,7}$ and the certified blocks
$B_7$, $B_{10}$, and $B_{13}$.

## The four finite exclusions

The mathematical reductions are proved in the paper. The computer-assisted
part consists of exactly the following four cases.

| Case ID | Descriptive title | $(R,k,a)$ | Certificate components | Decisive result |
|---|---|---:|---|---|
| [`r09_k2_a0`](cases/r09_k2_a0/) | 19-vertex dual-matching exclusion | $(9,2,0)$ | `cert19` | 312,552 triangulations; `complete_matchings=0` |
| [`r11_k3_a0`](cases/r11_k3_a0/) | 23-vertex triangle-incidence exclusion | $(11,3,0)$ | `cert23` | 33 maps; `target_tau_1x22_2=0` |
| [`r12_k3_a0`](cases/r12_k3_a0/) | 25-vertex zero-augmentation Profiles X/Y exclusion | $(12,3,0)$ | `cert25B`, `cert25_core` | `type_B=0`; `exact_patch_phases=0` |
| [`r12_k3_a1`](cases/r12_k3_a1/) | 25-vertex one-edge-augmentation exclusion (simple-new and parallel-pole branches) | $(12,3,1)$ | `cert25B`, `cert25_core`, `cert25_parallel` | every simple-new and parallel-pole branch is empty |

The low-level `cert*` directory names are historical names used by the
paper-locked archive, scripts, and SHA-256 manifests. They are therefore kept
unchanged. In particular, the legacy counter `type_B` in `cert25B` is the
counter for **Profile Y** in the current mathematical notation.

## Quick start

From the repository root, list the four available checks:

```sh
python3 run_verification.py --list
```

Verify one case with its descriptive name:

```sh
python3 run_verification.py dual-matching-19
```

Verify the complete recorded certificate package:

```sh
python3 run_verification.py all
```

The equivalent Make command is:

```sh
make verify
```

No source parameters need to be edited.

## Code structure

| Path | Purpose |
|---|---|
| `cases/` | User-facing specifications and entry points for the four finite exclusions |
| `cert19/` | 19-vertex dual-matching certificate for `r09_k2_a0` |
| `cert23/` | 23-vertex triangle-incidence certificate for `r11_k3_a0` |
| `cert25B/` | Quartic-map certificate for Profile Y and two simple-new quartic profiles |
| `cert25_core/` | Common core search for Profile X and the remaining simple-new profile |
| `cert25_parallel/` | Parallel-pole certificate for `r12_k3_a1` |
| `constructions/` | Certificates and verifier for $B_7$, $B_{10}$, and $B_{13}$ |
| `paper/` | LaTeX source and compiled manuscript |
| `release/` | Immutable certificate archive cited in the paper |
| `run_verification.py` | Primary command-line interface; accepts case IDs or descriptive names |
| `verify_case.sh`, `verify_all.sh` | Low-level compatibility entry points used by the Python interface |
| `RESULTS.md` | Compact record of the decisive search sizes and zero counts |
| `MANIFEST.sha256` | Root integrity manifest for repository artifacts |

Each certificate directory contains a technical README describing its
generation class, reduction, reference counts, hashes, and full-regeneration
commands.

## Expected output

A successful single-case run ends with

```text
PASS case CASE_ID: no residual counterexample
```

and a successful complete run ends with

```text
PASS all recorded certificate checks
```

The locked decisive counts are as follows.

- **19-vertex dual matching.** The catalogue contains 312,552
  triangulations, and the independent C search returns
  `complete_matchings=0`.
- **23-vertex triangle incidence.** The dual generation contains exactly 33
  embedded maps, and the rotation-system checker returns
  `target_tau_1x22_2=0`.
- **25 vertices, $a=0$.** For Profile Y, 51 dual maps and 1,938 inverse
  reconstructions give `type_B=0`. For Profile X, 152,706 connected cubic
  plane-multigraph inputs, 276,001,884 matchings, and 1,742,712,513
  special-face-role assignments give `simple_D=139893` and
  `exact_patch_phases=0`. A wider audit independently checks 52,169 maps and
  30,049,344 inverse phases, again obtaining no exact residual.
- **25 vertices, $a=1$.** In the simple-new quartic branches,
  `tau_0^1_1^24=0`; the second required incidence signature occurs in two
  maps, but `quartic2_pole_markings=0`. The common-core audit gives
  `exact_R=0` and `profile_R=0`. In the parallel-pole branch, 1,189 generator
  leaves reach the final filter, 51 have the required degree/face data, and
  two have the target triangle-incidence signature, but
  `exact_tau_one_double=0`.

## Prerequisites

Recorded verification requires:

- a POSIX shell;
- Python 3.9 or later; and
- a C99 compiler available as `cc`.

The Python verifiers use only the standard library. The exact official
plantri 5.8 source used for the common-core and parallel certificates is
bundled with its Apache 2.0 license. The construction verifier uses Python
assertions and must not be run with `python -O`.

## Reproducibility

`verify_all.sh` checks `MANIFEST.sha256`, recompiles the 19-vertex checker,
validates the stored catalogues, streams, logs, and shard manifests, and
reruns the independent checkers on every nonempty audit catalogue. The deep
common-core audit also recompiles `verify_core_duals.c` in a temporary
directory and runs that fresh binary on all 52,169 nonempty audit maps. The
hash of the historical x86-64 Linux binary is checked separately, preserving
the provenance of the recorded run while exercising the current source on
Linux and macOS.

Recorded verification does **not** regenerate every plantri catalogue or
repeat the most expensive exhaustive inverse run. The latter visited
276,001,884 matchings and 1,742,712,513 special-face-role assignments. Full
regeneration commands are given in the individual certificate READMEs.

After an intentional artifact change, refresh and recheck the root manifest:

```sh
python3 refresh_manifest.py
./verify_all.sh
```

The paper-locked archive is
`release/d8_exact_bound_certificate_bundle.tar.gz`, with SHA-256 digest

```text
1604f65cc43a9c987fc1088ee2519d66069d8f08aa86f8ffa7f75da816128d0d
```

The Git repository additionally includes the manuscript, top-level helpers,
and vendored plantri provenance files; it is intentionally not a byte-for-byte
unpacking of the archive.

## Citation and questions

Citation metadata are provided in [`CITATION.cff`](CITATION.cff). For
questions or comments, open a GitHub issue or contact the corresponding author
listed there.

## Licensing notice

This draft does not yet select a repository-wide license for the authors'
manuscript and original certificate code. Before public release, the authors
should add the license they intend to grant. Bundled third-party generator
sources remain subject to their upstream terms; see
[`LICENSE-NOTICE.md`](LICENSE-NOTICE.md) and the plantri notices shipped with
the source copies.
