#!/usr/bin/env python3
"""Independent verifier for the n=25 type-X planar-code certificate.

The generator emits every plane map with

    3 * (degree,tau)=(5,3), 1 * (3,0), 21 * (4,1),

where tau is the number of incident triangular faces.  For each emitted
map this verifier reconstructs the facial walks from the rotation system,
checks the profile, inserts both crossed diagonals in every quadrilateral,
checks global simplicity and degree sequence 7^24,6, and finally tests
factor-criticality.  Exit status is zero exactly when the input is valid
and no factor-critical completion is present.

Usage:
    python3 verify_25_typeX.py typeX25-0.plc [typeX25-1.plc ...]
"""

from collections import Counter
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import sys


HEADER = (b">>planar_code le<<", b">>planar_code<<")


class VerificationError(RuntimeError):
    pass


def fail(message):
    raise VerificationError(message)


def read_planar_strict(path, expected_order=25):
    """Read the one-byte planar_code used here, rejecting truncated data."""
    pth = Path(path)
    if not path:
        fail("empty input path")
    if not pth.is_file():
        fail(f"not a regular file: {path}")
    data = pth.read_bytes()
    if not data:
        fail(f"empty file (missing planar_code header): {path}")
    header = next((h for h in HEADER if data.startswith(h)), None)
    if header is None:
        fail(f"missing planar_code header: {path}")
    pos = len(header)
    record = 0
    while pos < len(data):
        n = data[pos]
        pos += 1
        if n == 0:
            fail(f"{path}: record {record}: unexpected wide planar_code")
        if n != expected_order:
            fail(f"{path}: record {record}: order {n}, expected {expected_order}")
        rotation = []
        for v in range(n):
            row = []
            while True:
                if pos >= len(data):
                    fail(f"{path}: record {record}: truncated adjacency of {v}")
                x = data[pos]
                pos += 1
                if x == 0:
                    break
                if x > n:
                    fail(f"{path}: record {record}: neighbour {x} out of range")
                row.append(x - 1)
            rotation.append(row)
        yield record, rotation
        record += 1


def edge(u, v):
    return (u, v) if u < v else (v, u)


def validate_rotation(rotation, label, expected_edges=51, connectivity=3):
    n = len(rotation)
    for v, row in enumerate(rotation):
        if not row:
            fail(f"{label}: isolated vertex {v}")
        if v in row:
            fail(f"{label}: loop at vertex {v}")
        if len(row) != len(set(row)):
            fail(f"{label}: repeated neighbour at vertex {v}")
        for u in row:
            if not (0 <= u < n):
                fail(f"{label}: neighbour out of range at vertex {v}")
            if v not in rotation[u]:
                fail(f"{label}: adjacency {v}-{u} is not reciprocal")

    edges = {edge(v, u) for v, row in enumerate(rotation) for u in row}
    if sum(map(len, rotation)) != 2 * len(edges):
        fail(f"{label}: inconsistent edge multiplicities")
    if len(edges) != expected_edges:
        fail(f"{label}: has {len(edges)} edges, expected {expected_edges}")

    def connected_after(removed):
        alive = [v for v in range(n) if v not in removed]
        reached = {alive[0]}
        stack = [alive[0]]
        while stack:
            v = stack.pop()
            for u in rotation[v]:
                if u not in removed and u not in reached:
                    reached.add(u)
                    stack.append(u)
        return len(reached) == len(alive)

    if not connected_after(set()):
        fail(f"{label}: disconnected graph")
    if connectivity >= 2:
        for u in range(n):
            if not connected_after({u}):
                fail(f"{label}: vertex connectivity is less than two")
    if connectivity >= 3:
        for u in range(n):
            for v in range(u + 1, n):
                if not connected_after({u, v}):
                    fail(f"{label}: vertex connectivity is less than three")
    return edges


def facial_cycles(rotation, label):
    """Return face boundaries induced by the supplied cyclic rotations."""
    successor = {}
    darts = set()
    for v, row in enumerate(rotation):
        for i, u in enumerate(row):
            darts.add((v, u))
            successor[(u, v)] = (v, row[(i - 1) % len(row)])
    if set(successor) != darts:
        fail(f"{label}: rotation does not define all dart successors")

    seen = set()
    faces = []
    for start in sorted(darts):
        if start in seen:
            continue
        cur = start
        local = set()
        face = []
        while cur not in local:
            if cur in seen:
                fail(f"{label}: facial walk merges into an earlier walk")
            local.add(cur)
            face.append(cur[0])
            try:
                cur = successor[cur]
            except KeyError:
                fail(f"{label}: missing successor for dart {cur}")
        if cur != start:
            fail(f"{label}: facial walk closes before returning to its start")
        if len(face) != len(set(face)):
            fail(f"{label}: non-simple face boundary {face}")
        seen.update(local)
        faces.append(face)
    if seen != darts:
        fail(f"{label}: not all darts lie on a face")
    if len(rotation) - len(darts) // 2 + len(faces) != 2:
        fail(f"{label}: rotation system is not spherical")
    if sum(map(len, faces)) != len(darts):
        fail(f"{label}: face-length identity failed")
    return faces


def tau_vector(faces, n):
    tau = [0] * n
    for face in faces:
        if len(face) == 3:
            for v in face:
                tau[v] += 1
    return tau


def kite_completion(base, faces):
    completed = set(base)
    for face in faces:
        if len(face) != 4:
            continue
        for u, v in ((face[0], face[2]), (face[1], face[3])):
            e = edge(u, v)
            if u == v or e in completed:
                return None
            completed.add(e)
    return completed


def degrees(n, edges):
    answer = [0] * n
    for u, v in edges:
        answer[u] += 1
        answer[v] += 1
    return sorted(answer)


def has_perfect_matching(mask, nbr):
    @lru_cache(maxsize=None)
    def visit(current):
        if current == 0:
            return True
        best_v = -1
        best_options = 1 << 30
        scan = current
        while scan:
            bit = scan & -scan
            v = bit.bit_length() - 1
            options = nbr[v] & current
            count = options.bit_count()
            if count < best_options:
                best_v, best_options = v, count
                if count == 0:
                    return False
            scan ^= bit
        vbit = 1 << best_v
        options = nbr[best_v] & current
        while options:
            wbit = options & -options
            if visit(current ^ vbit ^ wbit):
                return True
            options ^= wbit
        return False

    return visit(mask)


def factor_critical(n, edges):
    nbr = [0] * n
    for u, v in edges:
        nbr[u] |= 1 << v
        nbr[v] |= 1 << u
    all_vertices = (1 << n) - 1
    return all(has_perfect_matching(all_vertices ^ (1 << v), nbr)
               for v in range(n))


def main(argv):
    if not argv:
        fail("no planar_code input paths supplied")

    counts = Counter()
    hashes = []
    for path in argv:
        pth = Path(path)
        raw = pth.read_bytes() if pth.is_file() else b""
        hashes.append((path, sha256(raw).hexdigest()))
        file_records = 0
        for record, rotation in read_planar_strict(path):
            file_records += 1
            counts["maps"] += 1
            label = f"{path}: record {record}"
            base = validate_rotation(rotation, label)
            faces = facial_cycles(rotation, label)
            if Counter(map(len, faces)) != Counter({3: 10, 4: 18}):
                fail(f"{label}: face inventory is not 10T+18Q")
            tau = tau_vector(faces, 25)
            profile = Counter((len(rotation[v]), tau[v]) for v in range(25))
            target = Counter({(5, 3): 3, (3, 0): 1, (4, 1): 21})
            if profile != target:
                fail(f"{label}: wrong (degree,tau) profile: {profile}")
            counts["profile"] += 1

            completed = kite_completion(base, faces)
            if completed is None:
                continue
            counts["kite_simple"] += 1
            if len(completed) != 87:
                fail(f"{label}: simple kite completion has {len(completed)} edges")
            if degrees(25, completed) != [6] + [7] * 24:
                fail(f"{label}: simple kite completion has wrong degrees")
            counts["degree_7^24_6"] += 1
            if factor_critical(25, completed):
                counts["factor_critical"] += 1
                print(f"FOUND factor-critical completion: {label}")
        counts["files"] += 1
        counts["nonempty_files"] += bool(file_records)

    if counts["maps"] == 0:
        fail("all supplied planar_code files are header-only")
    if counts["profile"] != counts["maps"]:
        fail("not every emitted map has the exact target profile")

    for key in ("files", "nonempty_files", "maps", "profile",
                "kite_simple", "degree_7^24_6", "factor_critical"):
        print(f"{key}={counts[key]}")
    for path, digest in hashes:
        print(f"sha256 {digest}  {path}")
    if counts["factor_critical"]:
        print("certificate_result=FAIL: factor-critical reconstruction found")
        return 1
    print("certificate_result=PASS: no factor-critical reconstruction")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except VerificationError as exc:
        print(f"certificate_result=ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
