# Recorded verification results

The paper reduces the infinite extremal problem to four residual parameter
triples.  The checked-in catalogues and manifests record the following finite
computations.  A zero in the final column is the decisive exclusion.

| Verification | Main search size | Decisive recorded value |
|---|---:|---:|
| 19-vertex dual-matching exclusion, `(R,k,a)=(9,2,0)` | 312,552 triangulations | `complete_matchings=0` |
| 23-vertex triangle-incidence exclusion, `(11,3,0)` | 33 quartic plane maps | `target_tau_1x22_2=0` |
| 25-vertex zero-augmentation Profiles X/Y exclusion, `(12,3,0)` | 51 quartic maps and 152,706 common-core inputs | `type_B=0`, `exact_patch_phases=0` |
| 25-vertex one-edge-augmentation exclusion, `(12,3,1)` | 1,189 parallel-pole generator leaves, plus the shared simple-new searches | `exact_tau_one_double=0` and all simple-new residual counts zero |

The two 25-vertex verifications share the quartic-profile and common-residual
engines.  Shared code and input streams are checked once; this does not merge
the two mathematical cases.

## How to reproduce the table

Run the recorded certificate checks from the repository root:

```sh
python3 run_verification.py all
```

Success is explicit: every verification ends with a `PASS case ...` line and
the command exits with status zero.  A malformed input, changed hash, failed
structural test, or nonzero residual count terminates the command with a
nonzero status.

This command validates the checked-in certificate data.  It does not repeat
the most expensive catalogue generation and inverse enumeration.  Exact full
regeneration commands, generator versions, hashes, and reference counts are
given in the `cert*/README.md` files.
