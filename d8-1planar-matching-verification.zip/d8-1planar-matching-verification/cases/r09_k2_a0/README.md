# 19-vertex dual-matching exclusion

**Case ID:** `r09_k2_a0`  
**Parameters:** $(R,k,a)=(9,2,0)$  
**Certificate component:** [`cert19/`](../../cert19/)

## Mathematical target

A hypothetical factor-critical block would have 19 vertices, 65 edges, 14
crossings, and six uncrossed triangular regions. Deleting both diagonals from
each full kite would produce a simple 3-connected plane skeleton with 14
quadrilateral faces.

The paper reduces the two surviving local profiles to all 19-vertex plane
triangulations whose degrees lie in
$\{4,5,6,7\}$, together with all 14-edge matchings in their plane duals.

## Certificate and conclusion

`cert19/tri19_4567.plc` contains exactly 312,552 generated triangulations. The
independent C checker exhausts the dual-matching search after sound necessary
partial-state tests and returns

```text
complete_matchings=0
```

Therefore no target skeleton exists.

## Run

From the repository root:

```sh
python3 run_verification.py dual-matching-19
```

The exact case ID `r09_k2_a0` is accepted as an equivalent selector.

The run ends with:

```text
PASS case r09_k2_a0: no residual counterexample
```

See [`cert19/README.md`](../../cert19/README.md) for generator provenance, the
full-regeneration command, and locked hashes.
