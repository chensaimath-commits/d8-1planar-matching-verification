# 23-vertex triangle-incidence exclusion

**Case ID:** `r11_k3_a0`  
**Parameters:** $(R,k,a)=(11,3,0)$  
**Certificate component:** [`cert23/`](../../cert23/)

## Mathematical target

A hypothetical factor-critical block would have 23 vertices, 80 edges, and
degree sequence $7^{22},6$. Its only surviving full-kite skeleton profile is a
simple 3-connected 4-regular plane graph with eight triangular faces,
seventeen quadrilateral faces, and triangle-incidence multiset
$1^{22},2$.

Here $\tau(v)$ is the number of triangular-face incidences at $v$, counted
with facial multiplicity; the target multiset is therefore
$\{\tau(v):v\in V\}=1^{22},2$.

## Certificate and conclusion

Dual generation produces exactly 33 embedded maps. The independent
rotation-system checker verifies every encoding, facial walk, degree,
connectivity condition, and triangle-incidence multiset, and returns

```text
target_tau_1x22_2=0
```

Therefore no target skeleton exists.

## Run

From the repository root:

```sh
python3 run_verification.py triangle-incidence-23
```

The exact case ID `r11_k3_a0` is accepted as an equivalent selector.

The run ends with:

```text
PASS case r11_k3_a0: no residual counterexample
```

See [`cert23/README.md`](../../cert23/README.md) for the exact plantri command
and locked hashes.
