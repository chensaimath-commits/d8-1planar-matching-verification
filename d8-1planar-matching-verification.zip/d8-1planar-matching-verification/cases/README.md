# Four residual finite exclusions

The paper reduces the infinite extremal problem to the four cases indexed
below. For a factor-critical block $H$, the parameters are defined by
$|V(H)|=2R+1$ and $|E(H)|=7R+k$; the integer $a$ counts the uncrossed edges
added in the triangulated augmentation. The symbol $\tau(v)$ denotes
triangular-face incidence at $v$, counted with facial multiplicity.

| Case ID | Descriptive title | $(R,k,a)$ | Certificate components | Result |
|---|---|---:|---|---|
| [`r09_k2_a0`](r09_k2_a0/) | 19-vertex dual-matching exclusion | $(9,2,0)$ | `cert19` | excluded |
| [`r11_k3_a0`](r11_k3_a0/) | 23-vertex triangle-incidence exclusion | $(11,3,0)$ | `cert23` | excluded |
| [`r12_k3_a0`](r12_k3_a0/) | 25-vertex zero-augmentation Profiles X/Y exclusion | $(12,3,0)$ | `cert25B`, shared `cert25_core` | excluded |
| [`r12_k3_a1`](r12_k3_a1/) | 25-vertex one-edge-augmentation exclusion (simple-new and parallel-pole branches) | $(12,3,1)$ | `cert25B`, shared `cert25_core`, `cert25_parallel` | excluded |

The two 25-vertex cases share search engines and locked streams; their case
directories therefore contain specifications rather than copied catalogues.
The `cert*` names are historical and remain unchanged because they are used by
the paper-locked archive, scripts, and hashes. The legacy `type_B` counter in
`cert25B` corresponds to Profile Y.

## Run a case

From the repository root:

```sh
python3 run_verification.py zero-augmentation-25
```

A successful run ends with:

```text
PASS case r12_k3_a0: no residual counterexample
```

To verify the complete tamper-evident package, run:

```sh
python3 run_verification.py all
```

See the individual case pages for the mathematical target and decisive locked
counts, and the component READMEs for generation and full-regeneration details.
