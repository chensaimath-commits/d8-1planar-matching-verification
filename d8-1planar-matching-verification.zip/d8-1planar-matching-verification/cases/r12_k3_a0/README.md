# 25-vertex zero-augmentation Profiles X/Y exclusion

**Case ID:** `r12_k3_a0`  
**Parameters:** $(R,k,a)=(12,3,0)$  
**Certificate components:** [`cert25B/`](../../cert25B/) and
[`cert25_core/`](../../cert25_core/)

## Mathematical target

A hypothetical factor-critical block would have 25 vertices, 87 edges, and
degree sequence $7^{24},6$. With no added augmentation edge ($a=0$), theory
leaves exactly two full-kite skeleton profiles, called Profile X and Profile Y
in the paper.

## Profile Y: quartic inverse reconstruction

`cert25B/` checks Profile Y. Its directory and the counter `type_B` retain a
historical name because they are referenced by the paper-locked archive and
hash manifests. The current mathematical name of this target is Profile Y.

The certificate contains 51 dual maps. Testing 1,938 inverse reconstructions
gives

```text
type_B=0
```

## Profile X: common-core search

`cert25_core/` checks Profile X through the common residual also used by the
simple-new part of `r12_k3_a1`. The exhaustive run considers 152,706 connected
cubic plane-multigraph inputs, 276,001,884 matchings, and 1,742,712,513
special-face-role assignments, and obtains

```text
simple_D=139893
exact_patch_phases=0
```

A deliberately wider, nonempty audit independently checks 52,169 maps and
30,049,344 inverse phases, again finding zero exact residuals. Therefore
neither Profile X nor Profile Y exists.

## Run

From the repository root:

```sh
python3 run_verification.py zero-augmentation-25
```

The exact case ID `r12_k3_a0` is accepted as an equivalent selector.

The run ends with:

```text
PASS case r12_k3_a0: no residual counterexample
```

The recorded check completes quickly. See
[`cert25B/README.md`](../../cert25B/README.md) and
[`cert25_core/README.md`](../../cert25_core/README.md) for the inverse
reductions, full-regeneration commands, and locked hashes.
