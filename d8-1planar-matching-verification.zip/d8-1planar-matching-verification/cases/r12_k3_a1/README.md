# 25-vertex one-edge-augmentation exclusion

**Case ID:** `r12_k3_a1`  
**Parameters:** $(R,k,a)=(12,3,1)$  
**Branches:** simple-new and parallel-pole  
**Certificate components:** [`cert25B/`](../../cert25B/),
[`cert25_core/`](../../cert25_core/), and
[`cert25_parallel/`](../../cert25_parallel/)

## Mathematical target

The triangulated augmentation contains one added uncrossed edge. The proof
separates two possibilities: the added edge is new in the underlying simple
graph (the **simple-new** branch), or it is parallel to an old uncrossed edge
in the augmentation (the **parallel-pole** branch). Here $\tau(v)$ denotes
triangular-face incidence at $v$, counted with facial multiplicity.

## Simple-new branch

`cert25B/` excludes the two simple quartic profiles. It obtains

```text
tau_0^1_1^24=0
```

The second required triangle-incidence signature occurs in two maps, but

```text
quartic2_pole_markings=0
```

The remaining simple-new profile is the common residual checked once by
`cert25_core/`. Its wider independent audit gives

```text
exact_R=0
profile_R=0
```

## Parallel-pole branch

`cert25_parallel/` checks the parallel-pole possibility. Of 1,189 generator
leaves, 51 have the required degree/face data and two have the target
triangle-incidence signature, but none has the required double-pole edge:

```text
exact_tau_one_double=0
```

Thus every simple-new and parallel-pole branch is empty.

## Run

From the repository root:

```sh
python3 run_verification.py one-edge-augmentation-25
```

The exact case ID `r12_k3_a1` is accepted as an equivalent selector.

The run ends with:

```text
PASS case r12_k3_a1: no residual counterexample
```

See [`cert25B/README.md`](../../cert25B/README.md),
[`cert25_core/README.md`](../../cert25_core/README.md), and
[`cert25_parallel/README.md`](../../cert25_parallel/README.md) for the exact
inverse reductions, generation classes, full-regeneration commands, and
locked hashes.
