# Certified extremal blocks for the `d=8` construction

The three authoritative certificate files in this directory describe the
valid odd factor-critical blocks used in the sharp lower-bound construction.
Their parameters are

| file | `(r,k)` | vertices | edges | degree multiset |
|---|---:|---:|---:|---:|
| `block_r7_k1.txt` | `(7,1)` | 15 | 50 | `7^11,6^3,5` |
| `block_r10_k2.txt` | `(10,2)` | 21 | 72 | `7^18,6^3` |
| `block_r13_k3.txt` | `(13,3)` | 27 | 94 | `7^26,6` |

Here a block with parameters `(r,k)` has `2r+1` vertices and `7r+k`
edges.  Each displayed Hamilton cycle is odd and spanning.  It supplies a
matching of size `r`, and after deletion of any vertex its remaining
Hamilton path has a perfect matching.  Thus every block is factor-critical
and has matching number exactly `r`.

## Why the drawings are 1-planar

For the 15- and 21-vertex blocks, the certificate first gives a complete
clockwise rotation system and oriented face list for a plane triangulation.
Each new edge joins the two opposite vertices in the union of the two
triangles incident with its specified old edge, crossing that old edge once.
All of these two-face regions use pairwise disjoint triangular faces.

For the 27-vertex block, the rotation system and face list describe a plane
4-regular skeleton with eight triangular and twenty-one quadrilateral
faces.  Both diagonals are drawn crossing once inside every quadrilateral;
different face interiors are disjoint.  Deleting the two stated uncrossed
skeleton edges leaves 94 edges and degree multiset `7^26,6`.

The verifier checks reciprocal loop-free rotations, rotation-induced facial
walks and Euler counts, edge and diagonal uniqueness, disjoint crossing
regions, final edge counts and degrees, every edge of each Hamilton cycle,
and the alternating perfect matching after every possible vertex deletion.
Run it with ordinary Python, without `-O`, because the certificate assertions
must remain enabled.

Run from this directory:

```sh
python3 verify_blocks.py
```

Observed output:

```text
r=7 : skeleton_edges=39 added=11 degrees={7: 11, 6: 3, 5: 1} Hamilton/factor-critical=OK
r=10: skeleton_edges=57 added=15 degrees={7: 18, 6: 3} Hamilton/factor-critical=OK
r=13: skeleton_edges=54 diagonals=42 deleted=2 degrees={7: 26, 6: 1} Hamilton/factor-critical=OK
all three 1-planar construction certificates verified
```

## Assembly for every matching budget

Let `t=s-1` and write `t=13q+beta`, where `0<=beta<=12`.  Disjoint unions of
the certified blocks and copies of `K_{1,7}` attain

```text
B(t) = max{x+2y+3z : 7x+10y+13z <= t}
     = 3q                         if 0 <= beta <= 6,
       3q+1                       if 7 <= beta <= 9,
       3q+2                       if 10 <= beta <= 12.
```

For completeness, put `P=x+2y+3z` and `C=7x+10y+13z`.  Then

```text
C = (13P+8x+4y)/3.
```

For profits `P=3Q`, `3Q+1`, and `3Q+2`, the least possible costs are,
respectively, `13Q`, `13Q+7`, and `13Q+10`: modulo three, the least extra
terms `8x+4y` are `0`, `8`, and `4`, attained respectively by
`(x,y)=(0,0),(1,0),(0,1)`.  The resulting minimum-cost sequence is strictly
increasing, and profit `3q+3` already costs
`13(q+1)>13q+beta`.  This proves the displayed residue formula, not merely
its attainability.

Use `q` copies of the `(13,3)` block; according to the residue, add no
smaller block, one `(7,1)` block, or one `(10,2)` block.  Fill the remaining
matching budget with copies of `K_{1,7}`, each of which has seven edges and
matching number one.  The resulting simple 1-planar graph has maximum degree
seven, matching number exactly `t`, and `7t+B(t)` edges.

## SHA-256

```text
87f3d445484bbe008387c7e4726be0bcf4dcd104eec19d538c2d7d91e1c6f827  block_r7_k1.txt
e57f67641b3618f946caf7a980aa35997a0b7fc373f721fbeb12fad6de99ae9e  block_r10_k2.txt
a2176a71899b4b97537ae4d30933ae33cc47c4ca91136275b87acb4a7e838041  block_r13_k3.txt
b678015e8c01e3b257c1bb53814f180a28cddead6e13fb9d811ef51f696fc96d  verify_blocks.py
```
