#!/usr/bin/env python3
"""Independently verify the three construction certificates in this folder."""

from collections import Counter
from pathlib import Path
import re


if not __debug__:
    raise SystemExit(
        "FAIL: construction verification must run without Python -O"
    )


HERE = Path(__file__).resolve().parent


def edge(a, b):
    assert a != b
    return tuple(sorted((a, b)))


def canonical_cycle(face):
    face = tuple(face)
    candidates = []
    for direction in (face, tuple(reversed(face))):
        candidates.extend(direction[i:] + direction[:i]
                          for i in range(len(face)))
    return min(candidates)


def rotations_from(text, n):
    rotations = {}
    for match in re.finditer(r"(?m)^\s*(\d+):\s+([0-9 ]+)\s*$", text):
        v = int(match.group(1))
        neighbours = tuple(map(int, match.group(2).split()))
        rotations[v] = neighbours
    assert set(rotations) == set(range(1, n + 1))
    for v, neighbours in rotations.items():
        assert v not in neighbours
        assert len(neighbours) == len(set(neighbours))
        assert all(v in rotations[w] for w in neighbours)
    return rotations


def faces_from_rotations(rotations):
    """Return facial walks induced by the displayed clockwise rotations."""
    successor = {}
    for v, neighbours in rotations.items():
        for i, u in enumerate(neighbours):
            successor[u, v] = v, neighbours[(i - 1) % len(neighbours)]
    seen, faces = set(), []
    for u, neighbours in rotations.items():
        for v in neighbours:
            if (u, v) in seen:
                continue
            start = current = (u, v)
            face = []
            while current not in seen:
                seen.add(current)
                face.append(current[0])
                current = successor[current]
            assert current == start
            assert len(face) == len(set(face))
            faces.append(tuple(face))
    return faces


def skeleton_edges(rotations):
    return {edge(v, w) for v, neighbours in rotations.items()
            for w in neighbours}


def extract_parenthesized_faces(text, start_marker, end_marker):
    start = text.index(start_marker) + len(start_marker)
    end = text.index(end_marker, start)
    chunk = text[start:end]
    return [tuple(map(int, match)) for match in
            re.findall(r"\((\d+),(\d+),(\d+)\)", chunk)]


def extract_hamilton_cycle(text):
    tail = text[text.index("Hamilton cycle"):]
    certificate = tail.split("\n\n", 1)[1].split("\n\n", 1)[0]
    return list(map(int, re.findall(r"\d+", certificate)))


def check_hamilton(cycle, n, edges):
    assert len(cycle) == n + 1 and cycle[0] == cycle[-1]
    assert set(cycle[:-1]) == set(range(1, n + 1))
    assert all(edge(a, b) in edges for a, b in zip(cycle, cycle[1:]))
    # Explicitly check the alternating matching obtained after every deletion.
    ring = cycle[:-1]
    for deleted in range(1, n + 1):
        i = ring.index(deleted)
        path = ring[i + 1:] + ring[:i]
        matching = [edge(path[j], path[j + 1])
                    for j in range(0, n - 1, 2)]
        assert len(matching) == (n - 1) // 2
        assert all(e in edges for e in matching)
        assert len({v for e in matching for v in e}) == n - 1


def degrees(n, edges):
    answer = Counter()
    for a, b in edges:
        answer[a] += 1
        answer[b] += 1
    assert set(answer) == set(range(1, n + 1))
    return answer


def check_two_face_block(section, n, expected_m, expected_degrees,
                         face_start, face_end):
    rotations = rotations_from(section, n)
    displayed = extract_parenthesized_faces(
        section, face_start, face_end)
    induced = faces_from_rotations(rotations)
    assert Counter(map(canonical_cycle, displayed)) == Counter(
        map(canonical_cycle, induced))
    assert len(displayed) == 2 * n - 4
    assert all(len(face) == 3 for face in displayed)
    old_edges = skeleton_edges(rotations)
    assert len(old_edges) == 3 * n - 6
    assert n - len(old_edges) + len(displayed) == 2

    additions = []
    crossings = []
    for match in re.finditer(
            r"add\s+(\d+)-(\d+)\s+crossing\s+(\d+)-(\d+)", section):
        additions.append(edge(int(match.group(1)), int(match.group(2))))
        crossings.append(edge(int(match.group(3)), int(match.group(4))))
    assert len(additions) == expected_m - len(old_edges)
    assert len(additions) == len(set(additions))
    assert len(crossings) == len(set(crossings))
    assert not (set(additions) & old_edges)
    assert set(crossings) <= old_edges

    used_faces = []
    for added, crossed in zip(additions, crossings):
        incident = [i for i, face in enumerate(displayed)
                    if crossed[0] in face and crossed[1] in face]
        assert len(incident) == 2
        opposite = []
        for i in incident:
            opposite.extend(v for v in displayed[i] if v not in crossed)
        assert edge(*opposite) == added
        used_faces.extend(incident)
    assert len(used_faces) == len(set(used_faces))

    final_edges = old_edges | set(additions)
    assert len(final_edges) == expected_m
    degree_list = degrees(n, final_edges)
    assert Counter(degree_list.values()) == Counter(expected_degrees)
    assert max(degree_list.values()) == 7
    cycle = extract_hamilton_cycle(section)
    check_hamilton(cycle, n, final_edges)
    return len(old_edges), len(additions), Counter(degree_list.values())


def check_r7_r10():
    text7 = (HERE / "block_r7_k1.txt").read_text()
    text10 = (HERE / "block_r10_k2.txt").read_text()
    marker7 = "BLOCK (r,k)=(7,1)"
    marker10 = "BLOCK (r,k)=(10,2)"
    section7 = text7[text7.index(marker7):]
    section10 = text10[text10.index(marker10):]
    result7 = check_two_face_block(
        section7, 15, 50, {5: 1, 6: 3, 7: 11},
        "oriented triangular faces are:", "\n\nThe table")
    result10 = check_two_face_block(
        section10, 21, 72, {6: 3, 7: 18},
        "oriented triangular faces are:", "\n\nAs above")
    return result7, result10


def check_r13():
    text = (HERE / "block_r13_k3.txt").read_text()
    n = 27
    rotations = rotations_from(text, n)
    displayed = []
    kinds = []
    start = text.index("Equivalently, its 29 faces")
    end = text.index("\n\nDirect embedding check", start)
    for kind, vertices in re.findall(
            r"(?m)^\s*([TQ])\s+([0-9 ]+)\s*$", text[start:end]):
        face = tuple(map(int, vertices.split()))
        assert len(face) == (3 if kind == "T" else 4)
        kinds.append(kind)
        displayed.append(face)
    induced = faces_from_rotations(rotations)
    assert Counter(map(canonical_cycle, displayed)) == Counter(
        map(canonical_cycle, induced))
    assert Counter(kinds) == Counter({"T": 8, "Q": 21})
    old_edges = skeleton_edges(rotations)
    assert len(old_edges) == 54
    assert n - len(old_edges) + len(displayed) == 2

    diagonals = []
    for kind, face in zip(kinds, displayed):
        if kind == "Q":
            a, b, c, d = face
            diagonals.extend((edge(a, c), edge(b, d)))
    assert len(diagonals) == 42
    assert len(diagonals) == len(set(diagonals))
    assert not (set(diagonals) & old_edges)
    completed = old_edges | set(diagonals)
    assert len(completed) == 96

    start = text.index("Delete the skeleton edges")
    end = text.index("\n\nDeletion preserves", start)
    deleted = {edge(int(a), int(b)) for a, b in
               re.findall(r"(\d+)-(\d+)", text[start:end])}
    assert deleted == {edge(1, 4), edge(16, 25)}
    assert deleted <= old_edges
    final_edges = completed - deleted
    assert len(final_edges) == 94
    degree_list = degrees(n, final_edges)
    assert Counter(degree_list.values()) == Counter({6: 1, 7: 26})
    cycle = extract_hamilton_cycle(text)
    check_hamilton(cycle, n, final_edges)
    return len(old_edges), len(diagonals), len(deleted), Counter(
        degree_list.values())


def main():
    result7, result10 = check_r7_r10()
    result13 = check_r13()
    print("r=7 : skeleton_edges=%d added=%d degrees=%s Hamilton/factor-critical=OK"
          % (result7[0], result7[1], dict(result7[2])))
    print("r=10: skeleton_edges=%d added=%d degrees=%s Hamilton/factor-critical=OK"
          % (result10[0], result10[1], dict(result10[2])))
    print("r=13: skeleton_edges=%d diagonals=%d deleted=%d degrees=%s "
          "Hamilton/factor-critical=OK"
          % (result13[0], result13[1], result13[2], dict(result13[3])))
    print("all three 1-planar construction certificates verified")


if __name__ == "__main__":
    main()
