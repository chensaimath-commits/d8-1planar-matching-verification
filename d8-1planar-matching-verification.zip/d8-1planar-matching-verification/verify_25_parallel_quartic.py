#!/usr/bin/env python3
"""Verify the dual-quadrangulation certificate for parallel augmentation.

Input must be plantri edge_code (-E), which identifies parallel edges
unambiguously.  For every emitted 27-vertex quadrangulation Q this verifier
constructs its plane dual S+, checks degree/face and tau data and the unique
double pole edge, collapses that double edge, completes the 19 kites, and
tests the resulting 25-vertex graph for degrees 7^24,6 and
factor-criticality.
"""

from collections import Counter
from hashlib import sha256
from pathlib import Path
import sys

from verify_25_typeX import (
    VerificationError, degrees, edge, factor_critical, fail,
)


EDGE_HEADER = b">>edge_code<<"


def read_edge_code(path):
    pth = Path(path)
    if not path:
        fail("empty input path")
    if not pth.is_file():
        fail(f"not a regular file: {path}")
    data = pth.read_bytes()
    if not data:
        fail(f"empty file (missing edge_code header): {path}")
    if not data.startswith(EDGE_HEADER):
        fail(f"missing edge_code header (run plantri with -E): {path}")
    pos = len(EDGE_HEADER)
    record = 0
    while pos < len(data):
        first = data[pos]
        pos += 1
        if first:
            size, width = first, 1
        else:
            if pos >= len(data):
                fail(f"{path}: record {record}: truncated long header")
            descriptor = data[pos]
            pos += 1
            k, width = descriptor >> 4, descriptor & 15
            if not (1 <= k <= 15 and 1 <= width <= 15):
                fail(f"{path}: record {record}: invalid long header")
            if pos + k > len(data):
                fail(f"{path}: record {record}: truncated body size")
            size = int.from_bytes(data[pos:pos + k], "big")
            pos += k
        if pos + size > len(data):
            fail(f"{path}: record {record}: truncated body")
        body = data[pos:pos + size]
        pos += size
        if width != 1:
            fail(f"{path}: record {record}: unsupported edge width {width}")
        sections = body.split(b"\xff")
        if any(not section for section in sections):
            fail(f"{path}: record {record}: empty vertex section")
        yield record, [list(section) for section in sections]
        record += 1


def validate_edge_rotation(rows, label):
    if len(rows) != 27:
        fail(f"{label}: has {len(rows)} vertices, expected 27")
    occurrences = {}
    for v, row in enumerate(rows):
        if len(row) not in (3, 4):
            fail(f"{label}: vertex {v} has degree {len(row)}, expected 3 or 4")
        for pos, eid in enumerate(row):
            occurrences.setdefault(eid, []).append((v, pos))
    if set(occurrences) != set(range(50)):
        fail(f"{label}: edge identifiers are not exactly 0,...,49")
    inverse = {}
    endpoints = []
    for eid in range(50):
        occ = occurrences[eid]
        if len(occ) != 2:
            fail(f"{label}: edge {eid} occurs {len(occ)} times")
        a, b = occ
        if a[0] == b[0]:
            fail(f"{label}: loop at vertex {a[0]}")
        inverse[a] = b
        inverse[b] = a
        endpoints.append((a[0], b[0]))

    reached = {0}
    stack = [0]
    adjacency = [[] for _ in rows]
    for u, v in endpoints:
        adjacency[u].append(v)
        adjacency[v].append(u)
    while stack:
        v = stack.pop()
        for u in adjacency[v]:
            if u not in reached:
                reached.add(u)
                stack.append(u)
    if len(reached) != 27:
        fail(f"{label}: Q is disconnected")
    return inverse, endpoints


def quadrangular_faces(rows, inverse, label):
    darts = {(v, pos) for v, row in enumerate(rows)
             for pos in range(len(row))}
    seen = set()
    faces = []
    face_of = {}
    for start in sorted(darts):
        if start in seen:
            continue
        cur = start
        local = set()
        vertices = []
        while cur not in local:
            if cur in seen:
                fail(f"{label}: facial walk merges into an earlier face")
            local.add(cur)
            vertices.append(cur[0])
            iv, ipos = inverse[cur]
            cur = (iv, (ipos + 1) % len(rows[iv]))
        if cur != start:
            fail(f"{label}: facial walk closes prematurely")
        if len(vertices) != 4 or len(set(vertices)) != 4:
            fail(f"{label}: face is not a simple quadrilateral: {vertices}")
        f = len(faces)
        for dart in local:
            face_of[dart] = f
        seen.update(local)
        faces.append(vertices)
    if seen != darts or len(faces) != 25:
        fail(f"{label}: expected 25 quadrangular faces")
    if 27 - 50 + len(faces) != 2 or sum(map(len, faces)) != 100:
        fail(f"{label}: Euler/face-length identity failed")
    return faces, face_of


def reconstruct(rows, endpoints, faces, face_of, label):
    tau = [0] * 25
    for f, boundary in enumerate(faces):
        tau[f] = sum(len(rows[v]) == 3 for v in boundary)
    if Counter(tau) != Counter({0: 2, 1: 22, 2: 1}):
        return tau, None, None, False

    multiplicity = Counter()
    for eid, (u, v) in enumerate(endpoints):
        ou = rows[u].index(eid)
        ov = rows[v].index(eid)
        f, g = face_of[(u, ou)], face_of[(v, ov)]
        if f == g:
            return tau, None, None, True
        multiplicity[edge(f, g)] += 1
    double_edges = [e for e, m in multiplicity.items() if m == 2]
    if any(m not in (1, 2) for m in multiplicity.values()) \
            or len(double_edges) != 1 or len(multiplicity) != 49:
        return tau, None, None, True
    poles = double_edges[0]
    if tau[poles[0]] != 0 or tau[poles[1]] != 0:
        return tau, None, None, True

    completed = set(multiplicity)
    for v, row in enumerate(rows):
        if len(row) != 4:
            continue
        around = [face_of[(v, pos)] for pos in range(4)]
        if len(set(around)) != 4:
            return tau, poles, None, True
        for i in (0, 1):
            diagonal = edge(around[i], around[i + 2])
            if diagonal in completed:
                return tau, poles, None, True
            completed.add(diagonal)
    return tau, poles, completed, True


def main(argv):
    if not argv:
        fail("no edge_code input paths supplied")
    counts = Counter()
    hashes = []
    for path in argv:
        pth = Path(path)
        raw = pth.read_bytes() if pth.is_file() else b""
        hashes.append((path, sha256(raw).hexdigest()))
        for record, rows in read_edge_code(path):
            counts["maps"] += 1
            label = f"{path}: record {record}"
            inverse, endpoints = validate_edge_rotation(rows, label)
            if Counter(map(len, rows)) != Counter({3: 8, 4: 19}):
                fail(f"{label}: Q degree signature is not 3^8 4^19")
            counts["degree_signature"] += 1
            faces, face_of = quadrangular_faces(rows, inverse, label)
            counts["quadrangular_embedding"] += 1
            _tau, _poles, completed, tau_ok = reconstruct(
                rows, endpoints, faces, face_of, label)
            if tau_ok:
                counts["tau_signature"] += 1
            if _poles is None:
                continue
            counts["exact_tau_one_double"] += 1
            if completed is None:
                continue
            counts["kite_simple"] += 1
            if len(completed) != 87:
                fail(f"{label}: collapsed kite completion has {len(completed)} edges")
            if degrees(25, completed) != [6] + [7] * 24:
                fail(f"{label}: collapsed completion has wrong degrees")
            counts["degree_7^24_6"] += 1
            if factor_critical(25, completed):
                counts["factor_critical"] += 1
                print(f"FOUND factor-critical reconstruction: {label}")
        counts["files"] += 1

    if counts["maps"] == 0:
        fail("all supplied edge_code files are header-only")
    for key in ("files", "maps", "degree_signature",
                "quadrangular_embedding", "tau_signature",
                "exact_tau_one_double",
                "kite_simple", "degree_7^24_6", "factor_critical"):
        print(f"{key}={counts[key]}")
    for path, digest in hashes:
        print(f"sha256 {digest}  {path}")
    if counts["factor_critical"]:
        print("certificate_result=FAIL: factor-critical reconstruction found")
        return 1
    print("certificate_result=PASS: no factor-critical reconstruction")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except VerificationError as exc:
        print(f"certificate_result=ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
