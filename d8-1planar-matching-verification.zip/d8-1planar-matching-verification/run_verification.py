#!/usr/bin/env python3
"""Friendly command-line entry point for the four recorded verifications.

The certificate computations themselves remain in ``verify_case.sh`` and its
case-specific verifiers.  This module validates the public case metadata,
resolves descriptive case names, and invokes that trusted shell entry point
without constructing a shell command string.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parent
CASES_DIRECTORY = ROOT / "cases"
VERIFY_SCRIPT = ROOT / "verify_case.sh"


@dataclass(frozen=True)
class KnownCase:
    """Repository-level identity and mathematical parameters of one case."""

    case_id: str
    slug: str
    fallback_title: str
    parameters: tuple[int, int, int]
    components: tuple[str, ...]


KNOWN_CASES: tuple[KnownCase, ...] = (
    KnownCase(
        "r09_k2_a0",
        "dual-matching-19",
        "Dual matching obstruction on 19 vertices",
        (9, 2, 0),
        ("cert19",),
    ),
    KnownCase(
        "r11_k3_a0",
        "triangle-incidence-23",
        "Triangle-incidence obstruction on 23 vertices",
        (11, 3, 0),
        ("cert23",),
    ),
    KnownCase(
        "r12_k3_a0",
        "zero-augmentation-25",
        "Zero-augmentation obstruction on 25 vertices",
        (12, 3, 0),
        ("cert25B", "cert25_core"),
    ),
    KnownCase(
        "r12_k3_a1",
        "one-edge-augmentation-25",
        "One-edge augmentation obstruction on 25 vertices",
        (12, 3, 1),
        ("cert25B", "cert25_core", "cert25_parallel"),
    ),
)

KNOWN_BY_ID = {case.case_id: case for case in KNOWN_CASES}
SAFE_COMPONENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]*\Z")


class MetadataError(ValueError):
    """Raised when a case metadata file is malformed or inconsistent."""


@dataclass(frozen=True)
class CaseMetadata:
    """Validated metadata used for display and selector resolution."""

    case_id: str
    slug: str
    title: str
    parameters: tuple[int, int, int]
    components: tuple[str, ...]
    path: Path


def _is_integer(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _require_object(value: object, field: str, path: Path) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise MetadataError(f"{path}: {field} must be a JSON object")
    return value


def _read_case(path: Path) -> CaseMetadata:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except OSError as error:
        raise MetadataError(f"cannot read {path}: {error}") from error
    except json.JSONDecodeError as error:
        raise MetadataError(
            f"{path}:{error.lineno}:{error.colno}: invalid JSON: {error.msg}"
        ) from error

    data = _require_object(raw, "top-level value", path)
    schema_version = data.get("schema_version")
    if not _is_integer(schema_version) or schema_version not in (1, 2):
        raise MetadataError(f"{path}: schema_version must be 1 or 2")

    case_id = data.get("case_id")
    if not isinstance(case_id, str) or not case_id:
        raise MetadataError(f"{path}: case_id must be a non-empty string")
    if case_id != path.parent.name:
        raise MetadataError(
            f"{path}: case_id {case_id!r} does not match directory {path.parent.name!r}"
        )
    known = KNOWN_BY_ID.get(case_id)
    if known is None:
        raise MetadataError(f"{path}: unknown case_id {case_id!r}")

    slug_value = data.get("slug")
    if slug_value is None and schema_version == 1:
        slug = known.slug
    elif isinstance(slug_value, str) and slug_value:
        slug = slug_value
    else:
        raise MetadataError(f"{path}: slug must be a non-empty string")
    if slug != known.slug:
        raise MetadataError(
            f"{path}: slug must be {known.slug!r} for case {case_id!r}"
        )

    title_value = data.get("title")
    if title_value is None and schema_version == 1:
        title = known.fallback_title
    elif isinstance(title_value, str) and title_value.strip():
        title = title_value.strip()
    else:
        raise MetadataError(f"{path}: title must be a non-empty string")

    parameters_object = _require_object(data.get("parameters"), "parameters", path)
    required_parameter_keys = {"R", "k", "a"}
    if set(parameters_object) != required_parameter_keys:
        raise MetadataError(
            f"{path}: parameters must contain exactly R, k, and a"
        )
    parameter_values = tuple(parameters_object[key] for key in ("R", "k", "a"))
    if not all(_is_integer(value) for value in parameter_values):
        raise MetadataError(f"{path}: R, k, and a must be integers")
    parameters = (parameter_values[0], parameter_values[1], parameter_values[2])
    if parameters != known.parameters:
        raise MetadataError(
            f"{path}: expected parameters {known.parameters}, found {parameters}"
        )

    raw_components = data.get("certificate_components")
    if not isinstance(raw_components, list) or not raw_components:
        raise MetadataError(
            f"{path}: certificate_components must be a non-empty array"
        )
    if not all(
        isinstance(item, str) and SAFE_COMPONENT.fullmatch(item)
        for item in raw_components
    ):
        raise MetadataError(
            f"{path}: every certificate component must be a safe directory name"
        )
    components = tuple(raw_components)
    if len(set(components)) != len(components):
        raise MetadataError(f"{path}: certificate_components contains duplicates")
    if components != known.components:
        raise MetadataError(
            f"{path}: expected components {known.components}, found {components}"
        )
    for component in components:
        if not (ROOT / component).is_dir():
            raise MetadataError(
                f"{path}: certificate component directory {component!r} is missing"
            )

    expected = _require_object(data.get("expected"), "expected", path)
    if not expected:
        raise MetadataError(f"{path}: expected must not be empty")
    for key, value in expected.items():
        if not isinstance(key, str) or not key:
            raise MetadataError(f"{path}: expected contains an invalid key")
        if not _is_integer(value) or value < 0:
            raise MetadataError(
                f"{path}: expected value {key!r} must be a non-negative integer"
            )

    if data.get("outcome") != "excluded":
        raise MetadataError(f"{path}: outcome must be 'excluded'")

    return CaseMetadata(case_id, slug, title, parameters, components, path)


def load_cases() -> tuple[CaseMetadata, ...]:
    """Load all four metadata files and ensure selectors are unambiguous."""

    paths = sorted(CASES_DIRECTORY.glob("*/case.json"))
    cases = tuple(_read_case(path) for path in paths)
    found_ids = {case.case_id for case in cases}
    expected_ids = set(KNOWN_BY_ID)
    if found_ids != expected_ids or len(cases) != len(KNOWN_CASES):
        missing = sorted(expected_ids - found_ids)
        unexpected = sorted(found_ids - expected_ids)
        details = []
        if missing:
            details.append("missing " + ", ".join(missing))
        if unexpected:
            details.append("unexpected " + ", ".join(unexpected))
        if len(cases) != len(found_ids):
            details.append("duplicate case_id")
        raise MetadataError("case set is invalid: " + "; ".join(details))

    slugs = [case.slug for case in cases]
    if len(slugs) != len(set(slugs)):
        raise MetadataError("case metadata contains duplicate slugs")

    order = {known.case_id: index for index, known in enumerate(KNOWN_CASES)}
    return tuple(sorted(cases, key=lambda case: order[case.case_id]))


def format_parameters(parameters: tuple[int, int, int]) -> str:
    return f"(R, k, a) = ({parameters[0]}, {parameters[1]}, {parameters[2]})"


def list_cases(cases: Sequence[CaseMetadata]) -> None:
    """Print stable, copy-and-pasteable selectors for all recorded cases."""

    print("Available verification cases:\n")
    id_width = max(len(case.case_id) for case in cases)
    slug_width = max(len(case.slug) for case in cases)
    for case in cases:
        print(f"  {case.case_id:<{id_width}}  {case.slug:<{slug_width}}")
        print(f"  {'':<{id_width}}  {format_parameters(case.parameters)} — {case.title}")
    print("\nUse 'all' to run the complete recorded certificate package.")


def resolve_selector(selector: str, cases: Sequence[CaseMetadata]) -> CaseMetadata | None:
    """Return a case for an exact ID or slug; ``None`` denotes all cases."""

    if selector == "all":
        return None
    for case in cases:
        if selector in (case.case_id, case.slug):
            return case
    valid = ["all"]
    valid.extend(case.case_id for case in cases)
    valid.extend(case.slug for case in cases)
    raise MetadataError(
        f"unknown selector {selector!r}; choose one of: {', '.join(valid)}"
    )


def run_verification(selection: CaseMetadata | None, case_count: int) -> int:
    """Invoke the shell verifier once and return its process status."""

    if not VERIFY_SCRIPT.is_file():
        print(f"error: verifier not found: {VERIFY_SCRIPT}", file=sys.stderr)
        return 127

    if selection is None:
        selector = "all"
        heading = f"Complete verification package ({case_count} cases)"
        detail_lines = ("Selector: all",)
    else:
        selector = selection.case_id
        heading = selection.title
        detail_lines = (
            f"Case ID: {selection.case_id}",
            f"Selector: {selection.slug}",
            format_parameters(selection.parameters),
            "Certificate components: " + ", ".join(selection.components),
        )

    rule = "=" * len(heading)
    print(f"\n{heading}\n{rule}", flush=True)
    for line in detail_lines:
        print(line, flush=True)
    print("", flush=True)

    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    started = time.monotonic()
    try:
        completed = subprocess.run(
            [str(VERIFY_SCRIPT), selector],
            cwd=ROOT,
            env=environment,
            check=False,
        )
        return_code = completed.returncode
    except OSError as error:
        print(f"error: could not start {VERIFY_SCRIPT.name}: {error}", file=sys.stderr)
        return_code = 127
    except KeyboardInterrupt:
        print("\nVerification interrupted.", file=sys.stderr)
        return_code = 130

    elapsed = time.monotonic() - started
    result = "PASS" if return_code == 0 else f"FAIL (exit {return_code})"
    print(f"\n{result}: elapsed time {elapsed:.2f} s", flush=True)
    if return_code < 0:
        return 128 - return_code
    return return_code


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Validate and run one of the four recorded computer-assisted "
            "checks for the d=8 proof."
        ),
        epilog=(
            "SELECTOR may be 'all', an exact case ID, or a descriptive slug. "
            "Run with --list to display them."
        ),
    )
    parser.add_argument(
        "selector",
        nargs="?",
        metavar="SELECTOR",
        help="case ID, descriptive slug, or 'all'",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        dest="list_only",
        help="list available cases and exit",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    arguments = parser.parse_args(argv)
    if arguments.list_only and arguments.selector is not None:
        parser.error("--list cannot be combined with SELECTOR")
    if not arguments.list_only and arguments.selector is None:
        parser.error("SELECTOR is required unless --list is used")

    try:
        cases = load_cases()
        if arguments.list_only:
            list_cases(cases)
            return 0
        selection = resolve_selector(arguments.selector, cases)
    except MetadataError as error:
        parser.error(str(error))

    return run_verification(selection, len(cases))


if __name__ == "__main__":
    raise SystemExit(main())
