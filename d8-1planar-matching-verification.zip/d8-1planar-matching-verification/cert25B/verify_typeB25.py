#!/usr/bin/env python3
"""Independent verifier for the 25-vertex type-B finite certificate."""

from collections import Counter, deque
from hashlib import sha256
from pathlib import Path
import sys


EXPECTED_SHA256 = "97385cc130d6db5ceb344d10832edfa2700b905c6b7bd8734367d191c960dabb"


def read_planar(path):
    data = Path(path).read_bytes()
    header = b">>planar_code<<"
    if not data.startswith(header):
        raise ValueError("bad planar_code header")
    pos = len(header)
    while pos < len(data):
        if pos >= len(data):
            raise ValueError("truncated planar_code order")
        n = data[pos]
        pos += 1
        if n == 0:
            raise ValueError("wide planar_code is not expected here")
        rot = []
        for _ in range(n):
            nbrs = []
            while True:
                if pos >= len(data):
                    raise ValueError("truncated planar_code adjacency row")
                x = data[pos]
                pos += 1
                if x == 0:
                    break
                nbrs.append(x - 1)
            rot.append(nbrs)
        yield rot
    if pos != len(data):
        raise ValueError("trailing planar_code bytes")


def faces_of(rot):
    successor = {}
    for v, nbrs in enumerate(rot):
        for i, u in enumerate(nbrs):
            successor[(u, v)] = (v, nbrs[(i - 1) % len(nbrs)])
    unseen = set(successor)
    faces = []
    while unseen:
        start = next(iter(unseen))
        dart = start
        face = []
        while True:
            if dart not in unseen:
                raise ValueError("non-cellular rotation")
            unseen.remove(dart)
            face.append(dart[0])
            if dart not in successor:
                raise ValueError("missing facial successor")
            dart = successor[dart]
            if dart == start:
                break
        faces.append(face)
    return faces


def edge(a, b):
    return (a, b) if a < b else (b, a)


def connected_after(rot, removed):
    alive = [v for v in range(len(rot)) if v not in removed]
    if not alive:
        return True
    seen = {alive[0]}
    queue = deque([alive[0]])
    while queue:
        v = queue.popleft()
        for w in rot[v]:
            if w not in removed and w not in seen:
                seen.add(w)
                queue.append(w)
    return len(seen) == len(alive)


def is_three_connected(rot):
    n = len(rot)
    if not connected_after(rot, set()):
        return False
    for a in range(n):
        if not connected_after(rot, {a}):
            return False
        for b in range(a + 1, n):
            if not connected_after(rot, {a, b}):
                return False
    return True


def maxmatch(n, edge_set, removed):
    nbr = [0] * n
    for u, v in edge_set:
        if u == removed or v == removed:
            continue
        nbr[u] |= 1 << v
        nbr[v] |= 1 << u
    full = ((1 << n) - 1) ^ (1 << removed)
    memo = {0: 0}

    def solve(mask):
        if mask in memo:
            return memo[mask]
        bit = mask & -mask
        u = bit.bit_length() - 1
        best = solve(mask ^ bit)
        choices = nbr[u] & mask
        while choices:
            mate = choices & -choices
            best = max(best, 1 + solve(mask ^ bit ^ mate))
            choices ^= mate
        memo[mask] = best
        return best

    return solve(full)


def factor_critical(n, edge_set):
    return all(maxmatch(n, edge_set, v) == (n - 1) // 2
               for v in range(n))


def complete_quadrilaterals(base, faces):
    completed = set(base)
    for face in faces:
        if len(face) != 4:
            continue
        for new_edge in (edge(face[0], face[2]),
                         edge(face[1], face[3])):
            if new_edge in completed:
                return None
            completed.add(new_edge)
    return completed


def main(path="octa25c2.plc"):
    raw = Path(path).read_bytes()
    if sha256(raw).hexdigest() != EXPECTED_SHA256:
        raise ValueError("unexpected certificate SHA-256")
    graphs = bad_embedding = connectivity_lt3 = 0
    tau_0_1x24 = 0
    quartic2_signature = quartic2_pole_markings = 0
    quartic2_simple = quartic2_degree = quartic2_factor_critical = 0
    reconstructions = simple = target = 0
    for rot in read_planar(path):
        graphs += 1
        n = len(rot)
        darts = {(v, w) for v, nbrs in enumerate(rot) for w in nbrs}
        edges = {edge(v, w) for v, w in darts}
        faces = faces_of(rot)
        if not (
            n == 25
            and all(len(nbrs) == 4
                    and len(set(nbrs)) == 4
                    and v not in nbrs
                    and all(0 <= w < n for w in nbrs)
                    for v, nbrs in enumerate(rot))
            and all((w, v) in darts for v, w in darts)
            and len(edges) == 50
            and Counter(map(len, faces)) == Counter({3: 8, 4: 19})
            and sum(map(len, faces)) == 2 * len(edges)
            and all(len(face) == len(set(face)) for face in faces)
        ):
            bad_embedding += 1
            continue
        if not is_three_connected(rot):
            connectivity_lt3 += 1

        # This same complete quartic list also covers the simple-new
        # a=1 branch in which the low-degree vertex is a pole.  That branch
        # would require triangle-incidence multiset 0^1,1^24.
        tau0 = [0] * n
        for face in faces:
            if len(face) == 3:
                for v in face:
                    tau0[v] += 1
        if Counter(tau0) == Counter({0: 1, 1: 24}):
            tau_0_1x24 += 1

        # The second simple-new a=1 quartic profile has two tau-zero
        # poles, 22 vertices of tau one, and one vertex of tau two.  Its
        # augmenting pole edge must be present in the skeleton and have a
        # quadrilateral on each side.  Complete all 19 kites, then remove
        # that distinguished edge to recover the alleged 87-edge graph H.
        if Counter(tau0) == Counter({0: 2, 1: 22, 2: 1}):
            quartic2_signature += 1
            poles = [v for v in range(n) if tau0[v] == 0]
            pole_edge = edge(poles[0], poles[1])
            incident = [
                face for face in faces
                if any(edge(face[i], face[(i + 1) % len(face)]) == pole_edge
                       for i in range(len(face)))
            ]
            if (pole_edge in edges and len(incident) == 2
                    and all(len(face) == 4 for face in incident)):
                quartic2_pole_markings += 1
                augmented = complete_quadrilaterals(edges, faces)
                if augmented is not None and len(augmented) == 88:
                    recovered = augmented - {pole_edge}
                    if len(recovered) == 87:
                        quartic2_simple += 1
                        degree_h = [0] * n
                        for u, v in recovered:
                            degree_h[u] += 1
                            degree_h[v] += 1
                        if Counter(degree_h) == Counter({7: 24, 6: 1}):
                            quartic2_degree += 1
                            if factor_critical(n, recovered):
                                quartic2_factor_critical += 1

        for qi, quad in enumerate(faces):
            if len(quad) != 4:
                continue
            for shift in (0, 1):
                reconstructions += 1
                a, b = quad[shift], quad[shift + 2]
                diagonal = edge(a, b)
                if diagonal in edges:
                    continue
                x = quad[(shift + 1) % 4]
                y = quad[(shift + 3) % 4]
                new_faces = [f for j, f in enumerate(faces) if j != qi]
                new_faces += [[a, x, b], [a, b, y]]
                skeleton = edges | {diagonal}
                completed = set(skeleton)
                good = True
                for face in new_faces:
                    if len(face) != 4:
                        continue
                    for new_edge in (
                        edge(face[0], face[2]),
                        edge(face[1], face[3]),
                    ):
                        if new_edge in completed:
                            good = False
                            break
                        completed.add(new_edge)
                    if not good:
                        break
                if not good or len(completed) != 87:
                    continue
                simple += 1

                tau = [0] * 25
                degree_s = [0] * 25
                degree_h = [0] * 25
                for face in new_faces:
                    if len(face) == 3:
                        for v in face:
                            tau[v] += 1
                for u, v in skeleton:
                    degree_s[u] += 1
                    degree_s[v] += 1
                for u, v in completed:
                    degree_h[u] += 1
                    degree_h[v] += 1
                signature = Counter(zip(degree_s, tau))
                desired = Counter({(5, 3): 2, (4, 2): 1, (4, 1): 22})
                if (signature == desired
                        and Counter(degree_h) == Counter({7: 24, 6: 1})):
                    target += 1

    print(
        f"graphs={graphs} bad_embedding={bad_embedding} "
        f"connectivity_lt3={connectivity_lt3} "
        f"tau_0^1_1^24={tau_0_1x24} "
        f"quartic2_signature={quartic2_signature} "
        f"quartic2_pole_markings={quartic2_pole_markings} "
        f"quartic2_simple={quartic2_simple} "
        f"quartic2_degree={quartic2_degree} "
        f"quartic2_factor_critical={quartic2_factor_critical} "
        f"reconstructions={reconstructions} "
        f"simple_completions={simple} type_B={target}"
    )
    if (graphs != 51 or bad_embedding or connectivity_lt3 or tau_0_1x24
            or quartic2_signature != 2 or quartic2_pole_markings
            or quartic2_simple or quartic2_degree
            or quartic2_factor_critical
            or reconstructions != 1938 or simple != 1938 or target):
        raise SystemExit(1)


if __name__ == "__main__":
    main(*(sys.argv[1:]))
