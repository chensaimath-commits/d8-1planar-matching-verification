/* Extend the distributed quad_restrict plug-in to plantri's -q -c2
 * minimum-degree-three generator.  The P1/P2/P3 expansions change vertex
 * degrees in the same way as in the default -q generator, so the plug-in's
 * degree-error lower bound is still a necessary (and hence sound) pruning
 * test. */
#define ALLTOGETHER
#include "quad_restrict.c"

#define PRE_FILTER_QUAD_MIN3 pre_filter_quad()
#define FAST_FILTER_QUAD_MIN3 pre_filter_quad()

#undef SWITCHES
#define SWITCHES "[-F#[_#^#] -c2 -uagsh -odG -v -q]"
#undef PLUGIN_INIT
#define PLUGIN_INIT /* plantri validates the standard switches */
