# 23-vertex exclusion certificate

This directory gives a reproducible finite certificate for the only
remaining skeleton case of a hypothetical 23-vertex simple 1-planar graph
`G` with 80 edges and maximum degree at most seven.  Such a graph would have
degree sequence `7^22,6`.

## Reduction to the enumerated quartic maps

Start with a fixed good 1-plane drawing of `G`, and augment it to a
triangulated drawing by adding `a` edges (parallel augmentation edges are
allowed in this standard reduction).  Let `x` be the number of crossings and
`t` the number of uncrossed triangular regions in the augmented drawing.
The triangulated-drawing identities give

```text
x = (80+a) - (3*23-6) = 17+a,
t = 2*23-4-2x          = 8-2a.
```

At most `2a` of the 22 original degree-seven vertices are endpoints of
added edges.  Thus the augmented drawing still has at least `22-2a`
degree-seven vertices.  Biedl's triangle-incidence lemma says that their
number is at most `3t`, so

```text
22-2a <= 3(8-2a),
```

which forces `a=0`.  (The identities, augmentation, and incidence lemma are
from T. Biedl, *A note on 1-planar graphs with minimum degree 7*, Discrete
Applied Mathematics 289 (2021), 230--232,
doi:10.1016/j.dam.2020.10.004.)

The full-kite skeleton lemma now gives a simple 3-connected plane skeleton
`S`: each crossing pair is removed and its four uncrossed boundary edges
bound a quadrilateral.  Here `S` has 23 vertices, 46 edges, eight triangular
faces and seventeen quadrilateral faces.  Completing every quadrilateral by
its two crossing diagonals recovers `G`.

For a vertex `v`, write `d(v)` for its degree in `S` and `tau(v)` for the
number of incident triangular faces.  Completion gives

```text
degree_G(v) = 2*d(v) - tau(v).
```

For a degree-seven vertex write

```text
(d(v),tau(v)) = (4+j,1+2j),
```

and for the unique degree-six vertex write

```text
(d(v),tau(v)) = (3+j,2j).
```

All `j` are nonnegative because `S` is 3-connected.  Since
`sum_v(d(v)-4)=2*46-4*23=0`, the sum of these `j` values is one.  Consequently
there are only two signatures:

```text
I.  (4,2), (4,1)^22;
II. (5,3), (3,0), (4,1)^21.
```

Signature II is impossible without enumeration.  Around its `(5,3)` vertex,
three triangular and two quadrilateral face positions occur in a cyclic list
of length five, so two triangular positions are consecutive.  Their common
edge has another endpoint incident with both triangles, hence with
`tau >= 2`; every other vertex in signature II has `tau <= 1`, a
contradiction.  Thus `S` must be a 4-regular 3-connected plane graph with
eight triangles, seventeen quadrilaterals, and triangle-incidence multiset
`1^22,2`.  This is exactly the case checked below.

## Provenance and exhaustive generation

`plantri.c` and `quad_restrict.c` are unchanged files from the official
author repository

```text
https://github.com/lichengzhang1/4-regular-plane-graphs-with-given-faces
commit 23d75d009948a868c7bf6fdb1486051b192d0d52
```

used for Y. Huang, L. Zhang and F. Dong, *A new note on 1-planar graphs with
minimum degree 7*, Discrete Applied Mathematics 348 (2024), 165--183,
doi:10.1016/j.dam.2024.01.026.

The dual of a desired `S` is a 3-connected quadrangulation on 25 vertices
with eight vertices of degree three and seventeen of degree four.  Plantri's
`-q` class generates all such embedded quadrangulations; `-d` writes their
duals.  Rebuild the complete input from this directory with

```sh
cc -O3 -o quad_restrict \
  '-DPLUGIN="quad_restrict.c"' -DALLTOGETHER plantri.c
./quad_restrict -q -F3_8^8F4_17^17 -d 25 \
  quartic23.rebuilt.plc
```

Observed generator output:

```text
33 quartic graphs written to quartic23.rebuilt.plc
```

The rebuilt file is byte-for-byte equal to
`quartic23_F3x8_F4x17.plc`.

## Independent verification

Run

```sh
python3 verify_23_quartic.py quartic23_F3x8_F4x17.plc
```

Observed output:

```text
maps: 33
1 {0: 1, 1: 20, 2: 2}
6 {0: 3, 1: 16, 2: 4}
8 {0: 4, 1: 14, 2: 5}
5 {0: 5, 1: 12, 2: 6}
3 {0: 6, 1: 10, 2: 7}
2 {0: 6, 1: 11, 2: 5, 3: 1}
1 {0: 7, 1: 8, 2: 8}
5 {0: 7, 1: 9, 2: 6, 3: 1}
1 {0: 7, 1: 10, 2: 4, 3: 2}
1 {0: 9, 1: 6, 2: 6, 3: 2}
connectivity_lt3: 0
target_tau_1x22_2: 0
sha256: c2ebdf3c143ea2c2f912a4becf93f0cbea8cbdaf17063a0b0c1d4b47c07556f9
```

The checker independently decodes every rotation, verifies simplicity and
4-regularity, reconstructs all facial walks, checks the exact face counts,
and tests connectivity after deleting every set of at most two vertices.  It
then computes every triangle-incidence multiset.  None of the 33 maps has
the required `1^22,2` multiset, so the hypothetical `S`, and hence `G`, does
not exist.  It explicitly requires the planar-code header and the fixed input
SHA-256, and uses explicit failure conditions (not optimization-removable
Python assertions) for the certificate totals.

## SHA-256

```text
1e5be747be18fc92e040d2ca5c442d9e5f66bc01223f9ae1cf7365f287ed9738  plantri.c
846f9a0cfa705788f7442f386b945e6035d7fe19d2bc004ab3f73669940156aa  quad_restrict.c
c2ebdf3c143ea2c2f912a4becf93f0cbea8cbdaf17063a0b0c1d4b47c07556f9  quartic23_F3x8_F4x17.plc
59706ca7197f1740292c8fa79fe93d3fb55abc549d6c872398381f43a77711bb  verify_23_quartic.py
```
