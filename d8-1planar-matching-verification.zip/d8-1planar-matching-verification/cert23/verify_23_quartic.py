#!/usr/bin/env python3
"""Verify the finite 23-vertex quartic-map certificate.

Input is the planar_code output of

  quad_restrict -q -F3_8^8F4_17^17 -d 25

from commit 23d75d009948a868c7bf6fdb1486051b192d0d52 of
https://github.com/lichengzhang1/4-regular-plane-graphs-with-given-faces.
"""

from collections import Counter, deque
from hashlib import sha256
from pathlib import Path
import sys


HEADERS = (b">>planar_code<<", b">>planar_code le<<")
EXPECTED_SHA256 = "c2ebdf3c143ea2c2f912a4becf93f0cbea8cbdaf17063a0b0c1d4b47c07556f9"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def planar_codes(raw):
    for header in HEADERS:
        if raw.startswith(header):
            raw = raw[len(header) :]
            break
    else:
        raise ValueError("bad planar_code header")
    pos = 0
    while pos < len(raw):
        require(pos < len(raw), "truncated planar_code order")
        n = raw[pos]
        pos += 1
        wide = n == 0
        if wide:
            require(pos + 2 <= len(raw), "truncated wide planar_code order")
            n = int.from_bytes(raw[pos : pos + 2], "little")
            pos += 2
        rotation = []
        for _ in range(n):
            neighbours = []
            while True:
                width = 2 if wide else 1
                require(pos + width <= len(raw),
                        "truncated planar_code adjacency row")
                x = int.from_bytes(raw[pos : pos + width], "little")
                pos += width
                if x == 0:
                    break
                neighbours.append(x - 1)
            rotation.append(neighbours)
        yield rotation
    require(pos == len(raw), "trailing planar_code bytes")


def faces(rotation):
    """Read facial walks from the clockwise rotation system."""
    successor = {}
    for v, neighbours in enumerate(rotation):
        for i, u in enumerate(neighbours):
            successor[u, v] = v, neighbours[(i - 1) % len(neighbours)]
    seen, answer = set(), []
    for u, neighbours in enumerate(rotation):
        for v in neighbours:
            if (u, v) in seen:
                continue
            start = current = (u, v)
            face = []
            while current not in seen:
                seen.add(current)
                face.append(current[0])
                require(current in successor, "non-cellular rotation")
                current = successor[current]
            require(current == start, "facial walk did not close at its start")
            answer.append(face)
    return answer


def connected_after(rotation, removed):
    alive = [v for v in range(len(rotation)) if v not in removed]
    if not alive:
        return True
    seen = {alive[0]}
    queue = deque([alive[0]])
    while queue:
        v = queue.popleft()
        for w in rotation[v]:
            if w not in removed and w not in seen:
                seen.add(w)
                queue.append(w)
    return len(seen) == len(alive)


def main(path):
    raw = Path(path).read_bytes()
    digest = sha256(raw).hexdigest()
    require(digest == EXPECTED_SHA256, "unexpected certificate SHA-256")
    histogram = Counter()
    number = target = connectivity_lt3 = 0
    for rotation in planar_codes(raw):
        number += 1
        require(len(rotation) == 23, "unexpected vertex count")
        require(all(
            len(neighbours) == 4
            and len(set(neighbours)) == 4
            and v not in neighbours
            and all(0 <= w < 23 for w in neighbours)
            for v, neighbours in enumerate(rotation)
        ), "rotation is not simple quartic")
        darts = {(v, w) for v, neighbours in enumerate(rotation)
                 for w in neighbours}
        require(all((w, v) in darts for v, w in darts),
                "asymmetric planar_code adjacency")
        require(len({tuple(sorted(dart)) for dart in darts}) == 46,
                "wrong edge count")
        facial_walks = faces(rotation)
        require(Counter(map(len, facial_walks)) == Counter({3: 8, 4: 17}),
                "wrong face inventory")
        require(sum(map(len, facial_walks)) == 92,
                "wrong total facial length")
        require(all(len(face) == len(set(face)) for face in facial_walks),
                "facial walk repeats a vertex")
        for a in range(23):
            if not connected_after(rotation, {a}):
                connectivity_lt3 += 1
                break
            for b in range(a + 1, 23):
                if not connected_after(rotation, {a, b}):
                    connectivity_lt3 += 1
                    break
            else:
                continue
            break
        tau = [0] * 23
        for face in facial_walks:
            if len(face) == 3:
                for v in face:
                    tau[v] += 1
        histogram[tuple(sorted(Counter(tau).items()))] += 1
        if sorted(tau) == [1] * 22 + [2]:
            target += 1
    print("maps:", number)
    for signature, multiplicity in sorted(histogram.items()):
        print(multiplicity, dict(signature))
    print("connectivity_lt3:", connectivity_lt3)
    print("target_tau_1x22_2:", target)
    print("sha256:", digest)
    if number != 33 or connectivity_lt3 != 0 or target != 0:
        raise SystemExit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} quartic23.plc")
    main(sys.argv[1])
