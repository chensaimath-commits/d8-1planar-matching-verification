# Licensing notice

No repository-wide license grant has been selected for this draft. Copyright
in the manuscript and the authors' original certificate code remains with
Sai Chen and Wei Li unless they publish a separate top-level `LICENSE`.

The repository also contains third-party plantri sources. Those files retain
their upstream copyright and license notices. The official plantri 5.8 source
copies in `cert25_core/` and `cert25_parallel/` are accompanied by
`PLANTRI-LICENSE-2.0.txt`. The older source snapshots identify their upstream
version and provenance in their directory READMEs and source headers; confirm
the applicable upstream redistribution terms before public release.

This notice is informational and is not itself a software license.

