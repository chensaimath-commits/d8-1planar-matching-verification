# 25-vertex parallel-pole certificate

This directory excludes the only surviving `a=1` branch in which the added
uncrossed edge is parallel to an old pole edge.  In the augmented full-kite
skeleton `S+`, the old and new pole edges form the unique parallel pair.  The
dual `Q` is therefore a general plane quadrangulation on 27 vertices, with
degree multiset `3^8,4^19`.  The two faces of `Q` corresponding to the poles
have triangle-incidence zero; the required dual signature is
`0^2,1^22,2^1`, and the two zero-incidence vertices must be joined by the
unique double edge of `S+`.

## Exhaustive generation

The exact official plantri 5.8 source (March 4, 2026) and its Apache 2.0
license are bundled in this directory.  The recorded source has

```text
sha256 3f70de5a3cacc78b2ed25b6a257588da94a518d8ae1dae74bcd0bf259cea07e8  plantri.c
```

From this directory, compile the exact filter and the deliberately wider
audit filter.  This plantri version stringizes `PLUGIN` internally, so the
macro value must not contain additional C-string quotes:

```sh
cc -O3 -o plantri_pq25_exact \
  -DPLUGIN=../cert25_parallel_quartic_plugin.c plantri.c
cc -O3 -DPQ25_EMIT_SUPERSET -o plantri_pq25_superset \
  -DPLUGIN=../cert25_parallel_quartic_plugin.c plantri.c
```

The following 16-way split is plantri's canonical `res/mod` split.  `-E` is
essential because edge code distinguishes parallel edges.

```sh
for i in $(seq 0 15); do
  ./plantri_pq25_exact -E -Q -m3 27 "${i}/16" \
    "part_${i}.ec" >/dev/null 2>"part_${i}.log" &
  ./plantri_pq25_superset -E -Q -m3 27 "${i}/16" \
    "superset_${i}.ec" >/dev/null 2>"superset_${i}.log" &
done
wait
```

The plug-in's intermediate degree filter is necessary, not heuristic.  If
`rem=27-nv` expansion steps remain, one step can remove at most one unit of
degree excess above four, at most two units of deficit below three, and at
most three units of total distance from `{3,4}`.  It retains a partial map
whenever

```text
sum max(deg-4,0) <= rem,
sum max(3-deg,0) <= 2 rem,
sum distance(deg,{3,4}) <= 3 rem.
```

Thus no final `3^8,4^19` quadrangulation is pruned.  At size 27 the exact
filter reconstructs the dual rotation, all 25 quadrangular faces, the
triangle-incidence signature, edge multiplicities, all 19 kite completions,
the degree sequence `7^24,6`, and factor-criticality.  The superset build
emits all maps that reach the final degree/face test, including every map
rejected by the later signature and double-edge tests.  This lets the
separately written Python verifier repeat the decisive reconstruction without
trusting the plug-in's late tests.

Summed over the 16 shards, both runs report

```text
seen=1189 degree_faces=51 tau=2 emitted_one_double=0
kite_simple=0 degree_7^24_6=0 factor_critical=0
```

The exact run writes zero maps.  The audit run writes all 51 degree/face
candidates.  Run the independent reconstruction and the locked manifest from
this directory with

```sh
python3 ../verify_25_parallel_quartic.py superset_*.ec
python3 verify_manifest.py
```

The locked manifest prints

```text
PASS exact_generator seen=1189 degree_faces=51 tau=2 exact_tau_one_double=0 written=0
PASS superset_generator seen=1189 degree_faces=51 tau=2 exact_tau_one_double=0 written=51
PASS independent_verifier files=16 maps=51 degree_signature=51 quadrangular_embedding=51 tau_signature=2 exact_tau_one_double=0 kite_simple=0 degree_7^24_6=0 factor_critical=0
PASS all listed source/input-stream hashes and all per-shard counter rows locked
```

The independent verifier rejects header-only input, validates every edge-code
rotation and facial walk, and finds exactly two maps with the required
triangle-incidence signature.  Neither has the required unique double pole
edge, so the branch is empty before factor-criticality is needed.

## Locked source hashes

```text
3f70de5a3cacc78b2ed25b6a257588da94a518d8ae1dae74bcd0bf259cea07e8  plantri.c
402964d1d446e74c33c26db20e5ee173dffb11b024f1ebb84ad6b3bebc51e3dc  ../cert25_parallel_quartic_plugin.c
2c6a309159660e33d910a1af9ce46b87ef97e976d2dc409bf95c95220d08007f  ../verify_25_parallel_quartic.py
588f1eabd9952656ba7797a17454a1975bad156037cd4708b012431700bbb16e  ../verify_25_typeX.py
```

`verify_manifest.py` additionally locks every one of the 16 superset stream
hashes, the bundled plantri source, every per-shard counter row, and the fact
that all 16 exact streams
contain only the edge-code header.
