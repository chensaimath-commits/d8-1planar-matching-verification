#!/usr/bin/env python3
"""Locked manifest checker for the 25-vertex parallel-pole certificate."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import re
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
EDGE_HEADER = b">>edge_code<<"

SOURCE_HASHES = {
    HERE / "plantri.c":
        "3f70de5a3cacc78b2ed25b6a257588da94a518d8ae1dae74bcd0bf259cea07e8",
    ROOT / "cert25_parallel_quartic_plugin.c":
        "402964d1d446e74c33c26db20e5ee173dffb11b024f1ebb84ad6b3bebc51e3dc",
    ROOT / "verify_25_parallel_quartic.py":
        "2c6a309159660e33d910a1af9ce46b87ef97e976d2dc409bf95c95220d08007f",
    ROOT / "verify_25_typeX.py":
        "588f1eabd9952656ba7797a17454a1975bad156037cd4708b012431700bbb16e",
}

SUPERSET_HASHES = (
    "4e4a73525256d5e1b4abcc146f03ea2e442aeb46ba4b24e8bbc645ac9395b113",
    "fcaea9b30ca386c13835a486a5dc22fe8ff32bd2fbbe14a673b7b13aa75c45f0",
    "b0f1f87ad395241aae201437cf500fef88cbadb0be704be05f0ae7b731155a16",
    "8bf81efe66d874fbf825d7109e05a951fc90ab6d6977a4a6867350acef267be3",
    "2028bcd03d369b6f882c7f0120d1f7c101f55c6ed5eaadee4ee1d53c6ff0b392",
    "5f5df76ba2953b3a7ae3b5f541749c285b0d3df68a02ca4883d54d514fd1f52a",
    "654c42db4862ce1f41574f81aa2eebc4e9392da08becb41fd0b28d4e4c034355",
    "72e0440f7c93cac09e134022f81abc25e709310cc8bd985ce48c2bbcbbd6c188",
    "93cc30dd80f2f011ecaa883b7572e503870001d803f94208e0824898a35b5734",
    "c4afb04bf7b8dae0feebec24517ad7e3f54244c35cd880180a64bf311d6fde5f",
    "e4c8ccfa5806344c4bf4c09c35d5dcfe7b2941bc87b82be59639f030c2fd445b",
    "02bcc840ae9afbce1556556642a7dd6f76382652f4e7562fed91c8d59f9cab0d",
    "c46b28ccc305a488265390bacdcf4bd142a933aee41542f363bb0fe6e6f229bd",
    "c1215f333de51e5348939e7ed7776664d5741e3ee7481637c62e0694d108de91",
    "0aa446b57f55ae44428705f15b29f2a35051d3867e0d9d98665feefc48921156",
    "35aa36549ed42ab56c655c1ed76fcd5491f6d22a089440f0904d0422256d30c3",
)

# seen, degree_faces, tau, exact-double, kite-simple, degree-ok,
# factor-critical, maps-written
EXACT_ROWS = (
    (18, 0, 0, 0, 0, 0, 0, 0),
    (34, 1, 0, 0, 0, 0, 0, 0),
    (30, 4, 0, 0, 0, 0, 0, 0),
    (43, 2, 0, 0, 0, 0, 0, 0),
    (54, 2, 0, 0, 0, 0, 0, 0),
    (106, 2, 0, 0, 0, 0, 0, 0),
    (65, 9, 1, 0, 0, 0, 0, 0),
    (106, 3, 1, 0, 0, 0, 0, 0),
    (81, 5, 0, 0, 0, 0, 0, 0),
    (115, 2, 0, 0, 0, 0, 0, 0),
    (100, 6, 0, 0, 0, 0, 0, 0),
    (86, 1, 0, 0, 0, 0, 0, 0),
    (58, 6, 0, 0, 0, 0, 0, 0),
    (125, 3, 0, 0, 0, 0, 0, 0),
    (103, 4, 0, 0, 0, 0, 0, 0),
    (65, 1, 0, 0, 0, 0, 0, 0),
)

SUPERSET_ROWS = tuple(row[:-1] + (row[1],) for row in EXACT_ROWS)

SUMMARY_RE = re.compile(
    r"parallel-quartic certificate: seen=(\d+) degree_faces=(\d+) "
    r"tau=(\d+) emitted_one_double=(\d+) kite_simple=(\d+) "
    r"degree_7\^24_6=(\d+) factor_critical=(\d+)"
)
WRITTEN_RE = re.compile(r"(\d+) quadrangulations written to .+; cpu=.+ sec")


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def digest(path: Path) -> str:
    try:
        return sha256(path.read_bytes()).hexdigest()
    except OSError as exc:
        fail(f"cannot read {path}: {exc}")


def parse_log(path: Path, shard: int) -> tuple[int, ...]:
    try:
        lines = path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as exc:
        fail(f"cannot parse {path}: {exc}")
    if len(lines) != 3:
        fail(f"{path}: expected exactly three lines")
    required_switches = f"-E -Q -m3 27 {shard}/16"
    if required_switches not in lines[0]:
        fail(f"{path}: command line does not contain {required_switches!r}")
    summary = SUMMARY_RE.fullmatch(lines[1])
    written = WRITTEN_RE.fullmatch(lines[2])
    if summary is None or written is None:
        fail(f"{path}: malformed summary")
    return tuple(map(int, summary.groups())) + (int(written.group(1)),)


def main() -> None:
    for path, expected in SOURCE_HASHES.items():
        actual = digest(path)
        if actual != expected:
            fail(f"{path}: sha256 {actual}, expected {expected}")

    exact_rows = []
    superset_rows = []
    superset_paths = []
    for shard in range(16):
        exact = HERE / f"part_{shard}.ec"
        if exact.read_bytes() != EDGE_HEADER:
            fail(f"{exact}: expected a header-only edge_code stream")
        exact_row = parse_log(HERE / f"part_{shard}.log", shard)
        if exact_row != EXACT_ROWS[shard]:
            fail(f"part_{shard}.log: counter row differs from locked result")
        exact_rows.append(exact_row)

        superset = HERE / f"superset_{shard}.ec"
        actual = digest(superset)
        if actual != SUPERSET_HASHES[shard]:
            fail(f"{superset}: sha256 {actual}, expected {SUPERSET_HASHES[shard]}")
        superset_row = parse_log(HERE / f"superset_{shard}.log", shard)
        if superset_row != SUPERSET_ROWS[shard]:
            fail(f"superset_{shard}.log: counter row differs from locked result")
        superset_rows.append(superset_row)
        superset_paths.append(superset)

    exact_totals = tuple(map(sum, zip(*exact_rows)))
    superset_totals = tuple(map(sum, zip(*superset_rows)))
    expected_exact = (1189, 51, 2, 0, 0, 0, 0, 0)
    expected_superset = (1189, 51, 2, 0, 0, 0, 0, 51)
    if exact_totals != expected_exact or superset_totals != expected_superset:
        fail("aggregate generator totals differ from locked results")

    command = [sys.executable, str(ROOT / "verify_25_parallel_quartic.py")]
    command.extend(map(str, superset_paths))
    checked = subprocess.run(command, text=True, capture_output=True)
    if checked.returncode != 0:
        fail(f"independent verifier exited {checked.returncode}: {checked.stderr.strip()}")
    observed = {}
    for line in checked.stdout.splitlines():
        match = re.fullmatch(r"([A-Za-z0-9_^]+)=(\d+)", line)
        if match:
            observed[match.group(1)] = int(match.group(2))
    expected = {
        "files": 16,
        "maps": 51,
        "degree_signature": 51,
        "quadrangular_embedding": 51,
        "tau_signature": 2,
        "exact_tau_one_double": 0,
        "kite_simple": 0,
        "degree_7^24_6": 0,
        "factor_critical": 0,
    }
    if observed != expected:
        fail(f"independent verifier counters {observed!r}, expected {expected!r}")
    if "certificate_result=PASS" not in checked.stdout:
        fail("independent verifier did not print PASS")

    print(
        "PASS exact_generator "
        "seen=1189 degree_faces=51 tau=2 exact_tau_one_double=0 written=0"
    )
    print(
        "PASS superset_generator "
        "seen=1189 degree_faces=51 tau=2 exact_tau_one_double=0 written=51"
    )
    print(
        "PASS independent_verifier files=16 maps=51 degree_signature=51 "
        "quadrangular_embedding=51 tau_signature=2 "
        "exact_tau_one_double=0 kite_simple=0 degree_7^24_6=0 "
        "factor_critical=0"
    )
    print(
        "PASS all listed source/input-stream hashes and all per-shard "
        "counter rows locked"
    )


if __name__ == "__main__":
    main()
